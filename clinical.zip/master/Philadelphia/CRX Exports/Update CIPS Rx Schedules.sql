/*
select distinct s.[Expanded SIG], s.schedule
into [philly schedules]
from [PHILADELPHIA RX ORDER EXPORT with schedule] s

select *, substring(s.[expanded sig], 2, len(s.[expanded sig])-2 ) from [philly schedules] s where s.[Expanded SIG] like '"%"'

update [philly schedules] set [Expanded SIG] = substring([expanded sig], 2, len([expanded sig])-2 ) where [Expanded SIG] like '"%"';

select * from [philly schedules] s where s.[Expanded SIG] = '"APPLY AS DIRECTED TWICE DAILY AS NEEDED, EXTERNALLY"'

--"APPLY AS DIRECTED TWICE DAILY AS NEEDED, EXTERNALLY"
*/

select * from CIPS_RAW_PHILLY.dbo.[philly schedules];

begin tran;

update rxf set rxf.sch_id = sch.id
from rxf
left outer join cips_raw_philly.dbo.[Philly schedules] s on ( s.[expanded sig] = rxf.EXPANDED_SIG )
left outer join sch on ( sch.dcode = s.[schedule] )
where rxf.conversion = 'philly'
and rxf.sch_id is null 
and rxf.dc_flag = 'F'
and len(s.[schedule]) > 0;

rollback;
commit;

select rxf.expanded_sig, sch.dcode, sch.dtext 
from rxf
left outer join sch on ( sch.id = rxf.sch_id ) 
where rxf.conversion = 'philly'
and rxf.sch_id is not null;

