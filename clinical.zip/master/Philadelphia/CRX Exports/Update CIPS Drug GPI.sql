select * from drg where conversion = 'philly' and len(gpi) > 0

select * from cips_raw_philly.dbo.[Philly Drugs with GPIs];

update drg set gpi = g.gpi
from drg
left outer join cips_raw_philly.dbo.[Philly Drugs with GPIs] g on ( g.[drug name] = drg.dname + ' ' + drg.strength + ' ' + drg.dos_id )
where drg.conversion = 'philly'
and ( drg.gpi is null or len(drg.gpi) = 0 );

--ALBUTEROL 3ML U/D			44201010102515

