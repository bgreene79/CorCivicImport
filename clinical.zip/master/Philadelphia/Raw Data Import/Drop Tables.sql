-- Clear out data from temp tables

drop table CIPS_RAW_PHILLY.dbo.rx;
drop table CIPS_RAW_PHILLY.dbo.alc;
