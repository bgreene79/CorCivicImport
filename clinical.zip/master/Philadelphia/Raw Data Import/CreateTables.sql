Create Table FacilityTranslation ( OldFacCode varchar(10) NOT NULL, NewFacCode varchar(10) NOT NULL, Defaults char(1) NOT NULL );

GO

CREATE UNIQUE CLUSTERED INDEX [ClusteredIndex] ON [dbo].[FacilityTranslation]
(
	[OldFacCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

GO

insert into facilitytranslation values ( '174', 'ASD-MOD', 'F' );
insert into facilitytranslation values ( '173', 'ASD-CU', 'F' );
insert into facilitytranslation values ( '176', 'CCC', 'F' );
insert into facilitytranslation values ( '163', 'CFCF-A', 'F' );
insert into facilitytranslation values ( '164', 'CFCF-B', 'F' );
insert into facilitytranslation values ( '165', 'CFCF-C', 'F' );
insert into facilitytranslation values ( '166', 'CFCF-D', 'F' );
insert into facilitytranslation values ( '167', 'CFCF-TRI', 'F' );
insert into facilitytranslation values ( '169', 'PICC-MED', 'F' );
insert into facilitytranslation values ( '168', 'PICC-TRA', 'F' );
insert into facilitytranslation values ( '181', 'PJJSC', 'F' );
insert into facilitytranslation values ( '162', 'PDC-BEH', 'F' );
insert into facilitytranslation values ( '161', 'PDC-INF', 'F' );
insert into facilitytranslation values ( '160', 'PDC-POP', 'F' );
insert into facilitytranslation values ( '170', 'PHOC', 'F' );
insert into facilitytranslation values ( '171', 'RCF-MH', 'F' );
insert into facilitytranslation values ( '172', 'RCF-POP', 'F' );
insert into facilitytranslation values ( '186', 'PHIL-DEF', 'T' );

GO

create table tmp_reg ( id varchar(20) NOT NULL, data varchar(255) );

GO

insert into tmp_reg values ( 'PHR_ID', 3 );
insert into tmp_reg values ( 'NEW_PHR_ID', 1 );
insert into tmp_reg values ( 'RGN_ID', 92 );
insert into tmp_reg values ( 'CONVERSION', 'PHILLY' );
insert into tmp_reg values ( 'DC_REA_ID', 'DC' );
insert into tmp_reg values ( 'SYS_USR_ID', 1 );
insert into tmp_reg values ( 'RPH_USR_ID', 36 ); -- Lorie Crenshaw

GO

