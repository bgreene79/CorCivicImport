select
'[' + columns.name + '],'
from sys.tables 
join sys.columns on (columns.object_id = tables.object_id)
left outer join sys.extended_properties on (columns.column_id = extended_properties.minor_id and columns.object_id = extended_properties.major_id and extended_properties.name = 'Default')
where tables.name = 'PAT_THP' and columns.name like '%'
order by tables.name, columns.name


select
isnull('''' + convert(varchar(100), extended_properties.value) + '''', 'NULL') + ', --' + columns.name
from sys.tables 
join sys.columns on (columns.object_id = tables.object_id)
left outer join sys.extended_properties on (columns.column_id = extended_properties.minor_id and columns.object_id = extended_properties.major_id and extended_properties.name = 'Default')
where tables.name = 'PAT_THP'
order by tables.name, columns.name


