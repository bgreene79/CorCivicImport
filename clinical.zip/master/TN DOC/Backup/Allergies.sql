USE QS1

DROP TABLE ALLERGIES

CREATE TABLE Allergies
(
	[PD-Pat Combined Name] VARCHAR(100),
	[PG-Acct Number1] VARCHAR(100),
	[PD-Birthdate x/x/x] VARCHAR(100),
	[PT-Medical Rcd Nbr] VARCHAR(100),
	[CL-Allg Code 01] VARCHAR(100),
	[CL-Allg Desc 01] VARCHAR(100),
	[CL-Allg Code 02] VARCHAR(100),
	[CL-Allg Desc 02] VARCHAR(100),
	[CL-Allg Code 03] VARCHAR(100),
	[CL-Allg Desc 03] VARCHAR(100),
	[CL-Allg Code 04] VARCHAR(100),
	[CL-Allg Desc 04] VARCHAR(100),
	[CL-Allg Code 05] VARCHAR(100),
	[CL-Allg Desc 05] VARCHAR(100),
	[CL-Allg Code 06] VARCHAR(100),
	[CL-Allg Desc 06] VARCHAR(100),
	[CL-Allg Code 07] VARCHAR(100),
	[CL-Allg Desc 07] VARCHAR(100),
	[CL-Allg Code 08] VARCHAR(100),
	[CL-Allg Desc 08] VARCHAR(100),
	[CL-Allg Code 09] VARCHAR(100),
	[CL-Allg Desc 09] VARCHAR(100),
	[CL-Allg Code 10] VARCHAR(100),
	[CL-Allg Desc 10] VARCHAR(100)
)

BULK INSERT Allergies
   FROM 'C:\QS12CIPS\Data\Allergies.txt'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '","',  
         ROWTERMINATOR = '"\n'  
      );

select * from allergies

update allergies set [PD-Pat Combined Name] = replace([PD-Pat Combined Name], '"', '')

select * 
from allergies
join fills on( [PD-Pat Combined Name] like rtrim([Last Name(35)]) + ', ' +  rtrim([First Name(35)]) + '%' and fills.[Patient Birthdate] = [PD-Birthdate x/x/x])


