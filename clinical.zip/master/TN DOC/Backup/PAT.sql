/*
alter table qs1.dbo.fills add id int

With data As
(
	SELECT fills.[date Entered], fills.[Time.Of.fill], fills.[rx number],
	ROW_NUMBER() OVER (ORDER BY [date entered], [Time.OF.Fill] asc) as  ID
	FROM qs1.dbo.fills

)
UPDATE qs1.dbo.fills SET id = data.id
FROM qs1.dbo.fills
INNER JOIN Data ON fills.[Date Entered] = data.[Date Entered] and fills.[Time.Of.Fill] = data.[time.of.fill] and fills.[rx number] = data.[rx number]


select 
* 
from qs1.dbo.fills
where [Patient Code] = ''
or [Patient Code] is null


select 
	[Patient Birthdate],
	[Patient First Nme],
	[Patient Last Name],
	[Patient Group]
from qs1.dbo.fills
Group by
	[Patient Birthdate],
	[Patient First Nme],
	[Patient Last Name],
	[Patient Group]
having min([patient code]) != max([patient code])

*/

USE CIPS_TEST

INSERT INTO PAT
(
ACCT_NUMBER,
ADDRESS1,
ADDRESS2,
ADMIT_DATE,
ADMIT_TIME,
AWAY,
BED,
BILL_FLAG,
BODY_SURF,
BOOK_NUMBER,
CHECK_MEDISPAN_FLAG,
CHG_ID,
CITY,
CLASS2_FLAG,
COMMENT1,
COMMENT2,
COMPLIANT_FLAG,
CONTROLLED_ALLOWED,
CREATIN,
DEFAULT_KOP,
DISPENSE_TYPE,
DISPLAY_FLAG,
DOB,
EARLIEST_RELEASE,
EMAIL,
FAC_FROM,
FAC_ID,
FNAME,
GENDER,
GROUPING,
HEIGHT_FT,
HEIGHT_IN,
HOSP_NUMBER,
ID,
LANG,
LEGAL_NAME,
LNAME,
LOCATION,
MNAME,
OMH_LEVEL,
ORIGIN,
PHONE,
PRINTED_DATE,
PRINTED_TIME,
PRINTED_USR_ID,
RACE,
REL_ID,
RELEASE_DATE,
RELEASE_TIME,
RESIDENCE,
ROOM,
SAFETYCAP_FLAG,
SLF_CRY_FLAG,
SPECIAL1,
SPECIAL2,
SS_NUMBER,
ST,
STATUS,
STOCK_FLAG,
SYS_DATE,
UNIT,
WEIGH_DATE,
WEIGHT,
WING,
ZIP
)
select
ACCT_NUMBER, --ACCT_NUMBER
NULL, --ADDRESS1
NULL, --ADDRESS2
NULL, --ADMIT_DATE
NULL, --ADMIT_TIME
'F', --AWAY
NULL, --BED
'T', --BILL_FLAG
NULL, --BODY_SURF
NULL, --BOOK_NUMBER
'T', --CHECK_MEDISPAN_FLAG
NULL, --CHG_ID
NULL, --CITY
NULL, --CLASS2_FLAG
NULL, --COMMENT1
NULL, --COMMENT2
'T', --COMPLIANT_FLAG
'T', --CONTROLLED_ALLOWED
NULL, --CREATIN
'S', --DEFAULT_KOP
'N', --DISPENSE_TYPE
'T', --DISPLAY_FLAG
DOB, --DOB
NULL, --EARLIEST_RELEASE
NULL, --EMAIL
NULL, --FAC_FROM
FAC_ID, --FAC_ID
isnull(FNAME,''), --FNAME
'U', --GENDER
NULL, --GROUPING
NULL, --HEIGHT_FT
NULL, --HEIGHT_IN
NULL, --HOSP_NUMBER
ID, --ID
'E', --LANG
NULL, --LEGAL_NAME
LNAME, --LNAME
NULL, --LOCATION
NULL, --MNAME
'0', --OMH_LEVEL
'NONE', --ORIGIN
NULL, --PHONE
NULL, --PRINTED_DATE
NULL, --PRINTED_TIME
NULL, --PRINTED_USR_ID
'U', --RACE
NULL, --REL_ID
NULL, --RELEASE_DATE
NULL, --RELEASE_TIME
'Z', --RESIDENCE
NULL, --ROOM
'F', --SAFETYCAP_FLAG
'T', --SLF_CRY_FLAG
NULL, --SPECIAL1
NULL, --SPECIAL2
NULL, --SS_NUMBER
' ', --ST
'N', --STATUS
'F', --STOCK_FLAG
SYS_DATE, --SYS_DATE
NULL, --UNIT
NULL, --WEIGH_DATE
NULL, --WEIGHT
NULL, --WING
NULL --ZIP
FROM 
(
	SELECT
	PF.ID ,
	(select [Patient Birthdate] where isdate([Patient Birthdate]) =1) as DOB,
	[Patient First Nme] as FNAME,
	[Patient Last Name] as LNAME,
	[Patient Code] as ACCT_NUMBER,
	[date entered] as SYS_DATE,
	FAC.ID as FAC_ID
	From qs1.dbo.fills as pf
	Left outer JOIN FAC on (FAC.dcode = pf.[Patient Group])
	WHERE pf.ID IN (SELECT MAX(fills.ID) FROM QS1.dbo.Fills GRoup by fills.[PAtient code])
) AS QS1PAT


