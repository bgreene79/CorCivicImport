DELETE FROM DOC
INSERT INTO DOC
(
[ADDRESS1],
[ADDRESS2],
[CERTIFICATE_TEXT],
[CITY],
[CNTRL_LIABILITY_FLAG],
[DEA],
[DEA_EXP],
[DGR_ID],
[DORMANT_FLAG],
[EMAIL],
[EXT1],
[EXT2],
[FAX],
[FNAME],
[GROUPING],
[ID],
[LNAME],
[MNAME],
[NPI],
[PHONE1],
[PHONE2],
[SNAME],
[ST],
[STATE_NUM],
[STATE_NUM_EXP],
[STOCK_LIABILITY_FLAG],
[SUFFIX],
[SUP_DOC_ID],
[TSK_DOC_ID],
[UPIN],
[ZIP]
)
SELECT
NULL, --ADDRESS1
NULL, --ADDRESS2
NULL, --CERTIFICATE_TEXT
NULL, --CITY
'F', --CNTRL_LIABILITY_FLAG
DEA, --DEA
DEA_EXP, --DEA_EXP
NULL, --DGR_ID
'F', --DORMANT_FLAG
NULL, --EMAIL
NULL, --EXT1
NULL, --EXT2
NULL, --FAX
FNAME, --FNAME
NULL, --GROUPING
ID, --ID
LNAME, --LNAME
NULL, --MNAME
NPI, --NPI
NULL, --PHONE1
NULL, --PHONE2
NULL, --SNAME
' ', --ST
NULL, --STATE_NUM
NULL, --STATE_NUM_EXP
'F', --STOCK_LIABILITY_FLAG
NULL, --SUFFIX
NULL, --SUP_DOC_ID
NULL, --TSK_DOC_ID
NULL, --UPIN
NULL --ZIP
FROM QS1.dbo.doctor





ALTER TABLE Doctor add id int
update doctor set id = null

With data As
(
	SELECT doctor.NAME,
	ROW_NUMBER() OVER (ORDER BY NAME) as  ID
	FROM qs1.dbo.doctor

)
UPDATE qs1.dbo.doctor SET id = data.id
FROM qs1.dbo.doctor
INNER JOIN Data ON doctor.NAME = data.NAME


alter table doctor drop column lname
alter table doctor drop column fname
alter table doctor add lname varchar(200)
alter table doctor add fname varchar(200)

update doctor set lname = name
update doctor set lname = REPLACE( substring(name, 1, charindex(',', name, 1) - 1), '"', '')
update doctor set fname = REPLACE( substring(name, charindex(',', name, 1) + 2, len(name)), '"', '')

select * From doctor


