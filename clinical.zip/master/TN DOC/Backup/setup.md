Control Settings
----------------
Account Number System Unique

Additional Registry Settings
----------------------------

Pharmacy Settings
------------------

Facility Settings
-----------------
* Use a Model Facility
* Use a CIPS_PREVIOUS
* Meds Taken on Stop

Regions and Queues
------------------
Setup Primary Regions
