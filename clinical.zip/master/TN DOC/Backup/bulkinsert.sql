BULK INSERT Fills  
   FROM 'C:\QS12CIPS\Data\QS1.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
