
# Build List of Columns

* Move QS1.xls to Data Folder
* Copy Via SecureLink to Kalos Desktop
* Open with Excel 2016
* Copy First Row of Column Titles to Notepad++
* Replace \t with \r\n using Extended Search Mode
* Insure Single Blank Line at the End of the File
* Position Cursor to beginning of the file
* Press Alt-M then Enter
* Press \[ (End) (Left) \] (Home) Down Alt-M T 
* Press ALT-M R E R 
* Attempt Create Table and look for duplicate column names.
* Add 2 at the end.
