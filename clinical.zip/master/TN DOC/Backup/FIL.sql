/*

select
'[' + columns.name + '],'
from sys.tables 
join sys.columns on (columns.object_id = tables.object_id)
left outer join sys.extended_properties on (columns.column_id = extended_properties.minor_id and columns.object_id = extended_properties.major_id and extended_properties.name = 'Default')
where tables.name = 'FIL' and columns.name like '%'
order by tables.name, columns.name


select
isnull('''' + convert(varchar(100), extended_properties.value) + '''', 'NULL') + ', --' + columns.name
from sys.tables 
join sys.columns on (columns.object_id = tables.object_id)
left outer join sys.extended_properties on (columns.column_id = extended_properties.minor_id and columns.object_id = extended_properties.major_id and extended_properties.name = 'Default')
where tables.name = 'FIL'
order by tables.name, columns.name
*/
USE CIPS_TEST
update rxf set fil_id = null
delete from fil
INSERT INTO FIL
(
[ACQ_COST],
[ADM_DATE],
[ADM_PASS],
[AUTHORIZE],
[AWP],
[BIL_BAT_ID],
[BIL_DATE],
[BILL_FLAG],
[CARD_QUANT],
[CHG_ID],
[COPAY_PRICE],
[COST],
[COST_BASIS],
[CREDITABLE_FLAG],
[DAYS_SUPPLY],
[DEA],
[DI_SEVERITY],
[DISPENSE_QTY],
[DISPENSE_TEXT],
[DOCUTRACK_ID],
[DRG_ID],
[DSP_FILL_FLAG],
[DSP_ID],
[EMAR],
[END_DATE],
[END_PASS],
[FAC_ID],
[FAC_TYPE],
[FIL_DATE],
[FIL_THP_ID],
[FORMULARY_FLAG],
[GENERIC_FLAG],
[HIGH_ACQ_COST],
[ID],
[INS_PRICE],
[KOP],
[LAB_REQ_FLAG],
[LABEL_COUNT],
[LABEL_SPLITS],
[LOT_DATE],
[LOT_NUMBER],
[MACHINE],
[MAINTENANCE_FLAG],
[MAN_ABB],
[MAN_DNAME],
[MAN_LABELER],
[MANUAL_PRC_FLAG],
[NDC],
[NET_QTY_DSP],
[NFA_ID],
[ORD_DRG_ID],
[ORIGIN],
[OTC_FLAG],
[OVR_ID],
[PACKS_FLAG],
[PAT_ID],
[PAT_LOCATION],
[PHARM_USR_ID],
[PHARMACIST],
[PHARMACY_FLAG],
[PHR_ID],
[PND_USR_ID],
[PR_FLAG],
[PRC_FACTOR],
[PRC_FEE],
[PRC_ID],
[PREFERRED_FLAG],
[PREGNANT_FLAG],
[PRI_ID],
[PRICE],
[PRT_DATE],
[PV_SYS_DATE],
[PV_SYS_TIME],
[PV_TIME_HOUR],
[PV_USR_ID],
[QTY_DSP],
[QTY_PER_BUBBLE],
[QTY_PER_CARD],
[QTY_SENT],
[QTY_UNCOSTED],
[RTN_FLAG],
[RXF_CON_ID],
[RXF_ID],
[RXF_NUMBER],
[RXF_ORD_ID],
[RXF_ORD_ORDER_NUM],
[SAFETY_CAP_FLAG],
[SAVED_VERSION],
[SCREENED],
[SCRIPTTYPE],
[SEQ_NUM],
[SHOW_IN_REVIEW_FLAG],
[STATUS],
[SYS_DATE],
[SYS_TIME],
[SYS_TIME_HOUR],
[SYS_USR_ID],
[TECH],
[TECH_USR_ID],
[THP],
[THREE],
[TIME_DISPENSED],
[U_COST],
[U_COST_BASIS],
[U_PRC_FACTOR],
[U_PRC_FEE],
[U_PRC_ID],
[UNIT],
[USUAL_PRICE],
[VERIFY1_SYS_DATE],
[VERIFY1_SYS_TIME],
[VERIFY1_USR_ID],
[VERIFY2_SYS_DATE],
[VERIFY2_SYS_TIME],
[VERIFY2_USR_ID],
[VERSION],
[VOID_REA_ID],
[VOID_SYS_DATE],
[VOID_SYS_TIME],
[VOID_SYS_USR_ID],
[WAC_COST]
)
SELECT
NULL, --ACQ_COST
NULL, --ADM_DATE
NULL, --ADM_PASS
NULL, --AUTHORIZE
NULL, --AWP
NULL, --BIL_BAT_ID
NULL, --BIL_DATE
'F', --BILL_FLAG
NULL, --CARD_QUANT
NULL, --CHG_ID
NULL, --COPAY_PRICE
NULL, --COST
'A', --COST_BASIS
'F', --CREDITABLE_FLAG
NULL, --DAYS_SUPPLY
'0', --DEA
NULL, --DI_SEVERITY
NULL, --DISPENSE_QTY
NULL, --DISPENSE_TEXT
NULL, --DOCUTRACK_ID
DRG_ID, --DRG_ID
'F', --DSP_FILL_FLAG
NULL, --DSP_ID
'F', --EMAR
NULL, --END_DATE
NULL, --END_PASS
fac_id, --FAC_ID
' ', --FAC_TYPE
FIL_DATE, --FIL_DATE
NULL, --FIL_THP_ID
'T', --FORMULARY_FLAG
'T', --GENERIC_FLAG
NULL, --HIGH_ACQ_COST
ID, --ID
NULL, --INS_PRICE
'N', --KOP
'F', --LAB_REQ_FLAG
NULL, --LABEL_COUNT
NULL, --LABEL_SPLITS
NULL, --LOT_DATE
NULL, --LOT_NUMBER
'N', --MACHINE
'F', --MAINTENANCE_FLAG
NULL, --MAN_ABB
NULL, --MAN_DNAME
NULL, --MAN_LABELER
'F', --MANUAL_PRC_FLAG
NDC, --NDC
QTY_DSP, --NET_QTY_DSP
NULL, --NFA_ID
DRG_ID, --ORD_DRG_ID
' ', --ORIGIN
'F', --OTC_FLAG
NULL, --OVR_ID
'F', --PACKS_FLAG
PAT_ID, --PAT_ID
NULL, --PAT_LOCATION
NULL, --PHARM_USR_ID
NULL, --PHARMACIST
'T', --PHARMACY_FLAG
1, --PHR_ID
NULL, --PND_USR_ID
'F', --PR_FLAG
NULL, --PRC_FACTOR
NULL, --PRC_FEE
NULL, --PRC_ID
'T', --PREFERRED_FLAG
'F', --PREGNANT_FLAG
NULL, --PRI_ID
NULL, --PRICE
NULL, --PRT_DATE
NULL, --PV_SYS_DATE
NULL, --PV_SYS_TIME
NULL, --PV_TIME_HOUR
NULL, --PV_USR_ID
QTY_DSP, --QTY_DSP
NULL, --QTY_PER_BUBBLE
NULL, --QTY_PER_CARD
NULL, --QTY_SENT
NULL, --QTY_UNCOSTED
'F', --RTN_FLAG
NULL, --RXF_CON_ID
RXF_ID, --RXF_ID
RX_NUMBER, --RXF_NUMBER
NULL, --RXF_ORD_ID
NULL, --RXF_ORD_ORDER_NUM
'F', --SAFETY_CAP_FLAG
NULL, --SAVED_VERSION
'N', --SCREENED
'N', --SCRIPTTYPE
ID, --SEQ_NUM
'T', --SHOW_IN_REVIEW_FLAG
'N', --STATUS
FIL_DATE, --SYS_DATE
SYS_TIME, --SYS_TIME
NULL, --SYS_TIME_HOUR
NULL, --SYS_USR_ID
NULL, --TECH
NULL, --TECH_USR_ID
'F', --THP
'F', --THREE
NULL, --TIME_DISPENSED
NULL, --U_COST
'A', --U_COST_BASIS
NULL, --U_PRC_FACTOR
NULL, --U_PRC_FEE
NULL, --U_PRC_ID
'E', --UNIT
NULL, --USUAL_PRICE
NULL, --VERIFY1_SYS_DATE
NULL, --VERIFY1_SYS_TIME
NULL, --VERIFY1_USR_ID
NULL, --VERIFY2_SYS_DATE
NULL, --VERIFY2_SYS_TIME
NULL, --VERIFY2_USR_ID
'QS1', --VERSION
NULL, --VOID_REA_ID
NULL, --VOID_SYS_DATE
NULL, --VOID_SYS_TIME
NULL, --VOID_SYS_USR_ID
NULL --WAC_COST
FROM 
(
	SELECT
	PF.ID,
	ff.id as rxf_ID,
	replace(ltrim(replace(pf.[Rx Number], '0', ' ')), ' ', '0') as RX_NUMBER,
	(Select replace(ltrim(replace(pf.[Refills Auth], '0', ' ')), ' ', '0') where (replace(ltrim(replace(pf.[Refills Auth], '0', ' ')), ' ', '0')) > 0) + 1 AS FILLS_ALLOWED,
	pf.[Refills Rem] + 1 as REF_LEFT,
	(select pf.[Date Written] where isdate(pf.[Date Written]) = 1)  as ORD_DATE,
	isnull((select pf.[Rx Stop Date] where isdate(pf.[Rx Stop Date]) = 1), (select pf.[Date Written] where isdate(pf.[Date Written]) = 1) + 365)  as EXP_DATE,
	pf.[Rx Sig Code] as SIG,
	(select pf.[Rx# Original Date] where isdate(pf.[Rx# Original Date]) = 1)  as ORG_DATE,
	replace(replace(pf.[Total Qty Remain], ',', ''), '"', '') as QTY_DUE,
	(select pf.[Date Entered] where isdate(pf.[Date Entered]) = 1)  as FIL_DATE,
	pf.[TIME.Of.Fill] as SYS_TIME,
	PAT.ID AS PAT_ID,
	DRG.ID AS DRG_ID,
	pf.[NDC Nbr]  as NDC,
	fac.id AS fac_id,
	replace(replace(pf.[Qty Dispensed], ',', ''), '"', '') as QTY_DSP
	From qs1.dbo.fills as pf
	LEFT OUTER JOIN PAT on (PAT.ACCT_NUMBER = pf.[Patient Code])
	LEFT OUTER JOIN fac on (faC.DCODE = pf.[Patient Group])
	LEFT OUTER join DRG on (DRG.FORMATTED_NDC=pf.[NDC Nbr])
	LEFT OUTER join qs1.dbo.fills as ff on (ff.id = (SELECT Max(fills.ID) FROM QS1.dbo.Fills where fills.[Rx Number] = pf.[Rx Number]))	
) AS QS1FIL
go

With data As
(
       SELECT RXF_NUMBER, ID as FIL_ID,
       ROW_NUMBER() OVER (ORDER BY RXF_NUMBER, ID) as ID
       FROM FIL
)
UPDATE FIL SET SEQ_NUM = DATA.ID
FROM FIL
INNER JOIN Data ON FIL_ID = FIL.ID
go

UPDATE FIL SET SEQ_NUM = SEQ_NUM - (SELECT MIN(F2.SEQ_NUM) FROM FIL as F2 WHERE FIL.RXF_NUMBER = F2.RXF_NUMBER)


UPDATE RXF SET FIL_ID = (select max(fil.id) from fil where rx_number = rxF_number);
UPDATE RXF SET QTY_USED = (select sum(QTY_DSP) from fil where rx_number = rxF_number);
UPDATE RXF SET REF_USED = (select COUNT(*) from fil where rx_number = rxF_number);
UPDATe RXF SET ACT_REF_USED = REF_USED
UPDATE RXF SET TOT_QTY_DUE = QTY_DUE + QTY_USED where QTY_DUE < 999999

