/*
select
'[' + columns.name + '],'
from sys.tables 
join sys.columns on (columns.object_id = tables.object_id)
left outer join sys.extended_properties on (columns.column_id = extended_properties.minor_id and columns.object_id = extended_properties.major_id and extended_properties.name = 'Default')
where tables.name = 'RXF' and columns.name like '%'
order by tables.name, columns.name


select
isnull('''' + convert(varchar(100), extended_properties.value) + '''', 'NULL') + ', --' + columns.name
from sys.tables 
join sys.columns on (columns.object_id = tables.object_id)
left outer join sys.extended_properties on (columns.column_id = extended_properties.minor_id and columns.object_id = extended_properties.major_id and extended_properties.name = 'Default')
where tables.name = 'RXF'
order by tables.name, columns.name
*/

USE CIPS_TEST


INSERT INTO RXF
(
[ACT_REF_USED],
[DAW],
[DAYS_SUPPLY],
[DC_DATE],
[DC_FLAG],
[DC_REA_ID],
[DISCARD_DATE],
[DISTRIBUTION_FLAG],
[DLY_QTY],
[DOC_ID],
[DRG_ID],
[EPCS_FLAG],
[EXP_DATE],
[EXPAND_SIG_FLAG],
[EXPANDED_ALT_SIG],
[EXPANDED_SIG],
[FIL_ID],
[FILLS_ALLOWED],
[FIRST_ORG_DATE],
[ID],
[LAST_FIL],
[MAR_PRINT_FLAG],
[NEW_RXF_ID],
[NEW_RXF_ORD_ID],
[NEXT_FIL_TYPE],
[NFR_ID],
[NM9_ID],
[OLD_RXF_ID],
[ORD_DATE],
[ORDER_NUMBER],
[ORG_DATE],
[ORIGIN],
[PAT_ID],
[PHR_ID],
[PRN_FLAG],
[QTY_DOSE],
[QTY_DUE],
[QTY_RETURNED],
[QTY_USED],
[REF_DAYS_SUPPLY],
[REF_LEFT],
[REF_QTY],
[REF_USED],
[RELEASE_FLAG],
[REPLACE_QTY],
[ROA],
[RX_NUMBER],
[RXF_CON_ID],
[RXF_ORD_CODE],
[RXF_ORD_ID],
[RXF_ORD_ORDER_NUM],
[RXF_ORD_TYPE],
[SCH_ID],
[SCRIPTTYPE],
[SHORT_TERM_FLAG],
[SIG],
[SIG_PRN_FLAG],
[SPLIT_ID],
[ST_RX_SERIAL_NUM],
[STOCK_FLAG],
[SYS_DATE],
[SYS_TIME],
[SYS_USR_ID],
[TOT_QTY_DUE],
[UNEVEN_DOSE_FLAG],
[VC_RPH_SYS_DATE],
[VC_RPH_SYS_TIME],
[VC_RPH_USR_ID],
[VC_TECH_SYS_DATE],
[VC_TECH_SYS_TIME],
[VC_TECH_USR_ID]
)
select
NULL, --ACT_REF_USED
' ', --DAW
NULL, --DAYS_SUPPLY
NULL, --DC_DATE
'F', --DC_FLAG
NULL, --DC_REA_ID
NULL, --DISCARD_DATE
'F', --DISTRIBUTION_FLAG
NULL, --DLY_QTY
DOC_ID, --DOC_ID
DRG_ID, --DRG_ID
'F', --EPCS_FLAG
EXP_DATE, --EXP_DATE
'T', --EXPAND_SIG_FLAG
NULL, --EXPANDED_ALT_SIG
NULL, --EXPANDED_SIG
NULL, --FIL_ID
FILLS_ALLOWED, --FILLS_ALLOWED
ORG_DATE, --FIRST_ORG_DATE
ID, --ID
LAST_FILL, --LAST_FIL
'F', --MAR_PRINT_FLAG
NULL, --NEW_RXF_ID
NULL, --NEW_RXF_ORD_ID
'S', --NEXT_FIL_TYPE
NULL, --NFR_ID
NULL, --NM9_ID
NULL, --OLD_RXF_ID
NULL, --ORD_DATE
NULL, --ORDER_NUMBER
ORG_DATE, --ORG_DATE
' ', --ORIGIN
PAT_ID, --PAT_ID
1, --PHR_ID
'F', --PRN_FLAG
NULL, --QTY_DOSE
QTY_DUE, --QTY_DUE
NULL, --QTY_RETURNED
NULL, --QTY_USED
NULL, --REF_DAYS_SUPPLY
NULL, --REF_LEFT
NULL, --REF_QTY
NULL, --REF_USED
'F', --RELEASE_FLAG
NULL, --REPLACE_QTY
'  ', --ROA
RX_NUMBER, --RX_NUMBER
NULL, --RXF_CON_ID
NULL, --RXF_ORD_CODE
NULL, --RXF_ORD_ID
NULL, --RXF_ORD_ORDER_NUM
NULL, --RXF_ORD_TYPE
NULL, --SCH_ID
'N', --SCRIPTTYPE
'F', --SHORT_TERM_FLAG
NULL, --SIG
'F', --SIG_PRN_FLAG
NULL, --SPLIT_ID
NULL, --ST_RX_SERIAL_NUM
'F', --STOCK_FLAG
SYS_DATE, --SYS_DATE
SYS_TIME, --SYS_TIME
1, --SYS_USR_ID
NULL, --TOT_QTY_DUE
'F', --UNEVEN_DOSE_FLAG
NULL, --VC_RPH_SYS_DATE
NULL, --VC_RPH_SYS_TIME
NULL, --VC_RPH_USR_ID
NULL, --VC_TECH_SYS_DATE
NULL, --VC_TECH_SYS_TIME
NULL --VC_TECH_USR_ID
FROM 
(
	SELECT
	PF.ID,
	replace(ltrim(replace(pf.[Rx Number], '0', ' ')), ' ', '0') as RX_NUMBER,
	(Select replace(ltrim(replace(pf.[Refills Auth], '0', ' ')), ' ', '0') where (replace(ltrim(replace(pf.[Refills Auth], '0', ' ')), ' ', '0')) > 0) + 1 AS FILLS_ALLOWED,
	pf.[Refills Rem] + 1 as REF_LEFT,
	(select pf.[Date Written] where isdate(pf.[Date Written]) = 1)  as ORD_DATE,
	isnull((select pf.[Rx Stop Date] where isdate(pf.[Rx Stop Date]) = 1), (select convert(datetime, pf.[Date Entered]) + 365 where isdate(pf.[date entered]) = 1))  as EXP_DATE,
	pf.[Rx Sig Code] as SIG,
	(select pf.[Rx# Original Date] where isdate(pf.[Rx# Original Date]) = 1)  as ORG_DATE,
	replace(replace(pf.[Total Qty Remain], ',', ''), '"', '') as QTY_DUE,
	(select pf.[Date Entered] where isdate(pf.[Date Entered]) = 1)  as LAST_FILL,
	isnull((select pf.[Date Entered] where isdate(pf.[Date Entered]) = 1), getdate())  as SYS_DATE,
	Ff.[TIME.Of.Fill] as SYS_TIME,
	PAT.ID AS PAT_ID,
	DOC.ID AS DOC_ID,
	DRG.ID AS DRG_ID
	From qs1.dbo.fills as pf
	LEFT OUTER JOIN PAT on (PAT.ACCT_NUMBER = pf.[Patient Code])
	LEFT OUTER JOIN QS1.dbo.doctor on (Doctor.name = pf.[Doctor Name(50)])
	LEFT OUTER join DOC on( DOC.ID = Doctor.ID)
	LEFT OUTER join DRG on (DRG.FORMATTED_NDC=pf.[NDC Nbr])
	LEFT OUTER join qs1.dbo.fills as ff on (ff.id = (SELECT Min(fills.ID) FROM QS1.dbo.Fills where fills.[Rx Number] = pf.[Rx Number]))	
	WHERE pf.ID IN (SELECT MAX(fills.ID) FROM QS1.dbo.Fills GRoup by fills.[Rx Number])
) AS QS1RXF

