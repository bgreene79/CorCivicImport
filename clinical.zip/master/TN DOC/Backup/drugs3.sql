Create TAble Drugs
(
	NAME varchar(100),
	NDC  varchar(13)
);

BULK INSERT Drugs  
   FROM 'C:\QS12CIPS\Data\Drugs.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
