alter table drg alter column label_name varchar(50) null

UPDATE DRG SET LABEL_NAME = isnull(label_name, drg.dname),
DNAME = med.dnAME,
STRENGTH = NDC.STRENGTH,
DOS_ID = NDC.DOSAGE,
DEA = MED.DEA,
GENERIC_FLAG = med.DGENERIC,
ROA = MED.ROA,
brand = b.dname
FROM drg  
JOIN NDC ON NDC.NDC = drg.formatted_ndc
JOIN Med on DDID = med.id
JOIN med as b on b.gpi = ndc.gpi and b.DGENERIC = case med.'DGENERIC' when 'F' then 'T' else 'F' end

select label_name, drg.dname, generic_Flag, brand as sub_for, strength, dos_id, ndc, dea, gpi, pur_qty, awp_Cost, man.ABB as man_abbrev, man.DNAME as manufacturer from drg
left outer join man on substring(ndc, 1, 5) = right( '0000' + man.id, 5)