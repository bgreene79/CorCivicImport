/*
@Table           Abbreviation
@Usage           Used to resolve Sig Codes entered during Script Filling
@Category        Abbreviation
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ABB
(
    ID                   INTEGER NOT NULL,                       /* Short Abbreviation Identifier */
    PHR_ID               INTEGER,                                /* Internal ID */
    DCODE                VARCHAR(10) NOT NULL,                   /* Short Abbreviation Identifier */
    DOSES                DECIMAL(10,4),                          /* Number of DOSES for Abbreviation */
    DAY_DOSE             DECIMAL(10,4),                          /* Days Per Dose (How Long each Dose Lasts) */
    QTY_DOSE             DECIMAL(10,4),                          /* Quantity per Dose (Number of Pills to Take) */
    DTEXT                VARCHAR(255),                           /* Expanded Language of Directions */
    UNEVEN_DOSE_FLAG     CHAR(1) NOT NULL,                       /* Dosage Varies */
    REMOTE_FLAG          CHAR(1) NOT NULL,                       /* Use this abbreviation in CIPS Remote */
    SCH_ID               INTEGER,                                /* Link To A Schedule */

    CONSTRAINT PK_ABB PRIMARY KEY (ID)
);


/*
@Table           Abbreviation Language
@Usage           Resolves Sig Codes to Various Languages
@Category        Abbreviation
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.ABL
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    ABB_ID               INTEGER NOT NULL,                       /* Abbreviation Id */
    LANG                 CHAR(1) NOT NULL,                       /* Language this Resolves to */
    DTEXT                VARCHAR(255),                           /* Descriptive Text */

    CONSTRAINT PK_ABL PRIMARY KEY (ID)
);


/*
@Table           Adverse Drug Effects
@Usage           Stores Adverse Drug Effects
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        GPI_CODE,MED_CODE,ADV_CODE
*/

CREATE TABLE dbo.ADV
(
    GPI_CODE             VARCHAR(14) NOT NULL,                   /* GPI Code */
    RESERVE_1            VARCHAR(4),                             /* Reserve 1 */
    MED_CODE             INTEGER NOT NULL,                       /* Medical Condition Restriction Code */
    ADV_CODE             INTEGER NOT NULL,                       /* Adverse Effect Code */
    SEV_LEVEL            INTEGER,                                /* Severity Level */
    ONSET_LEVEL          INTEGER,                                /* Onset Level */
    INC_LEVEL            INTEGER,                                /* Incidence Level */
    DOC_LEVEL            INTEGER,                                /* Documentation Level */
    TYPE_CODE            INTEGER,                                /* Adverse Effect Type Code */
    RESERVE_2            VARCHAR(21),                            /* Reserve 2 */

    CONSTRAINT PK_ADV PRIMARY KEY (GPI_CODE,MED_CODE,ADV_CODE)
);


/*
@Table           Allergy
@Usage           Stores Medispan Allergy Codes
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.ALC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Description of Allergy */

    CONSTRAINT PK_ALC PRIMARY KEY (ID)
);


/*
@Table           Allergy Translation
@Usage           Translates Customer Allergy Codes to Allergy ID's for Medispan
@Category        Interface
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.ALC_TRN
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Allergy Translate Record */
    DNAME                VARCHAR(255) NOT NULL,                  /* Description Name of Allergy from Old System */
    TRANSLATE_FROM       VARCHAR(255) NOT NULL,                  /* Allergy Code from Old System */
    TSK_ID               INTEGER NOT NULL,                       /* TSK Internal ID */
    PAR_ID               INTEGER,                                /* PAR Internal ID */
    ALC_ID               INTEGER,                                /* ALC Internal ID */
    MED_ID               INTEGER,                                /* Med Master(Drug) Internal ID */
    NHI_ID               INTEGER,                                /* Non-Screened Health Info ID */
    NM9_ID               VARCHAR(10),                            /* NM9 Internal ID */

    CONSTRAINT PK_ALC_TRN PRIMARY KEY (ID)
);


/*
@Table           Auto Refill
@Usage           Stores Auto Refill Batch Information
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ATR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    REP_BEG_TIME         DATETIME,                               /* Report Start Time */
    REP_END_TIME         DATETIME,                               /* Report End Time */
    PRO_BEG_TIME         DATETIME,                               /* Process Start Time */
    PRO_END_TIME         DATETIME,                               /* Process End Time */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Auto Refill was Run */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Auto Refill was Run */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System When Batch was Run */
    CUT_DATE             DATETIME NOT NULL,                      /* Run for Refill Due Records up to this Date */
    CUT_FLAG             CHAR(1) NOT NULL,                       /* Only Prescriptions with Refill Due Records for this Date Will Be Refilled */
    FIL_DATE             DATETIME NOT NULL,                      /* Generated Fill Records Get This Date */
    PHARMACIST           VARCHAR(3),                             /* Rph Initials */
    TECH                 VARCHAR(3),                             /* Tech Initials */
    FAC_LIST             VARCHAR(255),                           /* Facility List */
    GPI_LIST             VARCHAR(255),                           /* GPI List */
    CHG_ID               INTEGER,                                /* Charge Account */
    ROLLBACK_FLAG        CHAR(1) NOT NULL,                       /* Fill Records Generated by this Batch Have Been Removed */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Did not fill for dormant drugs. */
    KOP_A                CHAR(1) NOT NULL,                       /* KOP A */
    KOP_B                CHAR(1) NOT NULL,                       /* KOP B */
    KOP_C                CHAR(1) NOT NULL,                       /* KOP C */

    CONSTRAINT PK_ATR PRIMARY KEY (ID)
);


/*
@Table           Auto Refill Item
@Usage           Stores Auto Refill Batch Item Information
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ATR_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    ATR_ID               INTEGER NOT NULL,                       /* Auto Refill Table ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number within this Batch */
    RXF_ID               INTEGER NOT NULL,                       /* Internal ID from RXF Table */
    FIL_ID               INTEGER NOT NULL,                       /* Internal ID from FIL Table */
    RFD_DATE             DATETIME,                               /* Date in RFD Record */

    CONSTRAINT PK_ATR_ITM PRIMARY KEY (ID)
);


/*
@Table           Auto Refill Discrepancy Item
@Usage           Stores Auto Refill Batch Item Information
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ATR_DSC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    ATR_ID               INTEGER NOT NULL,                       /* Auto Refill Table ID */
    RXF_ID               INTEGER NOT NULL,                       /* Internal ID from RXF Table */
    RFD_DATE             DATETIME,                               /* Date in RFD Record */
    RFD_PAS_ID           VARCHAR(10),                            /* Time in RFD Record */
    DELETED_FLAG         CHAR(1) NOT NULL,                       /* RFD Record Deleted */
    REASON               CHAR(1) NOT NULL,                       /* Reason Not Filled */

    CONSTRAINT PK_ATR_DSC PRIMARY KEY (ID)
);


/*
@Table           Billing Batch
@Usage           Stores Batch Billing Info
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.BIL_BAT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Batch Bill Record */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */
    FAC_LIST             VARCHAR(255),                           /* Facility List */

    CONSTRAINT PK_BIL_BAT PRIMARY KEY (ID)
);


/*
@Table           Controlled Substance Archived Orders
@Usage           Stores Archived Controlled Substance Orders
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CAO
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal Id */
    DTEXT                VARCHAR( MAX ) NOT NULL,                /* Text of EPCS Order */
    DIGEST               VARCHAR( MAX ) NOT NULL,                /* Base-64 Hashed Digest of Order */
    SIGNATURE            VARCHAR( MAX ) NOT NULL,                /* Base-64 Digital Signature */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Inserted */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Inserted */
    RXF_ORD_ID           INTEGER NOT NULL,                       /* Internal ID of the Rx Order associated with this order */

    CONSTRAINT PK_CAO PRIMARY KEY (ID)
);


/*
@Table           Catalog
@Usage           Catalog from a Vendor to Order Drugs
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.CAT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    VEN_ID               INTEGER NOT NULL,                       /* Vendor Internal Id */
    ITEM_NO              VARCHAR(15),                            /* Vendor Assigned Item Number */
    GPI                  VARCHAR(25),                            /* Drug GPI Code */
    NDC                  VARCHAR(13),                            /* Drug NDC */
    DTEXT                VARCHAR(50),                            /* Free Text Name */
    PUR_QTY              DECIMAL(10,4),                          /* Purchase Quantity */
    MIN_ORD              DECIMAL(10,4),                          /* Minimum Order Amount */
    CONTRACT_COST        DECIMAL(10,4),                          /* Contract Cost */
    ACQ_COST             DECIMAL(10,4),                          /* Acquisition Cost */
    SPEC_COST            DECIMAL(10,4),                          /* Special Cost */
    AWP_COST             DECIMAL(10,4),                          /* Average Wholesale Price */
    WAC_COST             DECIMAL(10,4),                          /* Wholesale Acquisition Cost */
    DATE_CHANGE          DATETIME,                               /* Date Cost Last Changed */
    CAT_EXP              DATETIME,                               /* Information Expiration Date */
    BEG_DATE             DATETIME,                               /* Date Contract Begins */
    END_DATE             DATETIME,                               /* Date Contract Ends */
    OTC_FLAG             CHAR(1) NOT NULL,                       /* Over The Counter */
    GENERIC_FLAG         CHAR(1) NOT NULL,                       /* Drug is Generic */
    REPACK_FLAG          CHAR(1) NOT NULL,                       /* Drug is/can be?? Repackable */
    USE_IN_ORDER_FLAG    CHAR(1) NOT NULL,                       /* Use Catalog in Orders */
    USE_UPCHARGE_FLAG    CHAR(1) NOT NULL,                       /* Use Vendor Upcharge */
    PACK_CODE            VARCHAR(4),                             /* Packaging Code */
    UPC                  VARCHAR(13),                            /* Universal Product Code */
    DEA                  CHAR(1),                                /* DEA Code */
    WHL_SIZE             VARCHAR(8),                             /* Amerisource - Unit of Issue */

    CONSTRAINT PK_CAT PRIMARY KEY (ID)
);


/*
@Table           Change Log Controlling
@Usage           Stores which Tables are Logged
@Category        Logging
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CHC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    TABLE_NAME           VARCHAR(7) NOT NULL,                    /* Table that is Logged */
    LOG_ENABLE_FLAG      CHAR(1) NOT NULL,                       /* T/F Logging is Enabled for this Table */

    CONSTRAINT PK_CHC PRIMARY KEY (ID)
);


/*
@Table           Charge Account
@Usage           Stores Billing Information for Patients
@Category        Billing
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DCODE
*/

CREATE TABLE dbo.CHG
(
    ID                   INTEGER NOT NULL,                       /* Charge Internal Id */
    DCODE                VARCHAR(10) NOT NULL,                   /* Charge Account Code */
    DNAME                VARCHAR(30) NOT NULL,                   /* Charge Account Name */
    CYCLE_OVERRIDE       CHAR(1) NOT NULL,                       /* Override Facility Cycle Settings */
    CYCLE_TYPE           CHAR(1) NOT NULL,                       /* System for Handling Cycle Filling */
    CYCLE_START_DATE     DATETIME,                               /* Date the Filling Cycle is to Start */
    CYCLE_BEGIN_BUFFER   INTEGER,                                /* Number of Days Buffer to Figure Original Fill Quantity for Cycle */
    CYCLE_END_BUFFER     INTEGER,                                /* Number of Days Buffer to Figure Last Fill Quantity for Cycle */
    REFILL_DUE_FLAG      CHAR(1) NOT NULL,                       /* Will Refill Due Records Be Generated For This Facility? */
    RFD_TYPE             CHAR(1) NOT NULL,                       /* CIPS Will Generate Refill Due Records For This Type of Script... */
    DC_TRUNC_FLAG        CHAR(1) NOT NULL,                       /* Truncate Qty on DC */

    CONSTRAINT PK_CHG PRIMARY KEY (ID)
);


/*
@Table           Charge Third Party
@Usage           Logic for whether a drug should be submitted to third party
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FAC_CHG_ID,SEQ_NUM
*/

CREATE TABLE dbo.CHG_THP
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    FAC_CHG_ID           INTEGER NOT NULL,                       /* Facility Charge Internal */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number */
    ACTION               CHAR(1),                                /* If the Criteria is Met, Apply This Action */
    GPI                  VARCHAR(25),                            /* Criteria: GPI */

    CONSTRAINT PK_CHG_THP PRIMARY KEY (ID)
);


/*
@Table           Charge Translation
@Usage           Translates Charge Codes for Interfaces
@Category        Interface
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TSK_ID,TRANSLATE_FROM,CHG_ID
*/

CREATE TABLE dbo.CHG_TRN
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Charge Translate Record */
    TSK_ID               INTEGER NOT NULL,                       /* TSK Internal */
    TRANSLATE_FROM       VARCHAR(10) NOT NULL,                   /* Allergy Code from Old System */
    CHG_ID               INTEGER NOT NULL,                       /* Charge Account Internal Id */

    CONSTRAINT PK_CHG_TRN PRIMARY KEY (ID)
);


/*
@Table           Change Log (Individual)
@Usage           Used to Log Changes to a Field
@Category        Logging
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CHL_ID,FIELD_NAME
*/

CREATE TABLE dbo.CHI
(
    CHL_ID               INTEGER NOT NULL,                       /* CHL Internal ID */
    FIELD_NAME           VARCHAR(100) NOT NULL,                  /* Name of Field to be Logged */
    OLD_VALUE            VARCHAR(255),                           /* Value before it was Changed */
    NEW_VALUE            VARCHAR(255),                           /* New Value it was Changed to */

    CONSTRAINT PK_CHI PRIMARY KEY (CHL_ID,FIELD_NAME)
);


/*
@Table           Change Log (Base)
@Usage           Stores Logging Base Records
@Category        Logging
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CHL
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */
    TABLE_NAME           VARCHAR(60),                            /* Table that Changed */
    RECORD_KEY           VARCHAR(64),                            /* ID of Record Changed */
    RECORD_TEXT          VARCHAR(64),                            /* Text of Record Changed */
    PROCESS              CHAR(1),                                /* What process user was in when transaction took place */
    LOGTYPE              CHAR(1) NOT NULL,                       /* Transaction type ( Insert, Edit, etc... ) */
    PAT_ID               INTEGER,                                /* Internal ID of the Patient associated with the Record that was Logged */
    PROG_VERSION         VARCHAR(12),                            /* The Version Cips was on when this Logged */
    PCT_ID               INTEGER,                                /* Terminal ID */
    PRT_ID               INTEGER,                                /* Printer */

    CONSTRAINT PK_CHL PRIMARY KEY (ID)
);


/*
@Table           Approval
@Usage           Stores Approval to fill Scripts
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CON
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Consent */
    DCODE                VARCHAR(8) NOT NULL,                    /* Descriptive Short Code */
    DTEXT                VARCHAR(60),                            /* Descriptive Text */
    NUM_DAYS             INTEGER,                                /* Number of Days Consent is Good for */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* T/F Consent is Dormant */
    GPI_FLAG             CHAR(1) NOT NULL,                       /* Approve By 12 digits GPI */
    REQUIRED_FLAG        CHAR(1) NOT NULL,                       /* Used on drugs that always require consent */
    SOMETIMES_FLAG       CHAR(1) NOT NULL,                       /* Used on drugs that sometimes require consent */
    EMERGENCY_FLAG       CHAR(1) NOT NULL,                       /* Requires additional approval */
    DENIAL_FLAG          CHAR(1) NOT NULL,                       /* This is a denial option */
    DENIAL_REA_ID        VARCHAR(8),                             /* Reason For Denial */

    CONSTRAINT PK_CON PRIMARY KEY (ID)
);


/*
@Table           Consent Queue
@Usage           Consent Queue
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_CON_ID
*/

CREATE TABLE dbo.CON_QUE
(
    RXF_CON_ID           INTEGER NOT NULL,                       /* Consent Internal ID */
    QUE_ID               INTEGER NOT NULL,                       /* Queue Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    STATUS               CHAR(1),                                /* Status of the Consent in the Queue */
    LOCKED_FLAG          CHAR(1) NOT NULL,                       /* Shows Whether this Record is Currently in Use */
    USR_ID               INTEGER,                                /* User Who Has The Record Locked */

    CONSTRAINT PK_CON_QUE PRIMARY KEY (RXF_CON_ID)
);


/*
@Table           CR9 - Medispan Condition Code
@Usage           Stores Medispan Condition Codes
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CR9
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    ICD9                 VARCHAR(20),                            /* ICD9 Code */

    CONSTRAINT PK_CR9 PRIMARY KEY (ID)
);


/*
@Table           Drug Card
@Usage           Drug Card Descriptions
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DCODE
*/

CREATE TABLE dbo.CRD
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    DCODE                VARCHAR(8) NOT NULL,                    /* Short Description Of Card Type */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Longer Description Of Card Type */
    NUM_UNITS            INTEGER NOT NULL,                       /* How Many Pills Go On The Card */

    CONSTRAINT PK_CRD PRIMARY KEY (ID)
);


/*
@Table           Court
@Usage           Court
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CRT
(
    ID                   INTEGER NOT NULL,                       /* ID */
    DCODE                VARCHAR(10) NOT NULL,                   /* Short Code */
    DTEXT                VARCHAR(50) NOT NULL,                   /* Description */

    CONSTRAINT PK_CRT PRIMARY KEY (ID)
);


/*
@Table           Court Med Pass
@Usage           Connects Court Dates with Times
@Category        Schedule
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CRT_PAS
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    CRT_ID               INTEGER NOT NULL,                       /* Court Internal ID */
    PAS_ID               VARCHAR(10) NOT NULL,                   /* Med Pass Internal ID */

    CONSTRAINT PK_CRT_PAS PRIMARY KEY (ID)
);


/*
@Table           Controlled Substance Audit
@Usage           Stores Controlled Substance Logging Records
@Category        Logging
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CSA
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal Id */
    OS_PC_NAME           VARCHAR(64) NOT NULL,                   /* Computer Name (from Operating System) */
    OS_USR_NAME          VARCHAR(64) NOT NULL,                   /* User Name (from Operating System) */
    SYS_USR_ID           INTEGER,                                /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */
    PROGRAM_TYPE         CHAR(1),                                /* Program Type (CIPS, CIPS REMOTE, etc) */
    AUDIT_TYPE           CHAR(1) NOT NULL,                       /* Audit transaction type ( Insert, Edit, etc... ) */
    CHL_ID               INTEGER,                                /* Internal ID of the Change Log associated with the audit record */
    RXF_ORD_ID           INTEGER,                                /* Internal ID of the Rx Order associated with the audit record */
    CSO_ID               INTEGER,                                /* Internal ID of the Controlled Substance Order associated with the audit record */
    DTEXT                VARCHAR( MAX ),                         /* Additional Audit Information */

    CONSTRAINT PK_CSA PRIMARY KEY (ID)
);


/*
@Table           Controlled Substance Orders
@Usage           Pending CS Orders
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CSO
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal Id */
    STATUS               CHAR(1) NOT NULL,                       /* Status of Controlled Substance Order */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    LOCKED_FLAG          CHAR(1) NOT NULL,                       /* Shows Whether this Record is Currently in Use */
    PAT_ID               INTEGER,                                /* Patient Internal ID */
    PAT_LNAME            VARCHAR(20),                            /* Patient's Last Name */
    PAT_FNAME            VARCHAR(20),                            /* Patient's First Name */
    PAT_MNAME            VARCHAR(10),                            /* Patient's Middle Name */
    PAT_ADDRESS1         VARCHAR(30),                            /* Address Line 1 */
    PAT_ADDRESS2         VARCHAR(30),                            /* Address Line 2 */
    PAT_CITY             VARCHAR(20),                            /* City */
    PAT_ST               VARCHAR(2) NOT NULL,                    /* State */
    PAT_ZIP              VARCHAR(11),                            /* Zip Code */
    DOC_ID               INTEGER,                                /* Doctor Internal ID */
    DOC_LNAME            VARCHAR(20) NOT NULL,                   /* Doctor Last Name */
    DOC_FNAME            VARCHAR(20),                            /* Doctor First Name */
    DOC_MNAME            VARCHAR(10),                            /* Doctor Middle Name */
    DOC_DEA              VARCHAR(9),                             /* DEA (Assigned By Government) */
    DOC_ADDRESS1         VARCHAR(30),                            /* Address 1 */
    DOC_ADDRESS2         VARCHAR(30),                            /* Address 2 */
    DOC_CITY             VARCHAR(20),                            /* City */
    DOC_ST               VARCHAR(2) NOT NULL,                    /* State */
    DOC_ZIP              VARCHAR(10),                            /* Zip Code */
    DRG_ID               INTEGER,                                /* Drug IDs for Involved Drugs */
    DRG_NAME             VARCHAR(30),                            /* Drug Name */
    DRG_STRENGTH         VARCHAR(12),                            /* Drug Strength */
    DRG_DOSAGE           VARCHAR(8),                             /* Drug Dosage */
    RXF_ORD_DATE         DATETIME,                               /* Rx Order Date */
    RXF_ORG_DATE         DATETIME NOT NULL,                      /* Rx Original Date */
    RXF_EXP_DATE         DATETIME NOT NULL,                      /* Rx Expiration Date */
    RXF_QTY_DOSE         DECIMAL(10,4),                          /* Quantity Per Dose of Meds */
    RXF_DLY_QTY          DECIMAL(10,4),                          /* Quantity Taken per Day */
    RXF_PRN_FLAG         CHAR(1) NOT NULL,                       /* Is This A PRN Script? */
    RXF_FILLS_ALLOWED    INTEGER,                                /* Refills Authorized for PRN */
    RXF_DAW              CHAR(1),                                /* Dispense Orders */
    RXF_ROA              VARCHAR(2) NOT NULL,                    /* Route of Administration */
    RXF_RELEASE_FLAG     CHAR(1) NOT NULL,                       /* When Patient is Released, does this med go with him/her? */
    RXF_SIG              VARCHAR(510),                           /* Directions for Script */
    RXF_EXPANDED_SIG     VARCHAR(510),                           /* Expanded SIG */
    RXF_EXPANDED_ALT_SIG VARCHAR(510),                           /* Expanded Alternate Language SIG */
    RXF_SIG_PRN_FLAG     CHAR(1) NOT NULL,                       /* T/F SIG is PRN */
    RXF_DAYS_SUPPLY      INTEGER,                                /* Days Supply for Order */
    RXF_TOT_QTY_DUE      DECIMAL(10,4),                          /* Quantity Due For Order */
    RXF_ORG_TOT_QTY      DECIMAL(11,5),                          /* Original Quantity Requested in Order */
    RXF_ORDER_TYPE       CHAR(1) NOT NULL,                       /* Order Type */
    RXF_SCH_ID           INTEGER,                                /* Schedule Internal ID */
    NM9_ID               VARCHAR(10),                            /* Order Diagnosis */
    FIL_DEA              CHAR(1),                                /* DEA Number */
    FIL_AUTH_NOTE        VARCHAR(30),                            /* Authorization Comment Field */
    FIL_KOP              CHAR(1),                                /* How The Pills Are Given To The Patient */
    FIL_CHG_ID           INTEGER,                                /* Charge Internal ID */
    FIL_PRI_ID           INTEGER,                                /* Priority Level For This Fill */
    PROFILE_FLAG         CHAR(1) NOT NULL,                       /* Dispense 0 Qty Right Now */
    SUP_DOC_ID           INTEGER,                                /* Supervising Doctor Internal ID */
    VIS_ID               INTEGER,                                /* Visit Internal Id */
    RXF_CON_ID           INTEGER,                                /* Consent ID */
    RXF_ID               INTEGER,                                /* Rx Internal ID */
    OLD_RXF_ID           INTEGER,                                /* Old Script Internal ID */
    NOTE_TITLE           VARCHAR(30),                            /* Order Note Title */
    DNOTE                VARCHAR( MAX ),                         /* Order Note */
    ERR_MESSAGE          VARCHAR(60),                            /* Received Failed Error Message */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Record Entry */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    VOID_REA_ID          VARCHAR(8),                             /* Reason ID of Void Order */
    VOID_SYS_USR_ID      INTEGER,                                /* User ID who Voided Record */
    VOID_SYS_DATE        DATETIME,                               /* Date Record was Voided */
    VOID_SYS_TIME        DATETIME,                               /* Time Record was Voided */
    VOID_VIS_ID          INTEGER,                                /* Visit Internal Id */
    TRAN_SYS_USR_ID      INTEGER,                                /* User ID who Transmitted Record */
    TRAN_SYS_DATE        DATETIME,                               /* Date Record was Transmitted */
    TRAN_SYS_TIME        DATETIME,                               /* Time Record was Transmitted */
    SI_FLAG              CHAR(1) NOT NULL,                       /* Signature Indicator Flag */
    DTEXT                VARCHAR( MAX ),                         /* Text for EPCS Order */
    DTEXT_HASH           VARCHAR( MAX ),                         /* Base-64 Hashed Digest of Order */
    SIGNATURE            VARCHAR( MAX ),                         /* Base-64 Digital Signature */
    SIGNED_USR_ID        INTEGER,                                /* User Who Signed the Prescription */
    SIGNED_SYS_DATE      DATETIME,                               /* Date of Signing of Prescription */
    SIGNED_SYS_TIME      DATETIME,                               /* Time of Signing of Prescription */

    CONSTRAINT PK_CSO PRIMARY KEY (ID)
);


/*
@Table           CS Queue
@Usage           Controlled Substance Queue
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CSO_ID
*/

CREATE TABLE dbo.CSO_QUE
(
    CSO_ID               INTEGER NOT NULL,                       /* Controlled Substance Internal ID */
    QUE_ID               INTEGER NOT NULL,                       /* Queue Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    STATUS               CHAR(1),                                /* Status of the Consent in the Queue */
    LOCKED_FLAG          CHAR(1) NOT NULL,                       /* Shows Whether this Record is Currently in Use */
    USR_ID               INTEGER,                                /* User Who Has The Record Locked */

    CONSTRAINT PK_CSO_QUE PRIMARY KEY (CSO_ID)
);


/*
@Table           Custom Settings
@Usage           Custom Table Settings
@Category        System
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TABLE_NAME
*/

CREATE TABLE dbo.CST
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    TABLE_NAME           VARCHAR(30) NOT NULL,                   /* Name of the Table */

    CONSTRAINT PK_CST PRIMARY KEY (ID)
);


/*
@Table           Custom Settings Item
@Usage           Custom Table Item Settings
@Category        System
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CST_ID,FIELD_NAME
*/

CREATE TABLE dbo.CST_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    CST_ID               INTEGER NOT NULL,                       /* Internal ID of parent Record */
    FIELD_NAME           VARCHAR(60) NOT NULL,                   /* Field within the Table */
    TITLE                VARCHAR(255),                           /* Custom Title */
    NOTE                 VARCHAR(255),                           /* Custom Note */
    HINT                 VARCHAR(255),                           /* Custom Hint */
    DLENGTH              INTEGER,                                /* Maximum Length of Field ( Excluding Decimals ) */
    DECIMALS             INTEGER,                                /* Maximum Number of Places After the Decimal Point */
    DEFAULT_VALUE        VARCHAR(255),                           /* Default Value */
    SHOW_IT              CHAR(1) NOT NULL,                       /* Whether the field will show */
    EDIT_CASE            CHAR(1) NOT NULL,                       /* Field will be forced to the specified case ( Only Applies to Edit Boxes ) */
    REQUIRED             CHAR(1) NOT NULL,                       /* Is Information Required in the Field? (R)equired,(D)efaults to DataDictionary */

    CONSTRAINT PK_CST_ITM PRIMARY KEY (ID)
);


/*
@Table           Category
@Usage           Stores Categories for Drugs
@Category        Misc
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.CTG
(
    ID                   VARCHAR(8) NOT NULL,                    /* Category Code */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Category Description */

    CONSTRAINT PK_CTG PRIMARY KEY (ID)
);


/*
@Table           Drug Adjustment
@Usage           Drug Inventory Adjustment Batch
@Category        Drug Adjustment
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DAB
(
    ID                   INTEGER NOT NULL,                       /* Batch Internal Id */
    REF_NUMBER           VARCHAR(30) NOT NULL,                   /* Batch Number */
    DTEXT                VARCHAR(60) NOT NULL,                   /* Batch Description */
    ADJ_DATE             DATETIME NOT NULL,                      /* The date the user enters for this drug inventory adjustment */
    DSTATUS              CHAR(1) NOT NULL,                       /* Batch Status */
    USR_ID_STATUS        INTEGER NOT NULL,                       /* Status User ID */
    USR_ID               INTEGER,                                /* User who entered Record */
    SYS_DATE             DATETIME NOT NULL,                      /* Date */
    SYS_TIME             DATETIME NOT NULL,                      /* Time */

    CONSTRAINT PK_DAB PRIMARY KEY (ID)
);


/*
@Table           Drug Adjustment Item
@Usage           Drug Adjustment Batch Item
@Category        Drug Adjustment  Item
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DAB_ID,DRG_ID
*/

CREATE TABLE dbo.DAB_ITM
(
    DAB_ID               INTEGER NOT NULL,                       /* Batch ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug ID */
    ONHAND               DECIMAL(10,4),                          /* New Onhand */
    OLD_ONHAND           DECIMAL(10,4),                          /* Old Onhand */
    ADJUSTED_FLAG        CHAR(1) NOT NULL,                       /* Whether this Drug needs to be adjusted */
    ADJ_COST             DECIMAL(10,4),                          /* Adjusted Cost */
    ONHAND_COST          DECIMAL(10,4),                          /* Onhand Cost */
    OLD_ONHAND_COST      DECIMAL(10,4),                          /* Old Onhand Cost */
    USR_ID               INTEGER,                                /* User who entered Record */
    SYS_DATE             DATETIME NOT NULL,                      /* Date */
    SYS_TIME             DATETIME NOT NULL,                      /* Time */

    CONSTRAINT PK_DAB_ITM PRIMARY KEY (DAB_ID,DRG_ID)
);


/*
@Table           Drug Acquisition Costing
@Usage           Used for Inventory Tracking / Costing
@Category        Logging
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PHR_ID,DRG_ID
*/

CREATE TABLE dbo.DAC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Drug Internal Id */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal Id */
    TRAN_DATE            DATETIME NOT NULL,                      /* Date Inventory Received */
    ORG_QTY              DECIMAL(10,4) NOT NULL,                 /* Original Quantity Entered */
    CUR_QTY              DECIMAL(10,4),                          /* Quantity Left at this Cost */
    UNIT_COST            DECIMAL(10,4),                          /* Unit Acquisition Cost of 1 Unit */
    REF_TYPE             CHAR(1) NOT NULL,                       /* Reference Type */
    REF_NUM              VARCHAR(30),                            /* Reference Number */
    SYS_DATE             DATETIME,                               /* Date of Record Entry */
    SYS_TIME             DATETIME,                               /* Time of Record Entry */
    SYS_USR_ID           INTEGER,                                /* User who Entered Record */

    CONSTRAINT PK_DAC PRIMARY KEY (ID)
);


/*
@Table           Drug Auxiliary
@Usage           Tracks Inventory and Reordering for the Warehouse
@Category        Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID
*/

CREATE TABLE dbo.DAX
(
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal Id */
    PUC_CATEGORY_CODE    VARCHAR(11),                            /* Purchase Category Code */
    ISC_CATEGORY_CODE    VARCHAR(11),                            /* Issue Category Code */
    PUR_AMOUNT           INTEGER,                                /* Amount of Drug Purchased has to be in Multiples of this */
    PUR_AMOUNT_DESC      VARCHAR(15),                            /* Description of the contents of Purchase Amount */
    ISSUE_AMOUNT         INTEGER,                                /* Amount of Drug has to be Issued in Multiples of this */
    ISSUE_AMOUNT_DESC    VARCHAR(15),                            /* Description of the contents of Issue Amount */
    DISP_UNIT_DESC       VARCHAR(15),                            /* Description of the Base Units (Tabs,Caps) */
    MIN_DAY_SUP_ONHAND   INTEGER,                                /* Minimum Day Supply Onhand, Used if Requisitioning by Daily Usage */
    MAX_DAY_SUP_ONHAND   INTEGER,                                /* Maximum Day Supply Onhand, Used if Requisitioning by Daily Usage */
    MIN_QTY_ONHAND       INTEGER,                                /* Minimum Quantity Onhand, Used if Requisitioning by Static Inventory Levels */
    MAX_QTY_ONHAND       INTEGER,                                /* Maximum Quantity Onhand, Used if Requisitioning by Static Inventory Levels */
    MIN_SHIP_AMT         INTEGER,                                /* Minimum Amount of Drug that can be Shipped when Requisitioned */
    MAX_SHIP_AMT         INTEGER,                                /* Maximum Amount of Drug that can be Shipped when Requisitioned */
    QTY_ONHAND           INTEGER,                                /* Quantity Onhand */
    QTY_ONORDER          INTEGER,                                /* Quantity On Order */
    ACQ_COST             DECIMAL(10,4),                          /* Cost to the Warehouse to Purchase this Drug */
    SHELF_LOC            VARCHAR(20),                            /* Warehouse Location of Drug */
    REORDER_MODE         CHAR(1) NOT NULL,                       /* Mode to Reorder - (D)aily Average Use,(S)tatic Inventory,(N)o Reordering */

    CONSTRAINT PK_DAX PRIMARY KEY (DRG_ID)
);


/*
@Table           Drug DEA
@Usage           Matches Drug GPI to DEA Schedules
@Category        Drug DEA
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DEA
(
    ID                   INTEGER NOT NULL,                       /* Drug DEA Identifier */
    GPI                  VARCHAR(25),                            /* Drug GPI */
    DEA                  CHAR(1),                                /* DEA Schedule */
    ST                   VARCHAR(2) NOT NULL,                    /* State Where Housing Facility Is Located */

    CONSTRAINT PK_DEA PRIMARY KEY (ID)
);


/*
@Table           Drug Check
@Usage           Warns Pharmacist on various combinations of Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DCODE,DCOUNTER
*/

CREATE TABLE dbo.DCK
(
    DCODE                VARCHAR(6) NOT NULL,                    /* Code to Group Drugs for Checking */
    DCOUNTER             INTEGER NOT NULL,                       /* Positioning of Drug in this Group (1,2,3,etc.) */
    DRG_ID               INTEGER,                                /* Drug Internal ID */
    GPI                  VARCHAR(16),                            /* GPI Code */
    DTYPE                CHAR(1) NOT NULL,                       /* Method of Identifying Drug for comparison - (D)rug, (G)PI */
    NUM_DRG_WARN         INTEGER,                                /* # of Drugs Patient has to be on in this Group to warn Pharmacist */
    DTEXT                VARCHAR(30),                            /* Descriptive Text of this Group */

    CONSTRAINT PK_DCK PRIMARY KEY (DCODE,DCOUNTER)
);


/*
@Table           Discontinued Med
@Usage           Table tracks Scripts that are Discontinued
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DCM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    RXF_ID               INTEGER NOT NULL,                       /* RXF Internal Id */
    REA_ID               VARCHAR(8) NOT NULL,                    /* Reason Internal Id */
    USR_ID               INTEGER NOT NULL,                       /* User Internal Id */
    VIS_ID               INTEGER,                                /* Visit Internal Id */
    DC_DATE              DATETIME NOT NULL,                      /* Discontinued Date */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Entry */

    CONSTRAINT PK_DCM PRIMARY KEY (ID)
);


/*
@Table           Doctor Class Restriction
@Usage           Restricts certain doctors from filling certain drugs
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DOC_ID,DRG_GPI
*/

CREATE TABLE dbo.DCR
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DOC_ID               INTEGER NOT NULL,                       /* Doctor Internal Id */
    DRG_GPI              VARCHAR(25) NOT NULL,                   /* GPI */

    CONSTRAINT PK_DCR PRIMARY KEY (ID)
);


/*
@Table           Doctor Degree Drug Restriction
@Usage           Restricts some degrees from filling certain drugs
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DOC_DEGREE,DRG_GPI
*/

CREATE TABLE dbo.DDR
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DOC_DEGREE           CHAR(1) NOT NULL,                       /* Doctor Degree */
    DRG_GPI              VARCHAR(25) NOT NULL,                   /* GPI */

    CONSTRAINT PK_DDR PRIMARY KEY (ID)
);


/*
@Table           Delivery Item
@Usage           List of Scripts in a Delivery to a Facility
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DEL
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DEL_BAT_ID           INTEGER,                                /* Delivery Batch ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    RXF_ID               INTEGER NOT NULL,                       /* Script Internal ID */
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    VOID_FLAG            CHAR(1) NOT NULL,                       /* T/F Item will not be delivered */
    ERROR_FLAG           CHAR(1) NOT NULL,                       /* T/F Item was not delivered correctly */
    ERROR_DATE           DATETIME,                               /* Date of Record Creation */
    ERROR_TIME           DATETIME,                               /* Time of Record Creation */
    ERROR_USR_ID         INTEGER,                                /* User Logged in During Error */
    PHR_SCAN_FLAG        CHAR(1) NOT NULL,                       /* T/F Item has been scanned by the pharmacy */
    PHR_SCAN_DATE        DATETIME,                               /* Date of Record Creation */
    PHR_SCAN_TIME        DATETIME,                               /* Time of Record Creation */
    PHR_SCAN_USR_ID      INTEGER,                                /* Pharmacy User that Scanned the Delivery */
    PHR_SCAN_NUMBER      INTEGER,                                /* Number of Times Scanned by Pharmacy */
    FAC_SCAN_FLAG        CHAR(1) NOT NULL,                       /* T/F Item has been scanned by the facility */
    FAC_SCAN_DATE        DATETIME,                               /* Date of Record Creation */
    FAC_SCAN_TIME        DATETIME,                               /* Time of Record Creation */
    FAC_SCAN_USR_ID      INTEGER,                                /* Facility User that Scanned the Delivery */
    FAC_SCAN_NUMBER      INTEGER,                                /* Number of Times Scanned by Pharmacy */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */
    SYS_USR_ID           INTEGER NOT NULL,                       /* System User for Delivery */
    PREV_BAT_IDS         VARCHAR(255),                           /* Previous Batch ID's */

    CONSTRAINT PK_DEL PRIMARY KEY (ID)
);


/*
@Table           Delivery Sheet
@Usage           Delivery Sheet Batch
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DEL_BAT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    DEA_FLAG             CHAR(1),                                /* T/F The delivery sheet is for the controlled drugs. */
    PRINT_FLAG           CHAR(1) NOT NULL,                       /* T/F The delivery sheet was printed. */
    PRINT_DATE           DATETIME,                               /* Date of Record Creation */
    PRINT_TIME           DATETIME,                               /* Time of Record Creation */
    PRINT_USR_ID         INTEGER,                                /* User That Printed the Batch */
    EXPORT_FLAG          CHAR(1) NOT NULL,                       /* T/F The delivery sheet was exported. */
    EXPORT_DATE          DATETIME,                               /* Date Exported */
    EXPORT_USR_ID        INTEGER,                                /* User Logged In at Export */
    COMPLETE_FLAG        CHAR(1) NOT NULL,                       /* T/F The facility has finished processing the delivery. */
    COMPLETE_DATE        DATETIME,                               /* Date of Record Creation */
    COMPLETE_TIME        DATETIME,                               /* Time of Record Creation */
    COMPLETE_USR_ID      INTEGER,                                /* User That Completed the Batch */

    CONSTRAINT PK_DEL_BAT PRIMARY KEY (ID)
);


/*
@Table           Drug Grouping
@Usage           Stores Groups of Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        GROUPING
*/

CREATE TABLE dbo.DGP
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    GROUPING             VARCHAR(8) NOT NULL,                    /* Defines a Group of Drugs */
    DTEXT                VARCHAR(30),                            /* Description of the Group */

    CONSTRAINT PK_DGP PRIMARY KEY (ID)
);


/*
@Table           Doctor Degree
@Usage           Used to Setup Presciber Degrees
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DGR
(
    ID                   INTEGER NOT NULL,                       /* Internal Identifier */
    DCODE                VARCHAR(10) NOT NULL,                   /* Degree Identifier */
    DTEXT                VARCHAR(60),                            /* Degree Text */

    CONSTRAINT PK_DGR PRIMARY KEY (ID)
);


/*
@Table           Medical Condition
@Usage           Stores Medical Conditions for Patients
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.DIS
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Description of Medical Condition */

    CONSTRAINT PK_DIS PRIMARY KEY (ID)
);


/*
@Table           Drug Inventory Transaction
@Usage           Used to Track Inventory
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DIT
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal Id */
    PHR_ID               INTEGER,                                /* Pharmacy Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    DAC_ID               INTEGER,                                /* Drug Aquisition Internal ID */
    DRT_COD_ID           INTEGER,                                /* Transaction Internal ID */
    TRAN_DATE            DATETIME NOT NULL,                      /* Date of Transaction */
    TRAN_QTY             DECIMAL(10,4) NOT NULL,                 /* Transaction Qty */
    TRAN_UNIT_COST       DECIMAL(10,4) NOT NULL,                 /* Transaction Unit Cost */
    QTY_ONHAND           DECIMAL(10,4),                          /* Quantity Onhand(Snap Shot) of Warehouse after Transaction */
    REF_TYPE             CHAR(1) NOT NULL,                       /* Reference Type */
    REF_NUM              VARCHAR(30),                            /* Reference Number */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */

    CONSTRAINT PK_DIT PRIMARY KEY (ID)
);


/*
@Table           Drug IV Description
@Usage           Tracks Specific Information for IV's
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID
*/

CREATE TABLE dbo.DIV
(
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    MIN_QTY              DECIMAL(10,4),                          /* Minimum Quantity Dispensed */
    MAX_QTY              DECIMAL(10,4),                          /* Maximum Quantity Dispensed */
    DEFAULT_DSP_QTY      DECIMAL(10,4),                          /* Default Dispense Quantity */
    MIN_RATE             DECIMAL(10,4),                          /* Minimum Dispense Rate */
    MAX_RATE             DECIMAL(10,4),                          /* Maximum Dispense Rate */
    QTY                  DECIMAL(10,4),                          /* Quantity of Drug into Bag */
    VOLUME               DECIMAL(10,4),                          /* Volume of Liquid to go with this Drug in IV */
    QTY_UNIT             CHAR(1) NOT NULL,                       /* Unit of Drug in Bag */
    VOLUME_UNIT          CHAR(1) NOT NULL,                       /* Unit of Liquid to go with this Drug in IV */
    DTYPE                CHAR(1) NOT NULL,                       /* (D)rug,(S)olution */

    CONSTRAINT PK_DIV PRIMARY KEY (DRG_ID)
);


/*
@Table           Doctor
@Usage           Stores vital prescriber information
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        LNAME,FNAME
*/

CREATE TABLE dbo.DOC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    LNAME                VARCHAR(20) NOT NULL,                   /* Doctor Last Name */
    FNAME                VARCHAR(20),                            /* Doctor First Name */
    MNAME                VARCHAR(10),                            /* Doctor Middle Name */
    SNAME                VARCHAR(10),                            /* Short Name For Lookup */
    DEA                  VARCHAR(9),                             /* DEA (Assigned By Government) */
    GROUPING             VARCHAR(8),                             /* Special Grouping Field For Reporting */
    ADDRESS1             VARCHAR(30),                            /* Address 1 */
    ADDRESS2             VARCHAR(30),                            /* Address 2 */
    CITY                 VARCHAR(20),                            /* City */
    ST                   VARCHAR(2) NOT NULL,                    /* State */
    ZIP                  VARCHAR(10),                            /* Zip Code */
    EMAIL                VARCHAR(50),                            /* E-Mail Address */
    PHONE1               VARCHAR(14),                            /* Phone Number 1 */
    PHONE2               VARCHAR(14),                            /* Phone Number 2 */
    FAX                  VARCHAR(20),                            /* Fax Number */
    EXT1                 VARCHAR(4),                             /* Phone Extension 1 */
    EXT2                 VARCHAR(4),                             /* Phone Extension 2 */
    STATE_NUM            VARCHAR(15),                            /* State Assigned Doctor Number */
    SUFFIX               VARCHAR(4),                             /* DEA # Suffix */
    DGR_ID               INTEGER,                                /* Doctor's Degree */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Dormant Doctors Will Not Show Up During Filling */
    DEA_EXP              DATETIME,                               /* This is The Date The Doctor's DEA # Expires */
    STATE_NUM_EXP        DATETIME,                               /* This is The Date The Doctor's State # Expires */
    NPI                  VARCHAR(20),                            /* National Provider */
    STOCK_LIABILITY_FLAG CHAR(1) NOT NULL,                       /* Stock Liability On File */
    CNTRL_LIABILITY_FLAG CHAR(1) NOT NULL,                       /* Controlled Stock Liability On File */
    UPIN                 VARCHAR(20),                            /* Universal Provider ID # */
    TSK_DOC_ID           INTEGER,                                /* SureScripts Doctor record */
    SUP_DOC_ID           INTEGER,                                /* Supervising Doc ID */
    CERTIFICATE_TEXT     VARCHAR( MAX ),                         /* Doctor Signing Certificate */

    CONSTRAINT PK_DOC PRIMARY KEY (ID)
);


/*
@Table           Doctor Facility
@Usage           Links Doctors With Facilities
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DOC_ID,FAC_ID
*/

CREATE TABLE dbo.DOC_FAC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DOC_ID               INTEGER NOT NULL,                       /* Doctor Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    STOCK_LIABILITY_FLAG CHAR(1) NOT NULL,                       /* Stock Liability On File */
    STOCK_EXP_DATE       DATETIME,                               /* Stock License Expiration Date */
    CNTRL_LIABILITY_FLAG CHAR(1) NOT NULL,                       /* Controlled Stock Liability On File */
    CNTRL_EXP_DATE       DATETIME,                               /* Control License Expiration Date */

    CONSTRAINT PK_DOC_FAC PRIMARY KEY (ID)
);


/*
@Table           Doctor Location
@Usage           Links Doctors With SureScript Doctor Locations
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DOC_LOC
(
    ID                   INTEGER NOT NULL,                       /* Doctor Location Identifier */
    DOC_ID               INTEGER NOT NULL,                       /* Doctor Identifier */
    TSK_DOC_ID           INTEGER NOT NULL,                       /* SureScripts Doctor Identifier */

    CONSTRAINT PK_DOC_LOC PRIMARY KEY (ID)
);


/*
@Table           Doctor Logging
@Usage           Log Controlled Scripts The Doctor Has Prescribed
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DOC_LOG
(
    ID                   INTEGER NOT NULL,                       /* Doctor Logging */
    DOC_ID               INTEGER,                                /* Doctor Identifier */
    VIEWED               CHAR(1) NOT NULL,                       /* T/F Report Has Been Viewed */
    DATE_VIEWED          DATETIME,                               /* Date The Report Was Viewed */
    RUN_DATE             DATETIME,                               /* Date The Report Was Run */
    RUN_TIME             DATETIME,                               /* Time The Report Was Run */

    CONSTRAINT PK_DOC_LOG PRIMARY KEY (ID)
);


/*
@Table           Doctor Logging Item
@Usage           Line Items for Logging of Controlled Scripts The Doctor Has Prescribed
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DOC_ITM
(
    ID                   INTEGER NOT NULL,                       /* Doctor Logging Item */
    DOC_LOG_ID           INTEGER NOT NULL,                       /* Doctor Log Report Id */
    DTEXT                VARCHAR( MAX ),                         /* The Line Item */

    CONSTRAINT PK_DOC_ITM PRIMARY KEY (ID)
);


/*
@Table           Doctor Notes
@Usage           Stores unlimited notes tied to doctor
@Category        Doctor
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TITLE
*/

CREATE TABLE dbo.DOC_NOT
(
    ID                   INTEGER NOT NULL,                       /* Doctor Note Internal Id */
    DOC_ID               INTEGER NOT NULL,                       /* Link To Doctor */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Title Of The Note */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* Shows How the Note Was Added */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_DOC_NOT PRIMARY KEY (ID)
);


/*
@Table           Dosage Language
@Usage           Stores Dosage Instructions in Alternate Langauges
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DOS_ID,LANG
*/

CREATE TABLE dbo.DOL
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DOS_ID               VARCHAR(8) NOT NULL,                    /* Dosage Internal ID */
    LANG                 CHAR(1) NOT NULL,                       /* Language Code */
    VERB                 VARCHAR(30),                            /* Verb in Alternate Language */
    DOSAGE               VARCHAR(30),                            /* Dosage in Alternate Language */
    ROUTE                VARCHAR(30),                            /* Route in Aternate Language */

    CONSTRAINT PK_DOL PRIMARY KEY (ID)
);


/*
@Table           Domain
@Usage           Windows Domain
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DOM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DNAME                VARCHAR(255) NOT NULL,                  /* Domain Name from Windows */
    DPATH                VARCHAR(255),                           /* Path for Automatic Updates */

    CONSTRAINT PK_DOM PRIMARY KEY (ID)
);


/*
@Table           Dosage
@Usage           Stores Dosage Instructions
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DOS
(
    ID                   VARCHAR(8) NOT NULL,                    /* Dosage Code */
    VERB                 VARCHAR(30),                            /* Verb to Use (Take) */
    DOSAGE               VARCHAR(30),                            /* Dosage to Use (Tablets) */
    ROUTE                VARCHAR(30),                            /* Route to Use (By Mouth) */
    PILL_FLAG            CHAR(1) NOT NULL,                       /* This dosage is in pill form. */

    CONSTRAINT PK_DOS PRIMARY KEY (ID)
);


/*
@Table           Drug Receive Batch
@Usage           Records Drugs in Batches Received for Inventory
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRB
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    VEN_ID               INTEGER,                                /* Vendor Internal ID */
    REF_NUMBER           VARCHAR(30),                            /* Reference Number */
    DTEXT                VARCHAR(60),                            /* Batch Description */
    STATUS               CHAR(1) NOT NULL,                       /* Open/Closed/Voided */
    RECEIVEDON           DATETIME,                               /* Date Received */
    CREATE_USR_ID        INTEGER NOT NULL,                       /* Create User Internal ID */
    CREATE_SYS_DATE      DATETIME NOT NULL,                      /* Date Batch was Created */
    CREATE_SYS_TIME      DATETIME NOT NULL,                      /* Time Batch was Created */
    CLOSED_USR_ID        INTEGER,                                /* Closed User Internal ID */
    CLOSED_SYS_DATE      DATETIME,                               /* Date Batch was Closed */
    CLOSED_SYS_TIME      DATETIME,                               /* Time Batch was Closed */

    CONSTRAINT PK_DRB PRIMARY KEY (ID)
);


/*
@Table           Drug Receive Batch Item
@Usage           Stores Items for DRB(Drug Receive Batch) Table
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRB_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DRB_ID               INTEGER NOT NULL,                       /* Drug Receive Batch ID */
    SEQUENCE             INTEGER NOT NULL,                       /* Sequence Number */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    NDC                  VARCHAR(11),                            /* NDC */
    PURCHASE             DECIMAL(10,4),                          /* Purchase Quantity */
    AWP_COST             DECIMAL(10,4),                          /* Average Wholesale Price */
    ACQ_COST             DECIMAL(10,4),                          /* Acquisition Cost */
    GEN_COST1            DECIMAL(10,4),                          /* Generic Cost 1 */
    RECEIVED             DECIMAL(10,4),                          /* Received Quantity */
    PUR_UNIT             CHAR(1),                                /* Purchase Unit */
    ITEM_NUMBER          VARCHAR(15),                            /* Item Number */
    MIN_STOCK            DECIMAL(10,4),                          /* Acquisition Cost */
    MAX_STOCK            DECIMAL(10,4),                          /* Acquisition Cost */
    OLD_ONHAND           DECIMAL(10,4),                          /* Old Onhand when Batch Item Updated */
    NEW_ONHAND           DECIMAL(10,4),                          /* New Onhand when Batch Item Updated */
    DRG_UPDATED          CHAR(1) NOT NULL,                       /* Updated */
    USR_ID               INTEGER NOT NULL,                       /* User Internal ID */

    CONSTRAINT PK_DRB_ITM PRIMARY KEY (ID)
);


/*
@Table           Drug Receive Batch Lot
@Usage           Records Drug Lots in Batches Received for Inventory
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRB_ID, DRG_ID, NUMBER
*/

CREATE TABLE dbo.DRB_LOT
(
    DRB_ID               INTEGER NOT NULL,                       /* Drug Receive Batch ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug ID */
    NUMBER               VARCHAR(12) NOT NULL,                   /* Lot Number */
    EXPIRES              DATETIME,                               /* Date */

    CONSTRAINT PK_DRB_LOT PRIMARY KEY (DRB_ID, DRG_ID, NUMBER)
);


/*
@Table           Drug Transaction Batch
@Usage           Records Drug Transaction Batches
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    USR_ID_STATUS        INTEGER NOT NULL,                       /* Status User ID */
    SYS_DATE             DATETIME NOT NULL,                      /* Date */
    SYS_TIME             DATETIME NOT NULL,                      /* Time */
    USR_ID               INTEGER,                                /* User ID */
    REF_NUMBER           VARCHAR(30),                            /* Reference Number */
    DTEXT                VARCHAR(60),                            /* Batch Description */
    TRAN_DATE            DATETIME,                               /* Transaction Date */
    STATUS               CHAR(1) NOT NULL,                       /* Open/Closed/Voided/InUse */

    CONSTRAINT PK_DRT PRIMARY KEY (ID)
);


/*
@Table           Drug Transaction Batch Item
@Usage           Stores Items for Drt(Drug Transaction Batch) Table
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRT_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DRT_ID               INTEGER NOT NULL,                       /* Drug Transaction Batch ID */
    SEQUENCE             INTEGER NOT NULL,                       /* Sequence Number */
    SYS_DATE             DATETIME NOT NULL,                      /* Date */
    SYS_TIME             DATETIME NOT NULL,                      /* Time */
    USR_ID               INTEGER,                                /* User ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    DRT_COD_ID           INTEGER NOT NULL,                       /* Drug Transaction Code ID */
    REASON               VARCHAR(40),                            /* Reason */
    QUANTITY             DECIMAL(10,4),                          /* Quantity */
    UNIT_COST            DECIMAL(10,4),                          /* Unit Cost */
    DRG_ONHAND           DECIMAL(10,4),                          /* Old Onhand when Batch Item Updated */

    CONSTRAINT PK_DRT_ITM PRIMARY KEY (ID)
);


/*
@Table           Drug Transaction Code
@Usage           Stores Drug Transaction Codes
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRT_COD
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    SYS_DATE             DATETIME NOT NULL,                      /* Date */
    SYS_TIME             DATETIME NOT NULL,                      /* Time */
    USR_ID               INTEGER,                                /* User ID */
    SHORT_CODE           VARCHAR(8),                             /* Code */
    DESCRIPTION          VARCHAR(40),                            /* Description */
    TRAN_TYPE            CHAR(1) NOT NULL,                       /* Add/Subtract */

    CONSTRAINT PK_DRT_COD PRIMARY KEY (ID)
);


/*
@Table           Drug Compound
@Usage           Stores Ingredients for Compound Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID,ING_DRG_ID
*/

CREATE TABLE dbo.DRG_CMP
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal */
    ING_DRG_ID           INTEGER NOT NULL,                       /* Ingredient(Drug) Internal [TE] */
    ING_QTY              DECIMAL(10,4),                          /* Ingredient Quantity [ED] */
    STATUS               CHAR(1) NOT NULL,                       /* Status of Item ( P - Primary, S - Secondary ) */

    CONSTRAINT PK_DRG_CMP PRIMARY KEY (DRG_ID,ING_DRG_ID)
);


/*
@Table           Drug
@Usage           Stores Drug Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME,STRENGTH,DOS_ID
*/

CREATE TABLE dbo.DRG
(
    ID                   INTEGER NOT NULL,                       /* Drug Internal Id */
    DNAME                VARCHAR(30) NOT NULL,                   /* Drug Name */
    STRENGTH             VARCHAR(12),                            /* Drug Strength */
    DOS_ID               VARCHAR(8),                             /* Drug Dosage */
    BRAND                VARCHAR(40),                            /* Substitute This Drug For... */
    LABEL_NAME           VARCHAR(25),                            /* Name That Will Print on Label */
    NDC                  VARCHAR(13),                            /* Drug NDC */
    REPACK_NDC           VARCHAR(13),                            /* Repackage NDC Number */
    FORMATTED_NDC        VARCHAR(11),                            /* Formatted NDC Number */
    GPI                  VARCHAR(25),                            /* Drug GPI */
    SNAME                VARCHAR(10),                            /* Drug Short Name */
    UPC                  VARCHAR(25),                            /* Drug Bar Code */
    DEA                  CHAR(1),                                /* Drug DEA */
    BND_DRG_ID           INTEGER,                                /* DRG.ID Brand Drug ID */
    ITEM_NUMBER          VARCHAR(20),                            /* state code for drug */
    LOCATION             VARCHAR(30),                            /* Item Location */
    MAN_ID               INTEGER,                                /* Default manufacturer */
    PRT_ID               INTEGER,                                /* Labels for this Drug print to this Printer.  Facility Label Printer overrides this. */
    SEC_PRT_ID           INTEGER,                                /* Labels with Qty in Multiples of 30 for this Drug print to this Printer.  Facility Label Printer overrides this. */
    DISCARD_DAYS         INTEGER,                                /* Used to set the discard date in the fill record. */
    DEFAULT_DAYS         INTEGER,                                /* Days A Script Will Default To When Filling */
    DEFAULT_DAYS_FAC     CHAR(1) NOT NULL,                       /* Use Value from Facility Table */
    DEFAULT_REF_DAYS     INTEGER,                                /* Days A Script Will Default To When Refilling */
    DEFAULT_REF_DAYS_FAC CHAR(1) NOT NULL,                       /* Use Value from Facility Table */
    NF_DAYS              INTEGER,                                /* Days A Non-Formulary Script Will Default To When Filling */
    NF_DAYS_FAC          CHAR(1) NOT NULL,                       /* Use Value from Facility Table */
    NF_REF_DAYS          INTEGER,                                /* Days A Non-Formulary Script Will Default To When Refilling */
    NF_REF_DAYS_FAC      CHAR(1) NOT NULL,                       /* Use Value from Facility Table */
    NOFORM_DAYS          INTEGER,                                /* Days A Non-Formulary Script Will Default To When Filling Without A Form */
    NOFORM_DAYS_FAC      CHAR(1) NOT NULL,                       /* Use Value from Facility Table */
    NOFORM_REF_DAYS      INTEGER,                                /* Days A Non-Formulary Script Will Default To When Refilling Without A Form */
    NOFORM_REF_DAYS_FAC  CHAR(1) NOT NULL,                       /* Use Value from Facility Table */
    CRD_ID               INTEGER,                                /* Default Drug Card */
    MIN_RTN_QTY          DECIMAL(10,4),                          /* Less Than This Should Not Be Returned To Pharmacy */
    GROUPING             VARCHAR(8),                             /* Special Grouping Field For Reporting */
    CONSENT_REQUIRED     CHAR(1) NOT NULL,                       /* What is the Approval Level for this Drug? */
    AWP_COST             DECIMAL(10,4),                          /* Average Wholesale Price */
    WAC_COST             DECIMAL(10,4),                          /* Wholesale Acquisition Cost */
    ACQ_COST             DECIMAL(10,4),                          /* Acquisition Cost */
    GEN_COST1            DECIMAL(10,4),                          /* Generic Cost */
    DIST_COST            DECIMAL(10,4),                          /* Distribution Cost */
    OLD_AWP_COST         DECIMAL(10,4),                          /* Old Average Wholesale Price */
    OLD_WAC_COST         DECIMAL(10,4),                          /* Old Wholesale Acquisition Cost */
    OLD_ACQ_COST         DECIMAL(10,4),                          /* Old Acquisition Cost */
    OLD_GEN_COST1        DECIMAL(10,4),                          /* Old Generic Cost */
    DNOTE                VARCHAR(50),                            /* Drug Note */
    AWP_DATE             DATETIME,                               /* Date AWP Last Changed */
    WAC_DATE             DATETIME,                               /* Date WAC Last Changed */
    ACQ_DATE             DATETIME,                               /* Date Acquisition Cost Last Changed */
    GEN_DATE1            DATETIME,                               /* Date Generic Cost Last Changed */
    PUR_QTY              DECIMAL(10,4) NOT NULL,                 /* Drug Purchase Quantity */
    OLD_PUR_QTY          DECIMAL(10,4),                          /* Old Drug Purchase Quantity */
    DISPENSE_QTY         DECIMAL(10,4),                          /* Drug Must be Dispensed in Multiples of This */
    DISPENSE_QTY_FLAG    CHAR(1) NOT NULL,                       /* Allow Dispense Qty to be Overridden */
    TER_ID               INTEGER,                                /* NCPDP Unit Code */
    DIS_UNIT             CHAR(1) NOT NULL,                       /* Dispense Units */
    PUR_UNIT             CHAR(1) NOT NULL,                       /* Purchase Units */
    INV_UNIT             CHAR(1) NOT NULL,                       /* Inventory Units */
    ORD_UNIT             CHAR(1) NOT NULL,                       /* Order Units */
    PHARMACY_FLAG        CHAR(1) NOT NULL,                       /* T/F drug is from the pharmacy (normally used) */
    FORMULARY_FLAG       CHAR(1) NOT NULL,                       /* T/F drug is formulary (normally used) */
    FORMULARY_TWO_FLAG   CHAR(1) NOT NULL,                       /* T/F drug is formulary (normally used) */
    GRP_ID               VARCHAR(8),                             /* Group */
    DISPLAY_FLAG         CHAR(1) NOT NULL,                       /* T/F display flag */
    ACQ_UPDATE_FLAG      CHAR(1) NOT NULL,                       /* Do We Update ACQ_COST in General Updates? */
    AWP_UPDATE_FLAG      CHAR(1) NOT NULL,                       /* Do We Update AWP_COST in General Updates? */
    WAC_UPDATE_FLAG      CHAR(1) NOT NULL,                       /* Do We Update WAC_COST in General Updates? */
    GENERIC_FLAG         CHAR(1) NOT NULL,                       /* Flag: Drug is Generic */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Flag: Drug is Dormant */
    MAINTENANCE_FLAG     CHAR(1) NOT NULL,                       /* Flag: Drug is maintained */
    OTC_FLAG             CHAR(1) NOT NULL,                       /* Flag: Drug is  Over the Counter */
    FRIDGE_FLAG          CHAR(1) NOT NULL,                       /* T/F drug needs to be refrigerated */
    SELF_CARRY_FLAG      CHAR(1) NOT NULL,                       /* T/F patient can carry this drug on them */
    BILL_FLAG            CHAR(1) NOT NULL,                       /* How drug is to be billed */
    NON_MED_FLAG         CHAR(1) NOT NULL,                       /* T/F not an actual drug like a blanket,band-aid */
    CREDITABLE_FLAG      CHAR(1) NOT NULL,                       /* Can Returns On This Drug Be Credited? */
    REFILL_DUE_FLAG      CHAR(1) NOT NULL,                       /* Can Refill Due Records Be Generated? */
    PEDIGREE_FLAG        CHAR(1) NOT NULL,                       /* Does this drug have a pedigree? */
    FORCE_REVIEW_FLAG    CHAR(1) NOT NULL,                       /* Does this drug have to be reviewed by a pharmacist in all cases? */
    MACHINE              CHAR(1) NOT NULL,                       /* Machine Type */
    THREE_FLAG           CHAR(1) NOT NULL,                       /* T/F drug is 340b */
    LOT_NUM_FLAG         CHAR(1) NOT NULL,                       /* This Drug Requires a Lot Number and Date */
    ALLOW_STOCK_FLAG     CHAR(1) NOT NULL,                       /* Allow Stock Scripts For This Drug */
    PROFILE_ONLY_FLAG    CHAR(1) NOT NULL,                       /* This Drug is Only Profiled When Filled */
    DISC_DAYS            INTEGER,                                /* Default # of Days to Discard */
    ROA                  VARCHAR(2),                             /* Route of Administration */
    IMPRINT              VARCHAR(120),                           /* Alternate Imprint Information */
    IMPRINT_DATE         DATETIME,                               /* Date for Imprint Selection */
    DEFAULT_KOP          CHAR(1) NOT NULL,                       /* Default KOP for a Drug */
    FORCE_KOP_FLAG       CHAR(1) NOT NULL,                       /* Force Drug to be dispensed with specified KOP */
    CRI_TEXT             VARCHAR(1024),                          /* Criteria for dispensing */
    CTG_ID               VARCHAR(8),                             /* Category */
    THP_OPTION           CHAR(1) NOT NULL,                       /* Third Party Options */
    PRC_ID               INTEGER,                                /* Price Table */
    STK_PRC_ID           INTEGER,                                /* Stock Price Table */
    DST_DISPENSE         CHAR(1) NOT NULL,                       /* Rules For Dispensing This Drug As Distribution */
    HCPC                 VARCHAR(20),                            /* HCPC */
    HCPC_CODE            CHAR(1) NOT NULL,                       /* HCPC Code */
    MULTI_ING_FLAG       CHAR(1) NOT NULL,                       /* Drug has multiple ingredients */
    CMP_FORM_CODE        CHAR(1) NOT NULL,                       /* Form Code [EF] */
    CMP_UNIT_CODE        CHAR(1) NOT NULL,                       /* Unit Code [EG] */
    CMP_ROUTE_CODE       CHAR(1) NOT NULL,                       /* Route Code Version 5.1 [EH] */
    CMP_TYPE             CHAR(1) NOT NULL,                       /* Compound Type Version D.0 [G1] */
    CMP_ROUTE_D0_CODE    VARCHAR(11),                            /* Route of Administration D.0 [E2] */
    SMART_PROC_CODE      VARCHAR(8),                             /* sMARt Procedure Code */

    CONSTRAINT PK_DRG PRIMARY KEY (ID)
);


/*
@Table           Drug Diagnosis
@Usage           Stores Drug Exceptions for a given Diagnosis
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID, NM9_ID
*/

CREATE TABLE dbo.DRG_NM9
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    NM9_ID               VARCHAR(10) NOT NULL,                   /* ICD-9 ID */
    FORMULARY_FLAG       CHAR(1) NOT NULL,                       /* T/F drug is formulary (normally used) */
    CONSENT_REQUIRED     CHAR(1) NOT NULL,                       /* What is the Approval Level for this Drug? */

    CONSTRAINT PK_DRG_NM9 PRIMARY KEY (ID)
);


/*
@Table           Drug Alternates
@Usage           Stores Classes for Alternates
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID, THC_ID, MED_ID
*/

CREATE TABLE dbo.DRG_THC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    THC_ID               VARCHAR(10),                            /* Therapeutic Class */
    MED_ID               INTEGER,                                /* Medication ID */

    CONSTRAINT PK_DRG_THC PRIMARY KEY (ID)
);


/*
@Table           Drug Translation
@Usage           Drug NDC Translation For Interfaces
@Category        Drug Translation
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRG_TRN
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal */
    TRANSLATE_FROM       VARCHAR(255) NOT NULL,                  /* Translate From */
    TRANSLATE_FROM_Q     CHAR(1) NOT NULL,                       /* Drug Translate Type */

    CONSTRAINT PK_DRG_TRN PRIMARY KEY (ID)
);


/*
@Table           Drug Note
@Usage           Stores Notes for Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TITLE
*/

CREATE TABLE dbo.DRG_NOT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Title of Note */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* Note Type - (S)cript Screen,Plain (T)ext */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */
    REMOTE_FLAG          CHAR(1) NOT NULL,                       /* Remote Flag */

    CONSTRAINT PK_DRG_NOT PRIMARY KEY (ID)
);


/*
@Table           Drug Procedures
@Usage           Stores Procedures for Dispensing Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID,PRO_ID
*/

CREATE TABLE dbo.DRG_PRO
(
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal Id */
    PRO_ID               INTEGER NOT NULL,                       /* Procedure Internal Id */

    CONSTRAINT PK_DRG_PRO PRIMARY KEY (DRG_ID,PRO_ID)
);


/*
@Table           Drug Pharmacy
@Usage           Keeps Pharmacy Specific Information About A Drug
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PHR_ID,DRG_ID
*/

CREATE TABLE dbo.DRG_PHR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    REORDER_FLAG         CHAR(1) NOT NULL,                       /* T/F Reorder This Drug */
    MIN_STOCK            DECIMAL(10,4),                          /* Amount at which Pharmacy needs to Reorder */
    MAX_STOCK            DECIMAL(10,4),                          /* What Stock Level needs to get back to by Reordering */
    DAY_LIMIT            DECIMAL(10,4),                          /* max # of days a drug can be prescribed for */
    LAB_DAYS             INTEGER,                                /* patient must have lab work within this many days if LAB_REQ_FLAG is true */
    DIS_QTY              DECIMAL(10,4),                          /* Drug Dispense Quantity */
    QTY_LIMIT            DECIMAL(10,4),                          /* highest quantity of drug that can be dispensed at one time */
    GROUPING             VARCHAR(8),                             /* Grouping Field for Drugs */
    ALT_LOCATION         VARCHAR(20),                            /* Location for BAKER CELLS */
    COMPLIANCE           INTEGER,                                /* level of compliance for electronic MAR */
    NIGHT_STOCK_FLAG     CHAR(1) NOT NULL,                       /* T/F night stock flag */
    LAB_REQ_FLAG         CHAR(1) NOT NULL,                       /* T/F lab required flag */
    REPORT_EXP_FLAG      CHAR(1) NOT NULL,                       /* T/F does drug print on Script Expiration Report? */
    REF_DUE_FLAG         CHAR(1) NOT NULL,                       /* T/F drug is used for automatic refill */
    CONSENT_REQD_FLAG    CHAR(1) NOT NULL,                       /* T/F ?somebody's? consent is required */
    ONE_APP_FLAG         CHAR(1) NOT NULL,                       /* T/F drug requires only one time approval form */
    DUALENTRY_FLAG       CHAR(1) NOT NULL,                       /* T/F Force Operator to Verify Drug if Names are Similar */
    DISPLAY              CHAR(1) NOT NULL,                       /* Drug Displays For Pharmacy (Non-Filling) */

    CONSTRAINT PK_DRG_PHR PRIMARY KEY (ID)
);


/*
@Table           Drug Vendor
@Usage           Stores Drug Vendor Records for Ordering
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DRG_ID,VEN_ID
*/

CREATE TABLE dbo.DRG_VEN
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    VEN_ID               INTEGER NOT NULL,                       /* Vendor Internal ID */
    ITEM_NO              VARCHAR(15) NOT NULL,                   /* Vendor Assigned Item # */
    LAST_ORDER_DATE      DATETIME,                               /* Date of Last Order */
    LAST_ORDER_QTY       DECIMAL(10,4),                          /* Last Order Quantity */
    STATUS               CHAR(1) NOT NULL,                       /* Status - (P)rimary,(O)ther */

    CONSTRAINT PK_DRG_VEN PRIMARY KEY (ID)
);


/*
@Table           Patient Visit
@Usage           Visit Information
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.VIS
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    SYS_USR_ID           INTEGER NOT NULL,                       /* Creation User */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */

    CONSTRAINT PK_VIS PRIMARY KEY (ID)
);


/*
@Table           Standard Sigs
@Usage           Stores Default Sigs for Drug
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DRG_SIG
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    SIG                  VARCHAR(30) NOT NULL,                   /* Directions */
    PRIORITY             INTEGER,                                /* Order that it shows up in the list */

    CONSTRAINT PK_DRG_SIG PRIMARY KEY (ID)
);


/*
@Table           Dispense
@Usage           Defines Dispense Packaging Types
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.DSP
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Dispense Type */
    DCODE                CHAR(1),                                /* Short Code for this record */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Text Description */
    FORMAT               VARCHAR(12) NOT NULL,                   /* Specifies how to send data across to FilePro */

    CONSTRAINT PK_DSP PRIMARY KEY (ID)
);


/*
@Table           DUR Codes
@Usage           Stores Description of DUR Codes
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.DUR
(
    ID                   VARCHAR(4) NOT NULL,                    /* DUR Code */
    DTEXT                VARCHAR(60) NOT NULL,                   /* DUR Description */

    CONSTRAINT PK_DUR PRIMARY KEY (ID)
);


/*
@Table           Facility
@Usage           Stores Housing Facility Record Information
@Category        Pharmacy
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.FAC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Facility */
    DCODE                VARCHAR(8) NOT NULL,                    /* Short Code For This Facility Record */
    DNAME                VARCHAR(30) NOT NULL,                   /* Name Of Facility */
    PHR_ID               INTEGER NOT NULL,                       /* Internal ID of the Parent Pharmacy Record */
    ADDRESS1             VARCHAR(30),                            /* Address Line 1 */
    ADDRESS2             VARCHAR(30),                            /* Address Line 2 */
    CITY                 VARCHAR(20),                            /* City Where Housing Facility Is Located */
    ST                   VARCHAR(2),                             /* State Where Housing Facility Is Located */
    ZIP                  VARCHAR(11),                            /* Zip Code Where Housing Facility Is Located */
    EMAIL                VARCHAR(50),                            /* E-Mail Address Of Facility */
    PHONE1               VARCHAR(14),                            /* Primary Phone Number */
    PHONE2               VARCHAR(14),                            /* Secondary Phone Number */
    FAX1                 VARCHAR(14),                            /* Primary Fax Number */
    FAX2                 VARCHAR(14),                            /* Secondary Fax Number */
    CONTACT              VARCHAR(40),                            /* Contact Name of Person at Facility */
    ATTENTION            VARCHAR(40),                            /* Person at Facility Responsible For Incoming Items */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Dormant Facilities Will Not Be Accessible */
    DEA                  VARCHAR(9),                             /* DEA Number of Facility */
    BILL_NAM_ID          INTEGER,                                /* Internal ID of the Miscellaneous Name Record */
    REMIT_NAM_ID         INTEGER,                                /* Internal ID of the Miscellaneous Name Record */
    KOP_PRIMARY          CHAR(1) NOT NULL,                       /* This Is The Default Primary Filling Method */
    KOP_SECONDARY        CHAR(1) NOT NULL,                       /* This Is The Default Secondary Filling Method */
    LOCATION_TYPE        CHAR(1) NOT NULL,                       /* Use Location Field or Smaller Fields That Make Up Location */
    LOCATION_LEVEL       CHAR(1) NOT NULL,                       /* Restrict Location Fields At This Level Or Above */
    DOC_ID               INTEGER,                                /* Default Doctor ID */
    STOCK_PAT_ID         INTEGER,                                /* Default Stock Patient */
    CHG_ID               INTEGER,                                /* Default Charge ID */
    REFILL_WINDOW        INTEGER,                                /* Amount Of Previous Fill That Should Be Used Before Refill */
    REFILL_WINDOW_QUAL   CHAR(1) NOT NULL,                       /* Specifies When The Previous Fill Can Be Refilled */
    GROUPING             VARCHAR(4),                             /* Facility Grouping Code */
    FILLING_TYPE         CHAR(1) NOT NULL,                       /* Type Of Facility (Regular, Unit Dose, etc...) */
    PEND_DAYS_FIL_AHEAD  INTEGER,                                /* Maximum # of Days Ahead Pending Scripts Can Be Filled */
    MAX_FIL_DAY_SUP      INTEGER,                                /* Maximum Days that can be sent for one fill */
    FUTURE_START_DAYS    INTEGER,                                /* CIPS Will Add This # Of Days To Today For a Default Start Date */
    DEFAULT_DAYS         INTEGER,                                /* Days A Fill Will Default To When Filling */
    DEFAULT_REF_DAYS     INTEGER,                                /* Days A Fill Will Default To When Refilling */
    NF_DISPENSE_FLAG     CHAR(1) NOT NULL,                       /* Allow Non-Formulary Drugs To Be Dispensed Without Approval */
    NF_DAYS              INTEGER,                                /* Days A Non-Formulary Script Will Default To When Filling */
    NF_REF_DAYS          INTEGER,                                /* Days A Non-Formulary Script Will Default To When Refilling */
    NOFORM_DAYS          INTEGER,                                /* Days A Non-Formulary Script Will Default To When Filling Without A Form */
    NOFORM_REF_DAYS      INTEGER,                                /* Days A Non-Formulary Script Will Default To When Refilling Without A Form */
    PICK_FACTOR          INTEGER,                                /* (Pick Factor * Warehouse Max Order) = Max This Facility Can Order */
    CAP_AMT              DECIMAL(10,4),                          /* Capitation Amount */
    CAP_THP_AMT          DECIMAL(10,4),                          /* Cap for individual fill claim submission */
    LABEL_TYPE           CHAR(1),                                /* Default Label Format For This Facility */
    POPULATION_TYPE      CHAR(1) NOT NULL,                       /* Type Of Population In This Facility */
    REFILL_DUE_FLAG      CHAR(1) NOT NULL,                       /* Will Refill Due Records Be Generated For This Facility? */
    CUTOFF_TIME          DATETIME,                               /* Orders must be received by this time to be sent out today */
    FUTURE_START_DATE    CHAR(1) NOT NULL,                       /* Profile or Warn User Processing Orders With Future Start Dates */
    RFD_TYPE             CHAR(1) NOT NULL,                       /* CIPS Will Generate Refill Due Records For This Type of Script... */
    STA_ID               VARCHAR(5),                             /* Talyst Machine ID */
    AUTO_PAT_ED          CHAR(1) NOT NULL,                       /* Cips Will Automatically Print a Patient Education Sheet In Specified Language */
    USE_THP_FLAG         CHAR(1) NOT NULL,                       /* Allow Submitting Claims to Third Parties */
    USE_SCH_FLAG         CHAR(1) NOT NULL,                       /* Tab Stop on Dosage Schedule */
    FORCE_SCH_FLAG       CHAR(1) NOT NULL,                       /* Force Entry of Dosage Schedule */
    DEF_PILLS_CARD       INTEGER,                                /* Default Number of Pills per Card */
    GPI_LENGTH           CHAR(1) NOT NULL,                       /* This Field Tells CIPS How Many Characters to Compare For Matches */
    GPI_REFILL_LENGTH    CHAR(1) NOT NULL,                       /* This Field Tells CIPS How Many Characters of the Drug GPI to Check on Refills */
    REVIEW_PROF          CHAR(1) NOT NULL,                       /* Force Entry Of Pharmacist Review Fields on Profiled Scripts */
    MACH_SITE_SCAN       CHAR(1) NOT NULL,                       /* Barcodes will be Sent to Packaging Machines for Sites using scanners */
    USE_IF_DATES_FLAG    CHAR(1) NOT NULL,                       /* Use Start and Stop Dates from Order Interfaces As Is */
    TAKEN_ON_EXP_FLAG    CHAR(1) NOT NULL,                       /* CIPS Will Use This Flag to Figure the Stop Date */
    MAX_DAY_SUP          INTEGER,                                /* Maximum Days A Script Can Be Filled For At This Facility */
    DEFAULT_DAY_SUP      INTEGER,                                /* Default # Of Days To For Entire Script */
    RESTRICT_QTY_FLAG    CHAR(1) NOT NULL,                       /* Will limit the amount of qty dispensed to the days left on the script */
    USE_QTY_DUE_FLAG     CHAR(1) NOT NULL,                       /* CIPS Will Use Quantity Due In Calculations */
    USE_REFILL_DAYS      CHAR(1) NOT NULL,                       /* Auto-Refill Will Figure Refill Quanitity Based on Refill Days */
    USE_FILL_TIME        CHAR(1) NOT NULL,                       /* Adjust Start Pass Based on Fill Time */
    USE_FORM_TWO_FLAG    CHAR(1) NOT NULL,                       /* Use Drug Wexford Formulary Flag */
    USE_RXS_FOR_QTY      CHAR(1) NOT NULL,                       /*  */
    DEF_FILL_QTY         DECIMAL(10,4),                          /* (Overrides Default Fill Days Supply if there is a value) */
    SAT_DEL_FLAG         CHAR(1) NOT NULL,                       /* Scripts Delivered on Saturday. */
    SUN_DEL_FLAG         CHAR(1) NOT NULL,                       /* Scripts Delivered on Sunday. */
    PAS_ID               VARCHAR(10),                            /* Pass ID */
    APPROVAL_TYPE        CHAR(1) NOT NULL,                       /* System for Handling Approvals */
    CYCLE_TYPE           CHAR(1) NOT NULL,                       /* System for Handling Cycle Filling */
    CYCLE_START_DATE     DATETIME,                               /* Date the Filling Cycle is to Start */
    CYCLE_BEGIN_BUFFER   INTEGER,                                /* Number of Days Buffer to Figure Original Fill Quantity for Cycle */
    CYCLE_END_BUFFER     INTEGER,                                /* Number of Days Buffer to Figure Last Fill Quantity for Cycle */
    PGR_ID               INTEGER,                                /* Price Table Group */
    THREE_FLAG           CHAR(1) NOT NULL,                       /* 340b Facility */
    MAC_FLAG             CHAR(1) NOT NULL,                       /* How MAC price is Figured from MAC in Drug Tables */
    USE_MAR_LABELS       CHAR(1) NOT NULL,                       /* Print MAR Labels Through Cips Remote? */
    USE_ORDER_FORM       CHAR(1) NOT NULL,                       /* Print Order Form Through Cips Remote? */
    LAB_IMPRINT_SIG_FLAG CHAR(1) NOT NULL,                       /* T/F Print Imprint w/ SIG on Labels */
    LAB_DATES_FLAG       CHAR(1) NOT NULL,                       /* T/F Print Start/Stop Dates on Labels */
    MAR_DATES_FLAG       CHAR(1) NOT NULL,                       /* T/F Print Start/Stop Dates on MAR */
    LABEL_PRT_ID         INTEGER,                                /* Label Printer for this Facility. Overrides Drug Label Printer */
    USE_DRG_SYMBOLS      CHAR(1) NOT NULL,                       /* T/F To Print Drug Name Symbols on Labels */
    IMPRINT_FLAG         CHAR(1) NOT NULL,                       /* Show Drug Imprint with Sig On Label ( Must Be Set Up On Label ) */
    BOOKING_FLAG         CHAR(1) NOT NULL,                       /* The Booking Number is the Primary Number for Lookups and Printing */
    NEW_LABEL_NAME       VARCHAR(255),                           /* Name of the Label to Print for New Scripts */
    REF_LABEL_NAME       VARCHAR(255),                           /* Name of the Label to Print for Scripts being Refilled */
    MAR_LABEL_NAME       VARCHAR(255),                           /* Name of the MAR Label to Print for Scripts */
    NEW_MAR_LABELS       INTEGER,                                /* Number of MAR Labels to Print for New Orders */
    REF_MAR_LABELS       INTEGER,                                /* Number of MAR Labels to Print for Refill Orders */
    PROF_MAR_LABELS      INTEGER,                                /* Number of MAR Labels to Print for Profile Orders */
    LABEL_TEXT           VARCHAR(8),                             /* Text to Show on Label */
    STD_ORD_LAB_FLAG     CHAR(1) NOT NULL,                       /* Prints Labels After Entering a Standard Order in Remote */
    USE_PHR_REVIEW       CHAR(1) NOT NULL,                       /* Use the Facility Pharmacy Review Settings */
    USE_REVIEW           CHAR(1) NOT NULL,                       /* Force Entry Of Pharmacist Review Fields On a New Script */
    LIMIT_TO_ORD_FLAG    CHAR(1) NOT NULL,                       /* Scripts that did not orginate from orders cannot be entered. */
    USE_SCH_NUM_FLAG     CHAR(1) NOT NULL,                       /* Controlled Substances must be numbered */
    WORKFLOW_FLAG        CHAR(1) NOT NULL,                       /* CIPS will send script information to the workflow system for this facility */
    WORKFLOW_FAC_DCODE   VARCHAR(5),                             /* CIPS will send script information to the workflow system under this code */
    PRI_ID               INTEGER,                                /* Default Fill Priority */
    DISTRIBUTION_FLAG    CHAR(1) NOT NULL,                       /* Can Distribution Pharmacy Dispense to this Facility? */
    LICENSE_FLAG         CHAR(1) NOT NULL,                       /* License On File */
    LICENSE_EXP_DATE     DATETIME,                               /* License Expiration Date */
    DEA_LICENSE_FLAG     CHAR(1) NOT NULL,                       /* DEA License On File */
    DEA_LICENSE_EXP_DATE DATETIME,                               /* DEA License Expiration Date */
    RTN_CREDIT_TYPE      CHAR(1) NOT NULL,                       /* Business Rule for Figuring Credits */
    RTN_REA_ID           VARCHAR(8),                             /* Default Return Reason */
    CREDIT_PGR_ID        INTEGER,                                /* CIPS Will Use This Price Group To Determine How Much Credit To Give the Facility */
    RESTOCK_PGR_ID       INTEGER,                                /* CIPS Will Use This Price Group To Determine A Restocking Fee */
    RTN_CREDIT_LIMIT     DECIMAL(10,4),                          /* Credit Must Be Above This Value Or No Credit Given */
    EXP_DEL_FLAG         CHAR(1) NOT NULL,                       /* Export Delivery Sheets */
    IMAGE_DIRECTORY      VARCHAR(255),                           /* This Is Where Images Are Found For This Facility */
    RESTRICT_NEW_FLAG    CHAR(1) NOT NULL,                       /* Are Remote Users in this Facility Restricted from Entering New Orders? */
    RESTRICT_REFILL_FLAG CHAR(1) NOT NULL,                       /* Are Remote Users in this Facility Restricted from Entering Refill Orders? */
    SEARCH_RGN_FLAG      CHAR(1) NOT NULL,                       /* Are Remote Users in this Facility Allowed to search for Facilities in their Region? */
    DOC_SEARCH_RGN_FLAG  CHAR(1) NOT NULL,                       /* Are Remote Users in this Facility Allowed to search for Doctors in their Primary Region? */
    USE_RF_CUT_TIME_FLAG CHAR(1) NOT NULL,                       /* Use Refill Cut Time */
    REF_CUT_TIME         DATETIME,                               /* The Time that Refills Stop Being Processed for Today */
    USE_TOT_QTY_DUE_FLAG CHAR(1) NOT NULL,                       /* Are Remote Users in this Facility Allowed to Set the Total Qty Due Manually? */
    REMOTE_USR_ID        INTEGER,                                /* Default User for CIPS Remote Options */
    DEF_ORDER_TYPE       CHAR(1) NOT NULL,                       /* Default Order Type */
    DC_MAR_LABELS        INTEGER,                                /* Number of MAR labels to print when a script is discontinued */
    KEEP_DOC_FLAG        CHAR(1) NOT NULL,                       /* Keep Doctor when Generally Clearing Order Entry Screen */
    MOVE_FAC             CHAR(1) NOT NULL,                       /* Allows users to fill orders from different facilities */
    SHOW_DOC_DEA         CHAR(1) NOT NULL,                       /* Show Doctor DEA in Remote */
    SHOW_ACQ_COST        CHAR(1) NOT NULL,                       /* Show Acquisition Cost in Remote */
    CHANGE_START_FLAG    CHAR(1) NOT NULL,                       /* Change Start Date after Que Cut Time */
    CHANGE_STOP_FLAG     CHAR(1),                                /* Change Stop Date When Start Date Changes */
    TSK_ID               INTEGER,                                /* Task ID For Linking Manually Entered Order Types */
    EPCS_FLAG            CHAR(1) NOT NULL,                       /* Doctors must use 2 Factor Authentication for Remote Orders */

    CONSTRAINT PK_FAC PRIMARY KEY (ID)
);


/*
@Table           Facility Charge
@Usage           Assigns Charge Accounts to Facilities
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_CHG
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    CHG_ID               INTEGER NOT NULL,                       /* Charge Account Internal ID */
    BILL_NAM_ID          INTEGER,                                /* Internal ID of the Miscellaneous Name Record */
    REMIT_NAM_ID         INTEGER,                                /* Internal ID of the Miscellaneous Name Record */
    SEQ_NUM              INTEGER,                                /* Used to Sort Charge Accounts */
    THP_ID               VARCHAR(12),                            /* Third Party Initial */
    PROCESSOR            VARCHAR(10),                            /* Processor Control Number */
    ACTION               CHAR(1) NOT NULL,                       /* Default Third Party Action */
    NUM_BILL_DAYS        INTEGER,                                /* Number of Billing Days */
    GRP_NUMBER           VARCHAR(15),                            /* Group Number */
    PERSON_CODE          VARCHAR(3),                             /* Person Code */
    CARD_ID_MASK         VARCHAR(20),                            /* Cardholder ID Mask */
    RELATION             CHAR(1) NOT NULL,                       /* Relationship to Cardholder */
    RX_ORIGIN            CHAR(1) NOT NULL,                       /* Default Prescription Origin Code */
    RX_DAW               CHAR(1) NOT NULL,                       /* Default Prescription DAW */
    DEFAULT_TO_INS_FLAG  CHAR(1) NOT NULL,                       /* Default to Insurance on Refills and Rollovers if Patient has Valid Insurance */

    CONSTRAINT PK_FAC_CHG PRIMARY KEY (ID)
);


/*
@Table           Facility Category
@Usage           Set Default Categories for a Facility
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_CTG
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Link To Facility */
    CTG_ID               VARCHAR(8) NOT NULL,                    /* Category */
    DTYPE                CHAR(1) NOT NULL,                       /* Category Type */

    CONSTRAINT PK_FAC_CTG PRIMARY KEY (ID)
);


/*
@Table           Facility Drug Exception
@Usage           Stores Exceptions for Facilities filling
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FAC_ID,DRG_ID
*/

CREATE TABLE dbo.FAC_DRG
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    PICK_FACTOR          INTEGER,                                /* Multiplier for Order Amounts for this Facility, overrides the default in FAC */
    PICK_FACTOR_DRG      CHAR(1) NOT NULL,                       /* Use Value From Drug Table */
    RESTRICTED_FLAG      CHAR(1) NOT NULL,                       /* Restrict facility from filling this drug */
    FDISPLAY             CHAR(1) NOT NULL,                       /* Drug Displays During Filling */
    NIGHT_STOCK          CHAR(1) NOT NULL,                       /* Drug can be used for Night Stock */
    SELF_CARRY           CHAR(1) NOT NULL,                       /* Drug can be Carried by Patient */
    DEFAULT_KOP          CHAR(1) NOT NULL,                       /* Default KOP for a Facility and Drug */
    FORCE_KOP            CHAR(1) NOT NULL,                       /* Force Drug to be dispensed with specified KOP for this facility */
    LAB_REQ              CHAR(1) NOT NULL,                       /* Lab Required to Dispense Drug */
    DORMANT              CHAR(1) NOT NULL,                       /* Drug is Dormant */
    MAINTENANCE          CHAR(1) NOT NULL,                       /* Drug is a Maintenance Drug */
    FORMULARY            CHAR(1) NOT NULL,                       /* Drug is Formulary */
    PHARMACY             CHAR(1) NOT NULL,                       /* Drug is from the Pharmacy */
    GRP_ID               VARCHAR(8),                             /* Group */
    GRP_ID_DRG           CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    CTG_ID               VARCHAR(8),                             /* Category */
    CTG_ID_DRG           CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    OTC                  CHAR(1) NOT NULL,                       /* Drug is Over the Counter */
    MACHINE              CHAR(1) NOT NULL,                       /* Machine Type */
    BILL                 CHAR(1) NOT NULL,                       /* Drug is Billable */
    CREDITABLE           CHAR(1) NOT NULL,                       /* Can Returns On This Drug Be Credited? */
    DEFAULT_DAYS         INTEGER,                                /* Days A Script Will Default To When Filling */
    DEFAULT_DAYS_DRG     CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    DEFAULT_REF_DAYS     INTEGER,                                /* Days A Script Will Default To When Refilling */
    DEFAULT_REF_DAYS_DRG CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    NF_DAYS              INTEGER,                                /* Days A Non-Formulary Script Will Default To When Filling */
    NF_DAYS_DRG          CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    NF_REF_DAYS          INTEGER,                                /* Days A Non-Formulary Script Will Default To When Refilling */
    NF_REF_DAYS_DRG      CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    NOFORM_DAYS          INTEGER,                                /* Days A Non-Formulary Script Will Default To When Filling Without A Form */
    NOFORM_DAYS_DRG      CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    NOFORM_REF_DAYS      INTEGER,                                /* Days A Non-Formulary Script Will Default To When Refilling Without A Form */
    NOFORM_REF_DAYS_DRG  CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    CRD_ID               INTEGER,                                /* Default Drug Card */
    CRD_ID_DRG           CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    MIN_RTN_QTY          DECIMAL(10,4),                          /* Less Than This Should Not Be Returned To Pharmacy */
    MIN_RTN_QTY_DRG      CHAR(1) NOT NULL,                       /* Use Value from Drug Table */
    CONSENT_REQUIRED     CHAR(1) NOT NULL,                       /* What is the Approval Level for this Drug? */
    THREE                CHAR(1) NOT NULL,                       /* Drug is 340b */
    ALLOW_STOCK          CHAR(1) NOT NULL,                       /* Allow Stock Scripts For This Drug */
    PROFILE_ONLY         CHAR(1) NOT NULL,                       /* This Drug is Only Profiled When Filled */
    MAC_PRICE            DECIMAL(10,4),                          /* Maximum Allowable Charge to be Charged to the Facility, Uses MAC Flag from Facility */
    PRC_ID               INTEGER,                                /* In Not Stock, Overrides all other price tables */
    STK_PRC_ID           INTEGER,                                /* If Stock, Overrides all other price tables */

    CONSTRAINT PK_FAC_DRG PRIMARY KEY (ID)
);


/*
@Table           Facility Logging
@Usage           Stores Logging Messages to Facilities
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_LOG
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DEL_BAT_ID           INTEGER,                                /* Batch Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal Id */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal Id */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal Id */
    VOID_FLAG            CHAR(1) NOT NULL,                       /* T/F Record has been Voided */
    LOGTYPE              CHAR(1) NOT NULL,                       /* Program that Generated Log */
    DTEXT                VARCHAR(255) NOT NULL,                  /* Log Text */
    DNOTE                VARCHAR(255) NOT NULL,                  /* Log Note */
    PREV_BAT_IDS         VARCHAR(255),                           /* Previous Batch ID's */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record was Added */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record was Added */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged in when Record was Added */

    CONSTRAINT PK_FAC_LOG PRIMARY KEY (ID)
);


/*
@Table           Facility Notes
@Usage           Stores unlimited notes tied to facility
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TITLE
*/

CREATE TABLE dbo.FAC_NOT
(
    ID                   INTEGER NOT NULL,                       /* Facility Note Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Link To Facility */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Title Of The Note */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* Shows How the Note Was Added */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_FAC_NOT PRIMARY KEY (ID)
);


/*
@Table           Facility Pass Times
@Usage           Facility Pass Times and MAR Boxes
@Category        Schedule
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_PAS
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    PAS_ID               VARCHAR(10) NOT NULL,                   /* Pass */
    DTIME                DATETIME,                               /* Cutoff Time for New Orders for this Pass */
    BOX                  INTEGER,                                /* Box for printing this time */
    TIME_FLAG            CHAR(1) NOT NULL,                       /* Print the Time Instead of the Code */

    CONSTRAINT PK_FAC_PAS PRIMARY KEY (ID)
);


/*
@Table           Facility Price
@Usage           Sorts through which Price Table to use for a Facility in a Particular Situation
@Category        Price
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PRC_ID,SEQ_NUM
*/

CREATE TABLE dbo.FAC_PRC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PGR_ID               INTEGER,                                /* Price Group Internal */
    PRC_ID               INTEGER NOT NULL,                       /* Price Table Internal ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number */
    FILTER1              CHAR(1) NOT NULL,                       /* if the Situation meets both Filters, this Price Table will be used */
    FILTER2              CHAR(1) NOT NULL,                       /* if the Situation meets both Filters, this Price Table will be used */
    CHG_ID               INTEGER,                                /* Charge ID to Filter By */

    CONSTRAINT PK_FAC_PRC PRIMARY KEY (ID)
);


/*
@Table           Facility Printer Forms
@Usage           Facility Printer Forms
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_PRF
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility ID */
    PRF_EVENT            CHAR(1) NOT NULL,                       /* Event When This Form Will Be Printed */
    FR_NAME              VARCHAR(100),                           /* FR Filename */
    PRT_ID               INTEGER,                                /* Printer ID */

    CONSTRAINT PK_FAC_PRF PRIMARY KEY (ID)
);


/*
@Table           Facility Queue
@Usage           Ties a Facility to a Queue
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_QUE
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Link To Facility */
    QUE_ID               INTEGER NOT NULL,                       /* Link To Queue */
    DTYPE                CHAR(1) NOT NULL,                       /* Type of Action */

    CONSTRAINT PK_FAC_QUE PRIMARY KEY (ID)
);


/*
@Table           Facility Remote
@Usage           Stores Facility Specific Settings for Remote Users
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FAC_ID
*/

CREATE TABLE dbo.FAC_RMT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Link To Facility */
    AUTO_DRG_ALT_FLAG    CHAR(1) NOT NULL,                       /* Alternate Matching Drugs Will Be Shown Automatically During Filling */
    USE_SCH_FLAG         CHAR(1) NOT NULL,                       /* Tab Stop on Dosage Schedule */

    CONSTRAINT PK_FAC_RMT PRIMARY KEY (ID)
);


/*
@Table           Facility Std Order
@Usage           Facility Std Order
@Category        Facility Order
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_STD
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    STD_ID               INTEGER NOT NULL,                       /* Standard Order */

    CONSTRAINT PK_FAC_STD PRIMARY KEY (ID)
);


/*
@Table           Facility Translation
@Usage           Translates Customer Facility Codes to Facility ID's for CIPS
@Category        Interface
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FAC_ID,TRANSLATE_FROM
*/

CREATE TABLE dbo.FAC_TRN
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Patient Record */
    TSK_ID               INTEGER NOT NULL,                       /* Task Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    LOCATION             VARCHAR(40),                            /* Location */
    TRANSLATE_FROM       VARCHAR(255) NOT NULL,                  /* Customer defined Facility Code */
    TRANSLATE_FLAG       CHAR(1) NOT NULL,                       /* Allow Interface to Update Facility */
    RELEASE_FLAG         CHAR(1) NOT NULL,                       /* Release */

    CONSTRAINT PK_FAC_TRN PRIMARY KEY (ID)
);


/*
@Table           Facility Unit
@Usage           Unit
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FAC_UNT
(
    FAC_ID               INTEGER NOT NULL,                       /* Facility ID */
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    UNIT                 VARCHAR(10) NOT NULL,                   /*  */
    DNAME                VARCHAR(30),                            /* Name Of Unit */
    STA_ID               VARCHAR(5),                             /* Talyst Machine ID */
    DTYPE                CHAR(1) NOT NULL,                       /* Court, Transfer, Etc. */
    COURT_DAYS           INTEGER,                                /* Length of Court Orders */

    CONSTRAINT PK_FAC_UNT PRIMARY KEY (ID)
);


/*
@Table           Facility Class Restriction
@Usage           Restricts a Facility's Ability to Fill a GPI Class
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FAC_ID,GPI
*/

CREATE TABLE dbo.FCR
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    GPI                  VARCHAR(25) NOT NULL,                   /* GPI */

    CONSTRAINT PK_FCR PRIMARY KEY (ID)
);


/*
@Table           Fill
@Usage           Stores Fills for Patients
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_NUMBER,SEQ_NUM
*/

CREATE TABLE dbo.FIL
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Facility */
    RXF_ID               INTEGER NOT NULL,                       /* Script Internal ID */
    PHR_ID               INTEGER,                                /* Pharmacy Internal ID */
    RXF_NUMBER           INTEGER NOT NULL,                       /* Rx Number */
    SEQ_NUM              INTEGER NOT NULL,                       /* Refill Sequence */
    NDC                  VARCHAR(14) NOT NULL,                   /* NDC Number from DRG */
    DEA                  CHAR(1),                                /* DEA from DRG */
    STATUS               CHAR(1) NOT NULL,                       /* What Stage Is This Fill In? */
    KOP                  CHAR(1) NOT NULL,                       /* Method of Giving Meds to the Patient */
    NET_QTY_DSP          DECIMAL(10,4),                          /* Quantity Dispensed to Patient Minus Returns */
    QTY_DSP              DECIMAL(10,4),                          /* Quantity Dispensed to Patient */
    QTY_UNCOSTED         DECIMAL(10,4),                          /* Quantity that there was no inventory for */
    QTY_SENT             DECIMAL(10,4),                          /* Quantity Sent Out the Door */
    QTY_PER_CARD         DECIMAL(10,4),                          /* Quantity That Goes in a Card */
    QTY_PER_BUBBLE       DECIMAL(10,4),                          /* Quantity That Goes in a Bubble */
    DISPENSE_QTY         DECIMAL(10,4),                          /* Quantity Per Pack */
    DAYS_SUPPLY          INTEGER,                                /* Days Supply of Quantity */
    UNIT                 CHAR(1) NOT NULL,                       /* Dispense Unit of Drug */
    LOT_NUMBER           VARCHAR(13),                            /* Drug Lot Number */
    LOT_DATE             DATETIME,                               /* Drug Lot Expiration Date */
    FAC_TYPE             CHAR(1),                                /* Facility Type */
    ORIGIN               CHAR(1) NOT NULL,                       /* How it was Filled ( manual, autofill, etc...) */
    PAT_LOCATION         VARCHAR(40),                            /* Specific Location of Patient */
    LABEL_COUNT          INTEGER,                                /* Number of Labels to Print ( Per Set ) */
    LABEL_SPLITS         VARCHAR(255),                           /* How the Quantity is split on the labels */
    SCRIPTTYPE           CHAR(1) NOT NULL,                       /* (C)onverted Script,(N)ormal Script */
    DOCUTRACK_ID         INTEGER,                                /* DocuTrack Document ID */
    CARD_QUANT           DECIMAL(10,4),                          /* Quantity Dispensed on a Card */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    FAC_ID               INTEGER,                                /* Facility Internal ID */
    ORD_DRG_ID           INTEGER,                                /* Drug that was Ordered */
    PRI_ID               INTEGER,                                /* Priority Level For This Fill */
    PHARMACIST           VARCHAR(3),                             /* Rph Initials */
    PHARM_USR_ID         INTEGER,                                /* Fill Pharmacist */
    TECH                 VARCHAR(3),                             /* Tech Initials */
    TECH_USR_ID          INTEGER,                                /* Fill Technician */
    PND_USR_ID           INTEGER,                                /* User who entered Pending Order */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */
    PV_USR_ID            INTEGER,                                /* Pharmacist who Reviewed Fill */
    VERIFY1_USR_ID       INTEGER,                                /* User who verified Record */
    VERIFY2_USR_ID       INTEGER,                                /* User who verified Record */
    VOID_SYS_USR_ID      INTEGER,                                /* User ID who Voided Record */
    VOID_REA_ID          VARCHAR(8),                             /* Void Reason Short Code */
    CHG_ID               INTEGER,                                /* Charge Code */
    PRC_ID               INTEGER,                                /* Price Internal ID */
    MANUAL_PRC_FLAG      CHAR(1) NOT NULL,                       /* This Price Table Was Manually Selected, Do not Refigure */
    DSP_ID               INTEGER,                                /* Dispense Type */
    OVR_ID               INTEGER,                                /* Override ID */
    RXF_CON_ID           INTEGER,                                /* Rx Consent Internal ID */
    DISPENSE_TEXT        VARCHAR(40),                            /* Dispense Free Text */
    AUTHORIZE            VARCHAR(30),                            /* Authorized By */
    RXF_ORD_ID           INTEGER,                                /* Internal ID of the Rx Order */
    RXF_ORD_ORDER_NUM    VARCHAR(60),                            /* Order Number */
    MACHINE              CHAR(1) NOT NULL,                       /* Machine Type */
    THREE                CHAR(1) NOT NULL,                       /* Fill is 340b */
    BIL_BAT_ID           INTEGER,                                /* Billing Batch ID */
    EMAR                 CHAR(1) NOT NULL,                       /* Fill is Sent to EMAR */
    THP                  CHAR(1) NOT NULL,                       /* Third Party ( T/F This is a third party script ) */
    FIL_THP_ID           INTEGER,                                /* Third Party Billing */
    FIL_DATE             DATETIME,                               /* Date Filled */
    BIL_DATE             DATETIME,                               /* Date Billed */
    TIME_DISPENSED       DATETIME,                               /* Time Medication was Dispensed */
    PRT_DATE             DATETIME,                               /* Date Printed */
    PV_SYS_DATE          DATETIME,                               /* Date Fill was Reviewed */
    PV_SYS_TIME          DATETIME,                               /* Time Fill was Reviewed */
    PV_TIME_HOUR         INTEGER,                                /* Review Time Hour */
    VERIFY1_SYS_DATE     DATETIME,                               /* Date Fill was Verified */
    VERIFY1_SYS_TIME     DATETIME,                               /* Time Fill was Verified */
    VERIFY2_SYS_DATE     DATETIME,                               /* Second Date Fill was Verified */
    VERIFY2_SYS_TIME     DATETIME,                               /* Second Time Fill was Verified */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */
    SYS_TIME_HOUR        INTEGER,                                /* System Time Hour */
    ADM_DATE             DATETIME,                               /* Date Medication was Administered */
    ADM_PASS             VARCHAR(10),                            /* First Pass Medication To Be Administered */
    END_DATE             DATETIME,                               /* Date Medication was to be Last Administered */
    END_PASS             VARCHAR(10),                            /* Last Pass Medication To Be Administered */
    VOID_SYS_DATE        DATETIME,                               /* Date Record was Voided */
    VOID_SYS_TIME        DATETIME,                               /* Time Record was Voided */
    VERSION              VARCHAR(12) NOT NULL,                   /* The Version Cips was on when this Fill was Stored Initially */
    SAVED_VERSION        VARCHAR(12),                            /* The Version Cips was on when this Fill was Saved (Correction) */
    PRC_FACTOR           DECIMAL(10,4),                          /* Captured Price from Price Table */
    PRC_FEE              DECIMAL(10,4),                          /* Captured Fee from Price Table */
    COST_BASIS           CHAR(1) NOT NULL,                       /* Cost Basis to use for Price Table */
    COST                 DECIMAL(10,4),                          /* Base Cost */
    WAC_COST             DECIMAL(10,4),                          /* Wholesale Acquisition Cost */
    HIGH_ACQ_COST        DECIMAL(10,4),                          /* Highest Acq Cost of Drugs */
    ACQ_COST             DECIMAL(10,4),                          /* Acquisition Cost of Dispense Qty of Drugs */
    PRICE                DECIMAL(10,4),                          /* Price Cips Figured */
    AWP                  DECIMAL(10,4),                          /* Average Wholesale Price */
    USUAL_PRICE          DECIMAL(10,4),                          /* Usual and Customary Price */
    INS_PRICE            DECIMAL(10,4),                          /* Price that the insurance will pay */
    COPAY_PRICE          DECIMAL(10,4),                          /* Price that the facility will pay */
    U_PRC_ID             INTEGER,                                /* U&C Price Internal */
    U_PRC_FACTOR         DECIMAL(10,4),                          /* U&C Price from Price Code */
    U_PRC_FEE            DECIMAL(10,4),                          /* U&C Fee from Price Code */
    U_COST_BASIS         CHAR(1) NOT NULL,                       /* U&C Cost Basis to use for Price Code */
    U_COST               DECIMAL(10,4),                          /* U&C Base Cost */
    GENERIC_FLAG         CHAR(1) NOT NULL,                       /* T/F Drug is Generic */
    PREGNANT_FLAG        CHAR(1) NOT NULL,                       /* T/F Patient is Pregnant */
    PREFERRED_FLAG       CHAR(1) NOT NULL,                       /* T/F Drug is Preferred when Filled */
    RTN_FLAG             CHAR(1) NOT NULL,                       /* T/F Fill has been Returned */
    FORMULARY_FLAG       CHAR(1) NOT NULL,                       /* T/F Drug is Formulary */
    PHARMACY_FLAG        CHAR(1) NOT NULL,                       /* T/F Drug is from the Pharmacy */
    BILL_FLAG            CHAR(1) NOT NULL,                       /* T/F Fill is Billable */
    SAFETY_CAP_FLAG      CHAR(1) NOT NULL,                       /* T/F Medication Requires Safety Cap */
    MAINTENANCE_FLAG     CHAR(1) NOT NULL,                       /* T/F This is a Maintenance Script */
    OTC_FLAG             CHAR(1) NOT NULL,                       /* T/F This is Over The Counter */
    CREDITABLE_FLAG      CHAR(1) NOT NULL,                       /* T/F This Fill is Creditable */
    LAB_REQ_FLAG         CHAR(1) NOT NULL,                       /* T/F Lab Work Required */
    PACKS_FLAG           CHAR(1) NOT NULL,                       /* This fill was dispensed as packs */
    DSP_FILL_FLAG        CHAR(1) NOT NULL,                       /* This fill is dispensed in this packaging for only this fill */
    SHOW_IN_REVIEW_FLAG  CHAR(1) NOT NULL,                       /* Will this fill show up in pharmacist review? */
    MAN_ABB              VARCHAR(5),                             /* 5 Char Short Code */
    MAN_LABELER          VARCHAR(10),                            /* 10 Char Labeler Abbreviation */
    MAN_DNAME            VARCHAR(30),                            /* Description Name of Manufacturer */
    SCREENED             CHAR(1) NOT NULL,                       /* Medispan Screening Status */
    PR_FLAG              CHAR(1) NOT NULL,                       /* Patient Allergies are an Issue */
    DI_SEVERITY          INTEGER,                                /* Drug Interaction Severity */
    NFA_ID               INTEGER,                                /* Link to Approval Record */

    CONSTRAINT PK_FIL PRIMARY KEY (ID)
);


/*
@Table           Fill Bill
@Usage           Stores Billing Info for Fills
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_BIL
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Fill Bill Record */
    COST                 DECIMAL(10,4),                          /* Base Cost */
    WAC_COST             DECIMAL(10,4),                          /* Wholesale Acquisition Cost */
    ACQ_COST             DECIMAL(10,4),                          /* Acquisition Cost */
    HIGH_ACQ_COST        DECIMAL(10,4),                          /* Highest Acq Cost of Drugs */
    AWP                  DECIMAL(10,4),                          /* Average Wholesale Price */
    COST_BASIS           CHAR(1) NOT NULL,                       /* Cost Basis to use for Price Code */
    PRC_FEE              DECIMAL(10,4),                          /* Captured Fee from Price Code */
    PRC_FACTOR           DECIMAL(10,4),                          /* Captured Price from Price Code */
    PRICE                DECIMAL(10,4),                          /* Price Cips Figured */
    USUAL_PRICE          DECIMAL(10,4),                          /* Usual and Customary Price */
    INS_PRICE            DECIMAL(10,4),                          /* Price that the insurance will pay */
    COPAY_PRICE          DECIMAL(10,4),                          /* Price that the facility will pay */
    U_COST               DECIMAL(10,4),                          /* U&C Base Cost */
    U_COST_BASIS         CHAR(1) NOT NULL,                       /* U&C Cost Basis to use for Price Code */
    U_PRC_FEE            DECIMAL(10,4),                          /* U&C Fee from Price Code */
    U_PRC_FACTOR         DECIMAL(10,4),                          /* U&C Price from Price Code */
    QTY_DSP              DECIMAL(10,4),                          /* Quantity Dispensed to Patient */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    RXF_ID               INTEGER,                                /* Rx Internal ID */
    PAT_ID               INTEGER,                                /* Patient Internal ID */
    FAC_ID               INTEGER,                                /* Facility Internal ID */
    CHG_ID               INTEGER,                                /* Charge Code */
    PRC_ID               INTEGER,                                /* Price Internal */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal */
    DOC_ID               INTEGER NOT NULL,                       /* Doctor Internal */
    U_PRC_ID             INTEGER,                                /* U&C Price Internal */
    BIL_BAT_ID           INTEGER,                                /* Batch Billing Internal */
    BIL_DATE             DATETIME,                               /* Date Billed */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */
    VOID_FLAG            CHAR(1) NOT NULL,                       /* T/F Record should not be used */
    REBILL_FLAG          CHAR(1) NOT NULL,                       /* T/F This is a Rebill ( Billed Outside of Grace Period ) */
    GENERIC_FLAG         CHAR(1) NOT NULL,                       /* T/F Drug is Generic */
    FORMULARY_FLAG       CHAR(1) NOT NULL,                       /* T/F Drug is Formulary */
    OTC_FLAG             CHAR(1) NOT NULL,                       /* T/F This is Over The Counter */

    CONSTRAINT PK_FIL_BIL PRIMARY KEY (ID)
);


/*
@Table           Credit/Debit
@Usage           Stores Credits and Debits
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_CDT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    REA_ID               VARCHAR(8) NOT NULL,                    /* Reason Internal ID */
    USR_ID               INTEGER NOT NULL,                       /* User Internal ID */
    TRN_DATE             DATETIME,                               /* Transaction Date */
    TRN_TIME             DATETIME,                               /* Transaction Time */
    DTYPE                CHAR(1) NOT NULL,                       /* Type of Transaction ( Credit or Debit ) */
    AMOUNT               DECIMAL(10,4),                          /* How Much Was Transaction */
    DTEXT                VARCHAR(255),                           /* Free Text Comment */
    QUANTITY             DECIMAL(10,4),                          /* Quantity Involved */
    COST                 DECIMAL(10,4),                          /* Cost of Transaction */
    RTN_ID               INTEGER,                                /* Return Internal ID */
    BIL_BAT_ID           INTEGER,                                /* Batch Billing Internal ID */

    CONSTRAINT PK_FIL_CDT PRIMARY KEY (ID)
);


/*
@Table           Fill Image
@Usage           Stores the Link Between a Prescription and An Image
@Category        Script,Image
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_IMG
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    IMG_QUE_ID           VARCHAR(50) NOT NULL,                   /* Link to Image Queue */
    RXF_ID               INTEGER,                                /* Rx Internal ID */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    DFL_ID               INTEGER,                                /* Deleted Fill Internal ID */
    DTYPE                CHAR(1) NOT NULL,                       /* Action that the marker stands for */
    XLOC                 INTEGER NOT NULL,                       /* Horizontal Location */
    YLOC                 INTEGER NOT NULL,                       /* Vertical Location */
    ROTATE_TYPE          INTEGER NOT NULL,                       /* Marker Orientation */
    COUNTER              INTEGER NOT NULL,                       /* Number to Display with Marker */

    CONSTRAINT PK_FIL_IMG PRIMARY KEY (ID)
);


/*
@Table           Fill Label Split
@Usage           Fill Pack Scan
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_PCK
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Fill Label Record */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    ERROR_FLAG           CHAR(1) NOT NULL,                       /* Error in Scanning Bar Code */
    RXF_NUMBER           INTEGER NOT NULL,                       /* Rx Number */
    SCAN_USR_ID          INTEGER,                                /* User who Scanned Record */
    SCAN_SYS_DATE        DATETIME,                               /* Date Fill was Scanned */
    SCAN_SYS_TIME        DATETIME,                               /* Time Fill was Scanned */
    SCAN_VALUE           VARCHAR(30),                            /* Value Entered from Keyboard or Scanner */

    CONSTRAINT PK_FIL_PCK PRIMARY KEY (ID)
);


/*
@Table           Fill Queue
@Usage           Fill Queue ( Pharmacist Review )
@Category        Script
@Related         0
@LOG_ENABLE      FALSE
@LOG_TEXT        FIL_ID
*/

CREATE TABLE dbo.FIL_QUE
(
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    QUE_ID               INTEGER NOT NULL,                       /* Queue Internal ID */
    RXF_ID               INTEGER NOT NULL,                       /* Rx Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    STATUS               CHAR(1),                                /* Status of the Fill in the Queue */
    LOCKED_FLAG          CHAR(1) NOT NULL,                       /* Shows Whether this Record is Currently in Use */
    USR_ID               INTEGER,                                /* User Who Has The Record Locked */

    CONSTRAINT PK_FIL_QUE PRIMARY KEY (FIL_ID)
);


/*
@Table           Fill Rejects
@Usage           Fill Rejects
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_REJ
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    SYS_DATE             DATETIME,                               /* Date Fill was Rejected */
    SYS_TIME             DATETIME,                               /* Time Fill was Rejected */
    USR_ID               INTEGER,                                /* User Who Has The Record Locked */

    CONSTRAINT PK_FIL_REJ PRIMARY KEY (ID)
);


/*
@Table           Fill Queue Routing
@Usage           Fill Queue Routing ( Pharmacist Review )
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FIL_ID,SEQ_NUM
*/

CREATE TABLE dbo.FIL_RTE
(
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Who Routed the Fill */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Routing */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Routing */
    SYS_TIME_HOUR        INTEGER,                                /* System Time Hour */
    STATUS               CHAR(1),                                /* Reason for Routing */

    CONSTRAINT PK_FIL_RTE PRIMARY KEY (FIL_ID,SEQ_NUM)
);


/*
@Table           Fill Ship
@Usage           Fill Shipping Table
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_SHP
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal ID Of The Fill Ship Record */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    COURIER_TYPE         CHAR(1) NOT NULL,                       /* Courier Type */
    TRACK_NO             VARCHAR(30) NOT NULL,                   /* Tracking Number */
    SHIP_COST            DECIMAL(10,4),                          /* Shipping Cost */
    EXCEPTION            VARCHAR(30),                            /* Exception */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */

    CONSTRAINT PK_FIL_SHP PRIMARY KEY (ID)
);


/*
@Table           3P Billing
@Usage           Stores Third Party Billing Record
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FIL_THP
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of Third Party Billing Record */
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal */
    SEQUENCE             INTEGER,                                /* Billing Sequence 0 - Primary, 1 - Secondary */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal */
    THP_ID               VARCHAR(12) NOT NULL,                   /* Third Party Initial */
    BATCH                CHAR(1) NOT NULL,                       /* Batch Claim */
    CLAIM_ACTIVE         CHAR(1) NOT NULL,                       /* Claim Active */
    MESSAGE_FLAG         CHAR(1) NOT NULL,                       /* Message in Claim Response */
    DUR_FLAG             CHAR(1) NOT NULL,                       /* DUR in Claim Response */
    REVERSAL_FLAG        CHAR(1) NOT NULL,                       /* Claim Reversed */
    STATUS               CHAR(1) NOT NULL,                       /* Submit Status */
    CLAIM_STATUS         CHAR(1) NOT NULL,                       /* Claim Status */
    RX_ORIGIN            CHAR(1) NOT NULL,                       /* Rx Origin */
    BILL_DATE            DATETIME,                               /* Date to be Billed to Insurance */
    SUB_DATE             DATETIME,                               /* Date Last Submitted to Insurance */
    PAY_DATE             DATETIME,                               /* Date Insurance Paid */
    SUB_DUE              DECIMAL(10,4),                          /* Due Submitted to Third Party */
    SUB_COST             DECIMAL(10,4),                          /* Cost Submitted to Third Party */
    SUB_FEE              DECIMAL(10,4),                          /* Fee Submitted to Third Party */
    SUB_TAX              DECIMAL(10,4),                          /* Tax Submitted to Third Party */
    SUB_COPAY            DECIMAL(10,4),                          /* Copay Submitted to Third Party */
    DUE                  DECIMAL(10,4),                          /* Due Returned by Third Party */
    COST                 DECIMAL(10,4),                          /* Cost Returned by Third Party */
    FEE                  DECIMAL(10,4),                          /* Fee Returned by Third Party */
    TAX                  DECIMAL(10,4),                          /* Tax Returned by Third Party */
    COPAY                DECIMAL(10,4),                          /* Copay Returned by Third Party */
    PAID                 DECIMAL(10,4),                          /* Amount Paid by Third Party */
    INCENTIVE            DECIMAL(10,4),                          /* Incentive Paid by Third Party */
    OTH_COVERAGE         VARCHAR(2),                             /* Other Coverage Code */
    AUTH_CODE            VARCHAR(2),                             /* Prior Authorization Code */
    PRIOR_AUTH           VARCHAR(11),                            /* Prior Authorization Number */
    AUTHORIZE            VARCHAR(25),                            /* Claim Authorization Number */
    REF_NUMBER           VARCHAR(20),                            /* Paid Claim Check Number */

    CONSTRAINT PK_FIL_THP PRIMARY KEY (ID)
);


/*
@Table           Fill Auxiliary
@Usage           Stores extra info for Fills (IV's)
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FIL_ID
*/

CREATE TABLE dbo.FLA
(
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    DATE_DUE             DATETIME,                               /* Date Fill is Due to be Refilled */
    TIME_DUE             DATETIME,                               /* Time Fill is Due to be Refilled */
    IDM_ID               INTEGER,                                /* Irregular Dosage Mix Table Internal ID */
    IDS_ID               INTEGER,                                /* Irregular Dosage Schedule Table Internal ID */
    FAC_TYPE             CHAR(1),                                /* Change FAC.TYPE to this Facility Type for this GPI Code */

    CONSTRAINT PK_FLA PRIMARY KEY (FIL_ID)
);


/*
@Table           Form Save
@Usage           Saves Settings for a Form/Report
@Category        System,Reports
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.FRM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    CLASS_NAME           VARCHAR(60) NOT NULL,                   /* Class Name ("TABBReport") (Group Key) */
    DNAME                VARCHAR(30) NOT NULL,                   /* Name */
    DTEXT                VARCHAR(70),                            /* Description */
    PRIVATE_FLAG         CHAR(1),                                /* T/F Values can Only be Changed by this User */
    FAC_ID               INTEGER,                                /* Facility that a Remote User is tied to */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Internal Id */
    SYS_DATE             DATETIME NOT NULL,                      /* System Date of Original Record Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* System Time of Original Record Entry */

    CONSTRAINT PK_FRM PRIMARY KEY (ID)
);


/*
@Table           Form Item Save
@Usage           Line Item Table for Saving Settings of a Form/Report
@Category        System,Reports
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FRM_ID,FIELD_NAME,SEQ_NUM
*/

CREATE TABLE dbo.FRM_ITM
(
    FRM_ID               INTEGER NOT NULL,                       /* FRM Internal ID */
    FIELD_NAME           VARCHAR(255) NOT NULL,                  /* Short Identifier for each field being saved */
    FIELD_VALUE          VARCHAR(255),                           /* Value of the Field being Saved */
    SEQ_NUM              INTEGER NOT NULL,                       /* Used to Hook Multiple Lines Together if Needed */

    CONSTRAINT PK_FRM_ITM PRIMARY KEY (FRM_ID,FIELD_NAME,SEQ_NUM)
);


/*
@Table           Group
@Usage           Group
@Category        Misc
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.GRP
(
    ID                   VARCHAR(8) NOT NULL,                    /* Short Description Of Group */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Longer Description Of Group */

    CONSTRAINT PK_GRP PRIMARY KEY (ID)
);


/*
@Table           Holiday Date
@Usage           Dates Observed for Holidays
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.HDT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Holiday Date */
    DTEXT                VARCHAR(30),                            /* Holiday Description */
    DDATE                DATETIME,                               /* Date of Holiday */
    ACTIVE               CHAR(1) NOT NULL,                       /* Date is an Active Holiday */

    CONSTRAINT PK_HDT PRIMARY KEY (ID)
);


/*
@Table           Unique ID
@Usage           Generic Cross Database ID Generator
@Category        System
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TABLENAME,FIELDNAME
*/

CREATE TABLE dbo.IDD
(
    TABLENAME            VARCHAR(30) NOT NULL,                   /* Table Name for which to generate ID */
    FIELDNAME            VARCHAR(30) NOT NULL,                   /* Field Name for which to generate ID */
    NEXTID               INTEGER NOT NULL,                       /* Next Valid ID to Use */

    CONSTRAINT PK_IDD PRIMARY KEY (TABLENAME,FIELDNAME)
);


/*
@Table           Irregular Drug Ingredient
@Usage           Ingredient Information for Irregular Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID,IDM_ID,SEQ_NUM
*/

CREATE TABLE dbo.IDI
(
    RXF_ID               INTEGER NOT NULL,                       /* Rx Internal ID */
    IDM_ID               INTEGER NOT NULL,                       /* Irregular Drug Mix ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Ingredient # out of List */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    QTY                  DECIMAL(10,4),                          /* Quantity of this Drug in the whole Drug */
    QTY_UNIT             CHAR(1) NOT NULL,                       /* Units of the Qty Field */
    VOLUME               DECIMAL(10,4),                          /* Volume of this Drug in the whole Drug */
    VOLUME_UNIT          CHAR(1) NOT NULL,                       /* Units of the Volume Field */
    DTYPE                CHAR(1) NOT NULL,                       /* (D)rug,(S)olution */

    CONSTRAINT PK_IDI PRIMARY KEY (RXF_ID,IDM_ID,SEQ_NUM)
);


/*
@Table           Irregular Drug Mix
@Usage           Dispensing/Various Information for Irregular Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID,SEQ_NUM
*/

CREATE TABLE dbo.IDM
(
    RXF_ID               INTEGER NOT NULL,                       /* Rx Internal ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Ingredient # out of List */
    FLOW_QTY             DECIMAL(10,4),                          /* Amount of Drug */
    FLOW_TIME            DATETIME,                               /* Amount of Time to Dispense Medication */
    FLOW_UNIT            CHAR(1) NOT NULL,                       /* Units of Dispensing Drug */
    VOL_UNIT             CHAR(1) NOT NULL,                       /* Units of Drug in Bag */
    ACTIVE_FLAG          CHAR(1) NOT NULL,                       /* If Mix is Active, it gets Filled */
    HOLD_FLAG            CHAR(1) NOT NULL,                       /* Temporarily on Hold */
    SIG                  VARCHAR(151),                           /* can Resolve like a normal SIG, but Specific Instructions */
    ROOM_KEEP            VARCHAR(10),                            /* Free Text, How long will Medication keep at Room Temp */
    REFRIG_KEEP          VARCHAR(10),                            /* Free Text, How long will Medication keep in Fridge */
    FROZEN_KEEP          VARCHAR(10),                            /* Free Text, How long will Medication keep in Freezer */
    DNOTE                VARCHAR(30),                            /* Special Note */
    DSTABILITY           VARCHAR(60),                            /* Free Text Comment on the Stability of the Medication */
    SPEC_HANDLING        VARCHAR(60),                            /* Special Handling Instructions */
    ADMINISTERING        VARCHAR(60),                            /* Administering Instructions */

    CONSTRAINT PK_IDM PRIMARY KEY (RXF_ID,SEQ_NUM)
);


/*
@Table           Irregular Drug Mix Note
@Usage           Notes for Irregular Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID,IDM_SEQ_NUM,NOTE_NUM
*/

CREATE TABLE dbo.IDM_NOT
(
    RXF_ID               INTEGER NOT NULL,                       /* Rx Internal ID */
    IDM_SEQ_NUM          INTEGER NOT NULL,                       /* Ingredient # out of List */
    NOTE_NUM             INTEGER NOT NULL,                       /* Sequence # of Note for this Mix */
    DNOTE                VARCHAR(70),                            /* The Note */

    CONSTRAINT PK_IDM_NOT PRIMARY KEY (RXF_ID,IDM_SEQ_NUM,NOTE_NUM)
);


/*
@Table           Irregular Drug Rx
@Usage           Stores Details for Irregular Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID
*/

CREATE TABLE dbo.IDR
(
    RXF_ID               INTEGER NOT NULL,                       /* Rx Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    PRN_START_DATE       DATETIME,                               /* Date Started if PRN */
    PRN_STOP_DATE        DATETIME,                               /* Date Stopped if PRN */
    PRN_MAX_FILLS        INTEGER,                                /* Max # of Fills if PRN */
    DTYPE                CHAR(1),                                /* Type of IV */
    ON_HOLD_FLAG         CHAR(1),                                /* T/F If on Hold, don't fill IV */

    CONSTRAINT PK_IDR PRIMARY KEY (RXF_ID)
);


/*
@Table           Irregular Dosage Schedule
@Usage           Stores Dosage Schedules for Irregular Drugs
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.IDS
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */

    CONSTRAINT PK_IDS PRIMARY KEY (ID)
);


/*
@Table           Drug Image Filename
@Usage           Stores Drug Image Filename
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.IMG
(
    ID                   VARCHAR(20) NOT NULL,                   /* Internal ID */
    IDTYPE               VARCHAR(2),                             /* ID Qualifer */
    START_DATE           DATETIME,                               /* Valid Start Date */
    STOP_DATE            DATETIME,                               /* Valid End Date */
    FILENAME             VARCHAR(10),                            /* Filename without the extension */

    CONSTRAINT PK_IMG PRIMARY KEY (ID)
);


/*
@Table           Image Queue
@Usage           Script Image Queue
@Category        Image
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.IMG_QUE
(
    ID                   VARCHAR(50) NOT NULL,                   /* Link to Image */
    QUE_ID               INTEGER NOT NULL,                       /* Queue ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    STATUS               CHAR(1),                                /* Status of the Image */
    DOCUCLASS_FLAG       CHAR(1) NOT NULL,                       /* This Image has been Archived with DocuClass */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    CLARIFY_FLAG         CHAR(1) NOT NULL,                       /* The Image Has A 'Clarification' Marker On It */
    PROCESS_SYS_DATE     DATETIME,                               /* Date of Image Being Closed */
    PROCESS_SYS_TIME     DATETIME,                               /* Time of Image Being Closed */
    PROCESS_USR_ID       INTEGER,                                /* User Who Closed the Image */
    USR_ID               INTEGER,                                /* User Who Has The Record Locked */
    POSTPONE_DATE        DATETIME,                               /* Cips will treat this image as tomorrow's work until it hits this date */

    CONSTRAINT PK_IMG_QUE PRIMARY KEY (ID)
);


/*
@Table           Interface Incoming
@Usage           Messages Coming into CIPS
@Category        Interface
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.INI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    CONTROL_ID           VARCHAR(60) NOT NULL,                   /* Unique ID from Sending Application */
    DMESSAGE             VARCHAR( MAX ) NOT NULL,                /* Full Message Text */
    FILE_NAME            VARCHAR(255),                           /* Message File Name */
    DTYPE                VARCHAR(10) NOT NULL,                   /* Task Type */
    DCODE                VARCHAR(10),                            /* Task Code */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record Was Created */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record Was Created */
    PROCESSED            CHAR(1) NOT NULL,                       /* Processed Status */
    PROCESSED_DATE       DATETIME,                               /* Date Record Was Processed */
    PROCESSED_TIME       DATETIME,                               /* Time Record Was Processed */
    RELATED_CONTROL_ID   VARCHAR(60),                            /* Related Control ID */
    VERSION              VARCHAR(20),                            /* Version of Interface */

    CONSTRAINT PK_INI PRIMARY KEY (ID)
);


/*
@Table           Interface Note
@Usage           Interface Note
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.INI_NOT
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal Id */
    INI_ID               INTEGER,                                /* Interface */
    PHR_ID               INTEGER,                                /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Title Of The Note */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* Type of Note */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Internal ID */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_INI_NOT PRIMARY KEY (ID)
);


/*
@Table           Interface Outgoing
@Usage           Messages Going Out of CIPS
@Category        Interface
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.INO
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RGN_ID               INTEGER,                                /* Region */
    FAC_ID               INTEGER,                                /* Facility */
    DRG_ID               INTEGER,                                /* Drug */
    PAT_ID               INTEGER,                                /* Patient */
    RXF_ORD_ID           INTEGER,                                /* Rx */
    RXF_ID               INTEGER,                                /* Rx */
    FIL_ID               INTEGER,                                /* Fill */
    TBX_ID               VARCHAR(23),                            /* Batch Number */
    DTYPE                VARCHAR(10) NOT NULL,                   /* Task Type */
    DCODE                VARCHAR(10),                            /* Task Code */
    CONTROL_ID           VARCHAR(60),                            /* Unique ID from Sending Application */
    DEVENT               CHAR(1) NOT NULL,                       /*  */
    DTABLE               CHAR(1) NOT NULL,                       /*  */
    DMESSAGE             VARCHAR( MAX ),                         /* Full Message Text */
    FILE_NAME            VARCHAR(255),                           /* Message File Name */
    API_VERSION          VARCHAR(10),                            /* CIPS Client API Version */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record Was Created */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record Was Created */
    PROCESSED            CHAR(1) NOT NULL,                       /* Processed Status */
    PROCESSED_DATE       DATETIME,                               /* Date Record Was Processed */
    PROCESSED_TIME       DATETIME,                               /* Time Record Was Processed */

    CONSTRAINT PK_INO PRIMARY KEY (ID)
);


/*
@Table           Remote Instructions
@Usage           Stores Instructions for Remote Dropdown
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.INS
(
    ID                   VARCHAR(8) NOT NULL,                    /* Short Code */
    DTEXT                VARCHAR(30),                            /* Instruction Description */
    FAC_ID               INTEGER,                                /* Internal ID of this Facility */
    RGN_ID               INTEGER,                                /* Internal ID of this Region */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Dormant Instruction Will Not Be Accessible */

    CONSTRAINT PK_INS PRIMARY KEY (ID)
);


/*
@Table           Drug Imprint File
@Usage           Stores Drug Imprint Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,NDC,LANG_CODE,START_DATE
*/

CREATE TABLE dbo.IPD
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    NDC                  VARCHAR(20) NOT NULL,                   /* Drug NDC Number */
    LANG_CODE            INTEGER NOT NULL,                       /* Language for Record */
    START_DATE           DATETIME NOT NULL,                      /* Start Date for Record */
    STOP_DATE            DATETIME,                               /* Stop Date for Record */
    IMPRINT1             VARCHAR(40),                            /* First Imprint */
    IMPRINT2             VARCHAR(40),                            /* Second Imprint */

    CONSTRAINT PK_IPD PRIMARY KEY (ID,NDC,LANG_CODE,START_DATE)
);


/*
@Table           Drug Imprint Description
@Usage           Stores Drug Imprint Description Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CATEGORY_CODE,DESCRIPTOR_CODE,LANG_CODE,COUNTRY
*/

CREATE TABLE dbo.IPE
(
    CATEGORY_CODE        INTEGER NOT NULL,                       /* Category Code */
    DESCRIPTOR_CODE      INTEGER NOT NULL,                       /* Descriptor Code */
    LANG_CODE            INTEGER NOT NULL,                       /* Language Code */
    COUNTRY              INTEGER NOT NULL,                       /* Country Code */
    DTEXT                VARCHAR(30),                            /* Descriptive Text */

    CONSTRAINT PK_IPE PRIMARY KEY (CATEGORY_CODE,DESCRIPTOR_CODE,LANG_CODE,COUNTRY)
);


/*
@Table           Imprint Descriptor
@Usage           Stores Drug Imprint Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,NDC,START_DATE,TEXT_CODE
*/

CREATE TABLE dbo.IPI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    NDC                  VARCHAR(20) NOT NULL,                   /* NDC */
    START_DATE           DATETIME NOT NULL,                      /* Start Date */
    TEXT_CODE            INTEGER NOT NULL,                       /* Text Code */

    CONSTRAINT PK_IPI PRIMARY KEY (ID,NDC,START_DATE,TEXT_CODE)
);


/*
@Table           Imprint Drug Descriptor
@Usage           Stores Drug Imprint Descriptor Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,NDC,START_DATE,CATEGORY_CODE,DESCRIPTOR_CODE
*/

CREATE TABLE dbo.IPR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    NDC                  VARCHAR(20) NOT NULL,                   /* NDC */
    START_DATE           DATETIME NOT NULL,                      /* Start Date */
    CATEGORY_CODE        INTEGER NOT NULL,                       /* Category Code */
    DESCRIPTOR_CODE      INTEGER NOT NULL,                       /* Descriptor Code */

    CONSTRAINT PK_IPR PRIMARY KEY (ID,NDC,START_DATE,CATEGORY_CODE,DESCRIPTOR_CODE)
);


/*
@Table           Imprint Text File
@Usage           Stores Drug Imprint Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TEXT_CODE,LANG_CODE,COUNTRY,LINE_NUMBER
*/

CREATE TABLE dbo.IPX
(
    TEXT_CODE            INTEGER NOT NULL,                       /* Text Code */
    LANG_CODE            INTEGER NOT NULL,                       /* Language Code */
    COUNTRY              INTEGER NOT NULL,                       /* Country Code */
    LINE_NUMBER          INTEGER NOT NULL,                       /* Text Line Number */
    DTEXT                VARCHAR(70),                            /* Text */

    CONSTRAINT PK_IPX PRIMARY KEY (TEXT_CODE,LANG_CODE,COUNTRY,LINE_NUMBER)
);


/*
@Table           Issue Category Item
@Usage           Warehouse Groups Drugs in Issueing Categories Information
@Category        Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CATEGORY_CODE
*/

CREATE TABLE dbo.ISC
(
    CATEGORY_CODE        VARCHAR(11) NOT NULL,                   /* Category Code */
    DTEXT                VARCHAR(30),                            /* Text */
    FRIDGE_FLAG          CHAR(1) NOT NULL,                       /* T/F Drug needs to be Refrigerated */

    CONSTRAINT PK_ISC PRIMARY KEY (CATEGORY_CODE)
);


/*
@Table           Irregular Standard Order Ingredient
@Usage           Stores Standard Irregular Drug Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,ISR_ID,ISM_ID
*/

CREATE TABLE dbo.ISI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    ISR_ID               INTEGER NOT NULL,                       /* ISR Internal ID */
    ISM_ID               INTEGER NOT NULL,                       /* ISM Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    QTY                  DECIMAL(10,4),                          /* Quantity of this Drug in the Whole Drug */
    QTY_UNIT             CHAR(1) NOT NULL,                       /* Units of the Quantity Field */
    VOLUME               DECIMAL(10,4),                          /* Volume of this Drug in the Whole Drug */
    VOLUME_UNIT          CHAR(1) NOT NULL,                       /* Units of the Volume Field */
    DTYPE                CHAR(1) NOT NULL,                       /* (D)rug,(S)olution */

    CONSTRAINT PK_ISI PRIMARY KEY (ID,ISR_ID,ISM_ID)
);


/*
@Table           Irregular Drug Standard Order Mix
@Usage           Stores Standard Irregular Drug Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,ISR_ID
*/

CREATE TABLE dbo.ISM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    ISR_ID               INTEGER NOT NULL,                       /* ISR Internal ID */
    FLOW_QTY             DECIMAL(10,4),                          /* Amount of Drug */
    FLOW_TIME            DATETIME,                               /* Amount of Time to Dispense Medication */
    FLOW_UNIT            CHAR(1) NOT NULL,                       /* Unit of Dispensing Drug */
    VOL_UNIT             CHAR(1) NOT NULL,                       /* Unit of Drug in Bag */
    SIG                  VARCHAR(151),                           /* Specific Instructions that can Resolve like a Normal SIG */
    ROOM_KEEP            VARCHAR(10),                            /* How Long Medication will keep at Room Temp */
    FRIDGE_KEEP          VARCHAR(10),                            /* How Long Medication will keep in Refrigerator */
    FROZEN_KEEP          VARCHAR(10),                            /* How Long Medication will keep in Freezer */
    DNOTE                VARCHAR(30),                            /* Special Note */
    DSTABILITY           VARCHAR(60),                            /* Free Text Comment on the Stability of the Medication */
    SPEC_HANDLING        VARCHAR(60),                            /* Special Handling Instructions */
    ADMINISTERING        VARCHAR(60),                            /* Administering Instructions */

    CONSTRAINT PK_ISM PRIMARY KEY (ID,ISR_ID)
);


/*
@Table           Irregular Standard Order Rx
@Usage           Stores Standard Irregular Drug Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ISR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PRN_START_DATE       DATETIME,                               /* Date Started if PRN */
    PRN_STOP_DATE        DATETIME,                               /* Date Stopped if PRN */
    PRN_MAX_FILLS        INTEGER,                                /* Max # of Fills if PRN */
    DTYPE                CHAR(1),                                /* Type of IV */
    DTEXT                VARCHAR(80),                            /* Descriptive Text */

    CONSTRAINT PK_ISR PRIMARY KEY (ID)
);


/*
@Table           Irregular Standard Order Schedule
@Usage           Stores Standard Irregular Information
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ISS
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */

    CONSTRAINT PK_ISS PRIMARY KEY (ID)
);


/*
@Table           IV Class
@Usage           Stores IV Class Info
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        KDC_NUM,CLASS
*/

CREATE TABLE dbo.IVC
(
    KDC_NUM              VARCHAR(5) NOT NULL,                    /* Medispan Factor */
    CLASS                VARCHAR(5) NOT NULL,                    /* Medispan Factor */

    CONSTRAINT PK_IVC PRIMARY KEY (KDC_NUM,CLASS)
);


/*
@Table           KDC Number Cross Reference
@Usage           Stores IV Class Info
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        KDC_NUM,DRUG_NAME
*/

CREATE TABLE dbo.IVG
(
    KDC_NUM              VARCHAR(10) NOT NULL,                   /* Medispan Factor */
    DRUG_NAME            VARCHAR(50) NOT NULL,                   /* Drug Name */

    CONSTRAINT PK_IVG PRIMARY KEY (KDC_NUM,DRUG_NAME)
);


/*
@Table           NDC Number Cross Reference
@Usage           Stores IV Class Info
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        KDC_NUM,NDC
*/

CREATE TABLE dbo.IVN
(
    KDC_NUM              VARCHAR(10) NOT NULL,                   /* KDC Number */
    NDC                  VARCHAR(9) NOT NULL,                    /* NDC */

    CONSTRAINT PK_IVN PRIMARY KEY (KDC_NUM,NDC)
);


/*
@Table           Monograph
@Usage           
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        MONO_ID
*/

CREATE TABLE dbo.IVO
(
    MONO_ID              VARCHAR(6) NOT NULL,                    /* Mono ID */
    KDC_NUM1             VARCHAR(10),                            /* KDC Number 1 */
    KDC_NUM2             VARCHAR(10),                            /* KDC Number 2 */
    KDC_NUM3             VARCHAR(10),                            /* KDC Number 3 */
    KDC_NUM4             VARCHAR(10),                            /* KDC Number 4 */
    KDC_NUM5             VARCHAR(10),                            /* KDC Number 5 */
    KDC_NUM6             VARCHAR(10),                            /* KDC Number 6 */
    KDC_NUM7             VARCHAR(10),                            /* KDC Number 7 */
    ENT_DIST             CHAR(1),                                /* ENT_DIST */
    SUM_DIST             CHAR(1),                                /* SUM_DIST */
    PRM_DIST             CHAR(1),                                /* PRM_DIST */
    STM_DIST             CHAR(1),                                /* STM_DIST */
    ADM_DIST             CHAR(1),                                /* ADM_DIST */
    STR_MESS1            VARCHAR(3),                             /* Message 1 */
    STR_MESS2            VARCHAR(3),                             /* Message 2 */
    STR_MESS3            VARCHAR(3),                             /* Message 3 */
    STR_MESS4            VARCHAR(3),                             /* Message 4 */
    STR_MESS5            VARCHAR(3),                             /* Message 5 */
    STR_MESS6            VARCHAR(3),                             /* Message 6 */
    STR_MESS7            VARCHAR(3),                             /* Message 7 */

    CONSTRAINT PK_IVO PRIMARY KEY (MONO_ID)
);


/*
@Table           Solution Set Table
@Usage           
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        MONO_ID
*/

CREATE TABLE dbo.IVS
(
    MONO_ID              VARCHAR(6) NOT NULL,                    /* Mono ID */
    SEQ_NUM              INTEGER,                                /* Sequence */
    ROOM_TIME            INTEGER,                                /* Room Time */
    FRIDGE_TIME          INTEGER,                                /* Fridge Time */
    CIT1                 INTEGER,                                /* CIT 1 */
    CIT2                 INTEGER,                                /* CIT 2 */
    CIT3                 INTEGER,                                /* CIT 3 */
    CIT4                 INTEGER,                                /* CIT 4 */
    CIT5                 INTEGER,                                /* CIT 5 */
    CIT6                 INTEGER,                                /* CIT 6 */
    CIT7                 INTEGER,                                /* CIT 7 */
    CIT8                 INTEGER,                                /* CIT 8 */
    RATING               CHAR(1),                                /* Rating */
    CON_LEV              CHAR(1),                                /* CON_LEV */
    SOL_TYPE1            CHAR(1),                                /* SOL_TYPE1 */
    SOL_TYPE2            CHAR(1),                                /* SOL_TYPE2 */
    SOL_TYPE3            CHAR(1),                                /* SOL_TYPE3 */
    SOLUTION1            VARCHAR(10),                            /* Solution 1 */
    SOLUTION2            VARCHAR(10),                            /* Solution 2 */
    SOLUTION3            VARCHAR(10),                            /* Solution 3 */

    CONSTRAINT PK_IVS PRIMARY KEY (MONO_ID)
);


/*
@Table           Message
@Usage           Stores Messages
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CODE
*/

CREATE TABLE dbo.IVT
(
    CODE                 VARCHAR(3) NOT NULL,                    /* Code */
    DTEXT                VARCHAR(72),                            /* Text */

    CONSTRAINT PK_IVT PRIMARY KEY (CODE)
);


/*
@Table           Monograph Text
@Usage           Stores Monograph Texts
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        MONO_ID,TEXT_TYPE
*/

CREATE TABLE dbo.IVX
(
    MONO_ID              VARCHAR(6) NOT NULL,                    /* MONO_ID */
    TEXT_TYPE            VARCHAR(3) NOT NULL,                    /* Text Type */
    DTEXT                VARCHAR(3039),                          /* Text */

    CONSTRAINT PK_IVX PRIMARY KEY (MONO_ID,TEXT_TYPE)
);


/*
@Table           Table Format Information
@Usage           Table Format
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.JBL
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    USR_ID               INTEGER NOT NULL,                       /* Operator ID */
    NAME                 VARCHAR(30) NOT NULL,                   /* Description of Table To Arrange */

    CONSTRAINT PK_JBL PRIMARY KEY (ID)
);


/*
@Table           Table Layout Item
@Usage           Store Index and Field
@Category        TBL
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        JBL_ID, SEQUENCE
*/

CREATE TABLE dbo.JBL_ITM
(
    JBL_ID               INTEGER NOT NULL,                       /* Jable ID */
    SEQUENCE             INTEGER NOT NULL,                       /* Index */
    FIELD                VARCHAR(50),                            /* Field */

    CONSTRAINT PK_JBL_ITM PRIMARY KEY (JBL_ID, SEQUENCE)
);


/*
@Table           Batch Label
@Usage           Stores Info for Batch Labels
@Category        Labels
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        BATCH_ID,SYS_DATE
*/

CREATE TABLE dbo.LAB
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Batch Label Record */
    BATCH_ID             INTEGER NOT NULL,                       /* Batch ID of this Batch Label Record */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    RXF_ID               INTEGER,                                /* Script Internal ID */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    RXF_ORD_ID           INTEGER,                                /* Order Internal ID */
    LABEL_TYPE           CHAR(1) NOT NULL,                       /* Type of Label to Print On */
    LABEL_COUNT          INTEGER NOT NULL,                       /* How Many Labels are to be Printed? */
    GENERATED_FROM       CHAR(1) NOT NULL,                       /* What Generated this Record? */
    VOID_FLAG            CHAR(1) NOT NULL,                       /* T/F Record has been Voided */
    PRINT_FLAG           CHAR(1) NOT NULL,                       /* T/F Record has been Printed */
    PRINT_DATE           DATETIME,                               /* Date of Record Printing */
    PRINT_TIME           DATETIME,                               /* Time of Record Printing */
    PRINT_USR_ID         INTEGER,                                /* User Logged In at Record Printing */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged In at Record Creation */

    CONSTRAINT PK_LAB PRIMARY KEY (ID)
);


/*
@Table           Labels
@Usage           Used to Specify Label Types and Label File Names
@Category        Labels
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.LBL
(
    ID                   INTEGER NOT NULL,                       /* Short Label Identifier */
    DTYPE                CHAR(1) NOT NULL,                       /* Identifies the Type of Label */
    LBL_FILE             VARCHAR(255),                           /* Label File Name */

    CONSTRAINT PK_LBL PRIMARY KEY (ID)
);


/*
@Table           Location
@Usage           Patient Locations
@Category        Patient Locations
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.LOC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of The Location */
    FAC_ID               INTEGER NOT NULL,                       /* Location's Facility */
    LOCATION             VARCHAR(40),                            /* Patient's Current Location */
    UNIT                 VARCHAR(10),                            /* Patient's Current Unit */
    WING                 VARCHAR(10),                            /* Patient's Current Wing */
    ROOM                 VARCHAR(10),                            /* Patient's Current Room */
    BED                  VARCHAR(10),                            /* Patient's Current Bed */

    CONSTRAINT PK_LOC PRIMARY KEY (ID)
);


/*
@Table           Drug Lot Number
@Usage           Stores Drug Lots
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.LOT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    NUMBER               VARCHAR(12) NOT NULL,                   /* Manufacturer Lot Number */
    EXPIRES              DATETIME,                               /* Expires On Date */
    ONHAND               DECIMAL(10,4),                          /* Quantity Onhand at Pharmacy */

    CONSTRAINT PK_LOT PRIMARY KEY (ID)
);


/*
@Table           Long Term Scripts
@Usage           Used to Keep Track of Long Term Scripts
@Category        Long Term Scripts
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID
*/

CREATE TABLE dbo.LTM
(
    RXF_ID               INTEGER NOT NULL,                       /* Script Internal ID */
    DSTATUS              CHAR(1) NOT NULL,                       /* Long Term Script Status */
    DV_USR_ID            INTEGER NOT NULL,                       /* User Logged In at Record Creation */
    DOC_ID               INTEGER,                                /* Doctor for this Long Term Script */
    DV_SYS_DATE          DATETIME NOT NULL,                      /* Date of Record Creation */
    DV_SYS_TIME          DATETIME NOT NULL,                      /* Time of Record Creation */

    CONSTRAINT PK_LTM PRIMARY KEY (RXF_ID)
);


/*
@Table           Manufacturer
@Usage           Stores Manufacturers
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.MAN
(
    ID                   INTEGER NOT NULL,                       /* This ID is the link between the Drug NDC and the Manufacturer Record */
    ABB                  VARCHAR(5),                             /* 5 Char Short Code */
    ABB2                 VARCHAR(2),                             /* 2 Char Abbreviation */
    LABELER              VARCHAR(10),                            /* 10 Char Labeler Abbreviation */
    VEN_ID               INTEGER,                                /* Vendor Internal ID */
    DNAME                VARCHAR(30),                            /* Description Name of Manufacturer */

    CONSTRAINT PK_MAN PRIMARY KEY (ID)
);


/*
@Table           Medical Condition Name
@Usage           Stores Medical Condition Names
@Category        Drug
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.MCN
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    CODE                 INTEGER NOT NULL,                       /* Condition Code */
    COUNTRY              INTEGER NOT NULL,                       /* Country Code */
    LANGUAGE             INTEGER NOT NULL,                       /* Language Code */
    TYPE                 INTEGER NOT NULL,                       /* Type */
    NAME                 VARCHAR(58) NOT NULL,                   /* Condition Name */
    RESERVE              VARCHAR(24),                            /* Reserve */

    CONSTRAINT PK_MCN PRIMARY KEY (ID)
);


/*
@Table           Med Cart
@Usage           Stores Information for the Med Cart
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FIL_ID
*/

CREATE TABLE dbo.MDC
(
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FIL_DATE             DATETIME,                               /* Fill Date */
    PRINT_FLAG           CHAR(1) NOT NULL,                       /* T/F This Record has been Printed */
    VIEW_FLAG            CHAR(1) NOT NULL,                       /* T/F This Record has been Viewed */

    CONSTRAINT PK_MDC PRIMARY KEY (FIL_ID)
);


/*
@Table           Medication
@Usage           Drug List from Medispan
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.MED
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DNAME                VARCHAR(30),                            /* Name of Drug */
    STRENGTH             VARCHAR(25),                            /* Strength of Drug */
    DOSAGE               VARCHAR(4),                             /* Dosage of Drug */
    GPI                  VARCHAR(16),                            /* GPI of Drug */
    DGENERIC             CHAR(1),                                /* G-Generic, B-Brand */
    ROA                  VARCHAR(2),                             /* Route of Administration */
    DEA                  CHAR(1),                                /* DEA Schedule of Drug */
    KDC                  VARCHAR(10) NOT NULL,                   /* KDC Number */

    CONSTRAINT PK_MED PRIMARY KEY (ID)
);


/*
@Table           Message
@Usage           Allows Messages To Be Shown
@Category        Message
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        HEADING
*/

CREATE TABLE dbo.MSG
(
    ID                   INTEGER NOT NULL,                       /* Message Internal Id */
    HEADING              VARCHAR(60),                            /* Heading of the Message */
    DTEXT                VARCHAR(255),                           /* Text of the Message */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record was entered */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record was entered */
    SHOW_ONCE_FLAG       CHAR(1) NOT NULL,                       /* Show this Message Only Once */

    CONSTRAINT PK_MSG PRIMARY KEY (ID)
);


/*
@Table           Message Item
@Usage           Stores Information About a Message and User
@Category        Message
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        MSG_ID
*/

CREATE TABLE dbo.MSG_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    MSG_ID               INTEGER NOT NULL,                       /* Message ID */
    USR_ID               INTEGER NOT NULL,                       /* User that the Message is Assigned To */
    VIEW_FLAG            CHAR(1) NOT NULL,                       /* Has this Message been Viewed? */
    VIEW_DATE            DATETIME,                               /* Date Message was Viewed */
    VIEW_TIME            DATETIME,                               /* Time Message was Viewed */

    CONSTRAINT PK_MSG_ITM PRIMARY KEY (ID)
);


/*
@Table           Miscellaneous Name
@Usage           Stores Miscellaneous Name Information
@Category        Codes
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,DNAME
*/

CREATE TABLE dbo.NAM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Miscellaneous Name Record */
    DNAME                VARCHAR(60) NOT NULL,                   /* Name */
    ADDRESS1             VARCHAR(60),                            /*  */
    ADDRESS2             VARCHAR(60),                            /*  */
    CITY                 VARCHAR(30),                            /*  */
    ST                   VARCHAR(2) NOT NULL,                    /*  */
    ZIP                  VARCHAR(10),                            /*  */
    PHONE                VARCHAR(14),                            /*  */
    FAX                  VARCHAR(20),                            /* Fax Number */
    CONTACT              VARCHAR(30),                            /*  */
    EMAIL                VARCHAR(50),                            /* E-Mail Address */

    CONSTRAINT PK_NAM PRIMARY KEY (ID)
);


/*
@Table           NDC
@Usage           Staging Table for Pricing to be loaded into so it is Readily Available
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.NDC
(
    ID                   INTEGER NOT NULL,                       /* NDC Internal Id */
    NDC                  VARCHAR(13) NOT NULL,                   /* NDC Number */
    NEW_NDC              VARCHAR(13),                            /* New NDC Number */
    GPI                  VARCHAR(16),                            /* GPI Code for NDC */
    KDC                  VARCHAR(10),                            /* Medispan Knowledge Base Drug Code */
    DDID                 INTEGER,                                /* Drug Descriptor ID */
    AWP_COST             DECIMAL(10,4),                          /* Auxiliary Wholesale Cost */
    DIR_COST             DECIMAL(10,4),                          /* Direct Cost from Manufacturer */
    GEN_COST1            DECIMAL(10,4),                          /* User Defined Cost */
    GEN_COST2            DECIMAL(10,4),                          /* User Defined Cost */
    GEN_COST3            DECIMAL(10,4),                          /* User Defined Cost */
    WAC_COST             DECIMAL(10,4),                          /* Wholesale Acquisition Cost */
    PUR_QTY              DECIMAL(10,4),                          /* Drug Purchase Quantity */
    CHANGEON             DATETIME,                               /* Date Cost Changed */
    TEE_CODE             VARCHAR(2),                             /* Tee Code From Med Update - DRG.ORANGE_BOOK */
    GPI_FLAG             CHAR(1) NOT NULL,                       /* Not Used */
    OTC_FLAG             CHAR(1) NOT NULL,                       /* T/F Drug is Over the Counter */
    PRC_FLAG             CHAR(1),                                /* Record Last Change Type */
    KDC_FLAG             CHAR(1) NOT NULL,                       /* Medispan Knowledge Base Drug Code Flag */
    DNAME                VARCHAR(12),                            /* Medispan Assigned Name */
    DOSAGE               VARCHAR(3),                             /* Medispan Assigned Dosage */
    STRENGTH             VARCHAR(8),                             /* Medispan Assigned Strength */
    ROUTE                VARCHAR(2),                             /* Medispan Assigned Route */
    PUR_UNIT             CHAR(1),                                /* Unit of Purchase for Packaging */
    PACK_QTY             INTEGER,                                /* Package Quantity - How much comes in a Package */
    SNAME                VARCHAR(6),                             /* Medispan Assigned Short Name */
    TCRF                 VARCHAR(6),                             /* Therapeutic Class Reference */
    PACKAGING_CODE       CHAR(1),                                /* Packaging Code */
    DESI_CODE            CHAR(1),                                /* Designation Code */
    MULTI_SRCE_CODE      CHAR(1),                                /* How many Sources will Make/Dispense this Drug */
    REIMBURSEMENT        CHAR(1),                                /* Reimbursement Code from Medispan */
    ITEM_STATUS          CHAR(1),                                /* Item Status Code */
    INNERPACK_CODE       CHAR(1),                                /* Inner Packing Code */
    CLINICPACK_CODE      CHAR(1),                                /* Item Packing Code for Clinics */

    CONSTRAINT PK_NDC PRIMARY KEY (ID)
);


/*
@Table           Non-Form Approval
@Usage           Non-Formulary Approval
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.NFA
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient ID */
    DRG_ID               INTEGER,                                /* Drug ID */
    RXF_ID               INTEGER,                                /* Rx ID */
    RXF_ORD_ID           INTEGER,                                /* Order ID */
    GPI                  VARCHAR(25),                            /* Therapeutic Class */
    APP_NUM              VARCHAR(10),                            /* Approval Number */
    ORG_DATE             DATETIME,                               /* Date Drug Was Approved */
    EXP_DATE             DATETIME,                               /* Date Drug's Approval Expires */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    COMMENT              VARCHAR(255),                           /* Comment About Approval */

    CONSTRAINT PK_NFA PRIMARY KEY (ID)
);


/*
@Table           Non-Screened Health Info
@Usage           Stores NHI Info
@Category        Patient,Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.NHI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DTEXT                VARCHAR(255) NOT NULL,                  /* Descriptive Text */

    CONSTRAINT PK_NHI PRIMARY KEY (ID)
);


/*
@Table           NM9 (ICD Code)
@Usage           ICD Names
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.NM9
(
    ID                   VARCHAR(10) NOT NULL,                   /* Medispan Supplied Code */
    DTEXT                VARCHAR(75) NOT NULL,                   /* Descriptive Text */
    CHRONIC_FLAG         CHAR(1) NOT NULL,                       /* This will be added to the patient's profile */
    DTYPE                CHAR(1) NOT NULL,                       /* Definition came from CDC's ICD-10 List */
    ICD9_EQUIVALENT      VARCHAR(10),                            /* The ICD-9 equivalent of this ICD-10 value */

    CONSTRAINT PK_NM9 PRIMARY KEY (ID)
);


/*
@Table           Script Order Note
@Usage           Stores Script Order Notes for Patients
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.ORD_NOT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RXF_ORD_ID           INTEGER NOT NULL,                       /* RXF Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Note Title */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* (S)cript Screen Notes, Plain (T)ext */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_ORD_NOT PRIMARY KEY (ID)
);


/*
@Table           Order Queue
@Usage           Rx Order Queue
@Category        Script
@Related         0
@LOG_ENABLE      FALSE
@LOG_TEXT        RXF_ORD_ID
*/

CREATE TABLE dbo.ORD_QUE
(
    RXF_ORD_ID           INTEGER NOT NULL,                       /* Rx Order Internal ID */
    QUE_ID               INTEGER NOT NULL,                       /* Queue Internal ID */
    PAT_ID               INTEGER,                                /* Patient Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    STATUS               CHAR(1),                                /* Status of the Order in the Queue */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    LOCKED_FLAG          CHAR(1) NOT NULL,                       /* Shows Whether this Record is Currently in Use */
    USR_ID               INTEGER,                                /* User Who Has The Record Locked */
    POSTPONE_DATE        DATETIME,                               /* Cips will treat this order as tomorrow's work until it hits this date */

    CONSTRAINT PK_ORD_QUE PRIMARY KEY (RXF_ORD_ID)
);


/*
@Table           Override Codes
@Usage           Used to specify transmission string to FilePro
@Category        FilePro
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DCODE,DTEXT
*/

CREATE TABLE dbo.OVR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Override Code */
    DCODE                VARCHAR(3) NOT NULL,                    /* Short Override Code */
    DTEXT                VARCHAR(50) NOT NULL,                   /* Long Description of Override Code */

    CONSTRAINT PK_OVR PRIMARY KEY (ID)
);


/*
@Table           Medispan PAR
@Usage           Medispan Prior Adverse Reactions
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PAR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DTEXT                VARCHAR(40) NOT NULL,                   /* Description Text */

    CONSTRAINT PK_PAR PRIMARY KEY (ID)
);


/*
@Table           Med Pass
@Usage           System Pass Times and MAR Boxes
@Category        Schedule
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PAS
(
    ID                   VARCHAR(10) NOT NULL,                   /* Code */
    DTEXT                VARCHAR(30),                            /* Pass Information */
    DTIME                DATETIME,                               /* Cutoff Time for New Orders for this Pass */
    BOX                  INTEGER,                                /* MAR Box for printing this time */
    TIME_FLAG            CHAR(1) NOT NULL,                       /* Print the Time Instead of the Code */

    CONSTRAINT PK_PAS PRIMARY KEY (ID)
);


/*
@Table           Patient
@Usage           Stores Person Record Information
@Category        Patient
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        LNAME,FNAME
*/

CREATE TABLE dbo.PAT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Patient Record */
    ACCT_NUMBER          VARCHAR(20),                            /* Account Number */
    BOOK_NUMBER          VARCHAR(20),                            /* Number The Patient Was Booked Under */
    HOSP_NUMBER          VARCHAR(20),                            /* Medical Record Number */
    SS_NUMBER            VARCHAR(11),                            /* Patient's Social Security Number */
    LNAME                VARCHAR(20) NOT NULL,                   /* Patient's Last Name */
    FNAME                VARCHAR(20) NOT NULL,                   /* Patient's First Name */
    MNAME                VARCHAR(10),                            /* Patient's Middle Name */
    DOB                  DATETIME,                               /* Date This Patient Was Born */
    GENDER               CHAR(1) NOT NULL,                       /* Gender Of Patient */
    RACE                 CHAR(1) NOT NULL,                       /* Patient's Race */
    LANG                 CHAR(1) NOT NULL,                       /* Patient's Primary Language */
    STATUS               CHAR(1) NOT NULL,                       /* Patient's Current Status */
    COMMENT1             VARCHAR(20),                            /* Miscellaneous Comment 1 */
    COMMENT2             VARCHAR(20),                            /* Miscellaneous Comment 2 */
    SPECIAL1             VARCHAR(20),                            /* Special Comments 1 */
    SPECIAL2             VARCHAR(20),                            /* Special Comments 2 */
    EMAIL                VARCHAR(80),                            /* Patient's E-Mail Address */
    LEGAL_NAME           VARCHAR(50),                            /* Patient Legal Name */
    CHG_ID               INTEGER,                                /* Charge Code */
    FAC_ID               INTEGER NOT NULL,                       /* Patient's Current Housing Facility */
    FAC_FROM             VARCHAR(100),                           /* Value used to extract Facility code */
    LOCATION             VARCHAR(40),                            /* Patient's Current Location */
    UNIT                 VARCHAR(10),                            /* Patient's Current Unit */
    WING                 VARCHAR(10),                            /* Patient's Current Wing */
    ROOM                 VARCHAR(10),                            /* Patient's Current Room */
    BED                  VARCHAR(10),                            /* Patient's Current Bed */
    AWAY                 CHAR(1) NOT NULL,                       /* This Patient is not in Their Cell */
    RESIDENCE            CHAR(1) NOT NULL,                       /* Patient's Primary Residence */
    REL_ID               INTEGER,                                /* Type of Release Event */
    RELEASE_DATE         DATETIME,                               /* The Day The Person Will Be Released */
    RELEASE_TIME         DATETIME,                               /* The Time The Person Will Be Released */
    ADMIT_DATE           DATETIME,                               /* Date */
    ADMIT_TIME           DATETIME,                               /* Time */
    ORIGIN               VARCHAR(10) NOT NULL,                   /* Task Type */
    SYS_DATE             DATETIME NOT NULL,                      /* Date */
    ADDRESS1             VARCHAR(30),                            /* Address Line 1 */
    ADDRESS2             VARCHAR(30),                            /* Address Line 2 */
    CITY                 VARCHAR(20),                            /* City */
    ST                   VARCHAR(2),                             /* State */
    ZIP                  VARCHAR(11),                            /* Zip Code */
    PHONE                VARCHAR(14),                            /* Primary Phone Number */
    HEIGHT_FT            INTEGER,                                /* Height In Feet */
    HEIGHT_IN            INTEGER,                                /* Height In Inches */
    WEIGHT               INTEGER,                                /* Patient's Weight (In Pounds) */
    WEIGH_DATE           DATETIME,                               /* Last Time This Patient Was Weighed */
    BODY_SURF            INTEGER,                                /* Body Surface (In Meters Squared) */
    CREATIN              DECIMAL(10,4),                          /* Creatinine Level */
    OMH_LEVEL            CHAR(1),                                /* OMH Level */
    GROUPING             VARCHAR(4),                             /* Grouping (For Reports) */
    DISPENSE_TYPE        CHAR(1) NOT NULL,                       /* Dispensing Machine Type */
    DEFAULT_KOP          CHAR(1) NOT NULL,                       /* Default KOP for a Patient */
    EARLIEST_RELEASE     DATETIME,                               /* Earliest Release Date */
    SAFETYCAP_FLAG       CHAR(1) NOT NULL,                       /* Does This Patient Require A Safety Cap? */
    CLASS2_FLAG          CHAR(1),                                /* Can This Patient Have Class 2 Drugs Dispensed? */
    CONTROLLED_ALLOWED   CHAR(1) NOT NULL,                       /* Can This Patient Have Controlled Drugs Dispensed? */
    DISPLAY_FLAG         CHAR(1) NOT NULL,                       /* Should This Patient Show Up When Filling Scripts? */
    COMPLIANT_FLAG       CHAR(1) NOT NULL,                       /* Is This Patient Compliant? */
    BILL_FLAG            CHAR(1) NOT NULL,                       /* Is This Patient Billable? */
    SLF_CRY_FLAG         CHAR(1) NOT NULL,                       /* Can This Patient Self Carry? */
    CHECK_MEDISPAN_FLAG  CHAR(1) NOT NULL,                       /* Do Medispan Checks On This Person? */
    STOCK_FLAG           CHAR(1) NOT NULL,                       /* This Patient Record Is Used To Dispense Stock Items */
    PRINTED_DATE         DATETIME,                               /* Date Last Printed on the MAR Report */
    PRINTED_TIME         DATETIME,                               /* Time Last Printed on the MAR Report */
    PRINTED_USR_ID       INTEGER,                                /* The User who Last Printed the MAR Report */

    CONSTRAINT PK_PAT PRIMARY KEY (ID)
);


/*
@Table           Patient Allergy Cross Reference
@Usage           Connects Patients with Allergies and Symptoms
@Category        Patient,Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,ALC_ID
*/

CREATE TABLE dbo.PAT_ALC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    ALC_ID               INTEGER NOT NULL,                       /* ALC Internal ID */
    ONSET                DATETIME,                               /* Date of Allergy Onset */
    RASH_FLAG            CHAR(1) NOT NULL,                       /* Rash */
    SHOCK_FLAG           CHAR(1) NOT NULL,                       /* Shock */
    ASTHMA_FLAG          CHAR(1) NOT NULL,                       /* Asthma */
    NAUSEA_FLAG          CHAR(1) NOT NULL,                       /* Nausea */
    ANEMIA_FLAG          CHAR(1) NOT NULL,                       /* Anemia */
    OTHER_FLAG           CHAR(1) NOT NULL,                       /* Other */
    OTHER_TEXT           VARCHAR(25),                            /* Other Text Describing Other Flag */

    CONSTRAINT PK_PAT_ALC PRIMARY KEY (ID)
);


/*
@Table           Patient Booking Number
@Usage           Connects Patient ID to Booking Number
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PAT_BOK
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    BOOK_NUMBER          VARCHAR(20) NOT NULL,                   /* Booking Number */
    BOOK_DATE            DATETIME,                               /* Date Record was entered */
    BOOK_TIME            DATETIME,                               /* Time Record was entered */

    CONSTRAINT PK_PAT_BOK PRIMARY KEY (ID)
);


/*
@Table           Patient Disease
@Usage           Connects Patients with Diseases(Medical Conditions)
@Category        Patient,Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,DIS_ID
*/

CREATE TABLE dbo.PAT_DIS
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    DIS_ID               INTEGER NOT NULL,                       /* Medical Condition Internal ID */
    FLAGGED              CHAR(1) NOT NULL,                       /* Sent to Medispan to tell if this Disease has been Flagged */
    STARTON              DATETIME,                               /* Date Medical Condition Starts */
    STOPON               DATETIME,                               /* Date Medical Condition Ends */

    CONSTRAINT PK_PAT_DIS PRIMARY KEY (ID)
);


/*
@Table           Patient Image
@Usage           Links Images to Patients
@Category        Patient
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PAT_IMG
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    IMG_QUE_ID           VARCHAR(50) NOT NULL,                   /* Link to Image */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    XLOC                 INTEGER NOT NULL,                       /* Horizontal Location */
    YLOC                 INTEGER NOT NULL,                       /* Vertical Location */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */

    CONSTRAINT PK_PAT_IMG PRIMARY KEY (ID)
);


/*
@Table           Patient Drug Allergy
@Usage           Connects Patients with Drugs they're Allergic to
@Category        Patient,Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,MED_ID
*/

CREATE TABLE dbo.PAT_MED
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    MED_ID               INTEGER NOT NULL,                       /* Med Master(Drug) Internal ID */
    ONSET                DATETIME,                               /* Date of Allergy Onset */
    RASH_FLAG            CHAR(1) NOT NULL,                       /* Rash */
    SHOCK_FLAG           CHAR(1) NOT NULL,                       /* Shock */
    ASTHMA_FLAG          CHAR(1) NOT NULL,                       /* Asthma */
    NAUSEA_FLAG          CHAR(1) NOT NULL,                       /* Nausea */
    ANEMIA_FLAG          CHAR(1) NOT NULL,                       /* Anemia */
    OTHER_FLAG           CHAR(1) NOT NULL,                       /* Other */
    OTHER_TEXT           VARCHAR(25),                            /* Other Text Describing Other Flag */

    CONSTRAINT PK_PAT_MED PRIMARY KEY (ID)
);


/*
@Table           Patient Non-Screened Health Info
@Usage           Ties Patient with Non-Screened Health Info
@Category        Patient,Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,NHI_ID
*/

CREATE TABLE dbo.PAT_NHI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    NHI_ID               INTEGER NOT NULL,                       /* Non-Screened Health Info ID */
    DCODE                VARCHAR(10),                            /* Code from another vendor's system */
    DTEXT                VARCHAR(60),                            /* Text from another vendor's system */

    CONSTRAINT PK_PAT_NHI PRIMARY KEY (ID)
);


/*
@Table           Patient Medical Conditions ICD (NM9)
@Usage           Ties Patient with ICD Medical Conditions
@Category        Patient,Medispan,ICD9
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,NM9_ID
*/

CREATE TABLE dbo.PAT_NM9
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    NM9_ID               VARCHAR(10) NOT NULL,                   /* NM9 Internal ID */
    FLAGGED              CHAR(1) NOT NULL,                       /* T/F has been Sent to Medispan to tell if this Disease has been flagged before */
    STARTON              DATETIME,                               /* Date Medical Condition Starts */
    STOPON               DATETIME,                               /* Date Medical Condition Ends */

    CONSTRAINT PK_PAT_NM9 PRIMARY KEY (ID)
);


/*
@Table           Patient Name Change
@Usage           Used to Maintain Patient Name Changes
@Category        Patient
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PAT_NMC
(
    ID                   INTEGER NOT NULL,                       /* Internal Identifier */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    LNAME                VARCHAR(20) NOT NULL,                   /* Patient's Last Name */
    FNAME                VARCHAR(20) NOT NULL,                   /* Patient's First Name */
    MNAME                VARCHAR(10),                            /* Patient's Middle Name */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */

    CONSTRAINT PK_PAT_NMC PRIMARY KEY (ID)
);


/*
@Table           Patient Court Date
@Usage           Court Date and Location
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PAT_CRT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    CRT_ID               INTEGER NOT NULL,                       /* Court Internal ID */
    COURT_DATE           DATETIME NOT NULL,                      /* Court Date */

    CONSTRAINT PK_PAT_CRT PRIMARY KEY (ID)
);


/*
@Table           Patient Note
@Usage           Stores Notes for Patients
@Category        Patient
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TITLE
*/

CREATE TABLE dbo.PAT_NOT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Note Title */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* (S)cript Screen Notes, Plain (T)ext */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_PAT_NOT PRIMARY KEY (ID)
);


/*
@Table           Patient PAR
@Usage           Ties a Patient with Prior Adverse Reactions
@Category        Patient,Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,PAR_ID
*/

CREATE TABLE dbo.PAT_PAR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    PAT_ID               INTEGER NOT NULL,                       /* PAT Internal ID */
    PAR_ID               INTEGER NOT NULL,                       /* PAR Internal ID */
    ONSET                DATETIME,                               /* Date of Onset of Allergy */
    RASH_FLAG            CHAR(1) NOT NULL,                       /* Allergic Reaction Includes Rash */
    SHOCK_FLAG           CHAR(1) NOT NULL,                       /* Allergic Reaction Includes Shock */
    ASTHMA_FLAG          CHAR(1) NOT NULL,                       /* Allergic Reaction Includes Asthma */
    NAUSEA_FLAG          CHAR(1) NOT NULL,                       /* Allergic Reaction Includes Nausea */
    ANEMIA_FLAG          CHAR(1) NOT NULL,                       /* Allergic Reaction Includes Anemia */
    OTHER_FLAG           CHAR(1) NOT NULL,                       /* Allergic Reaction Includes Other Symptom Defined in Text */
    OTHER_TEXT           VARCHAR(25),                            /* Text Describing Other Allergic Reaction */

    CONSTRAINT PK_PAT_PAR PRIMARY KEY (ID)
);


/*
@Table           Patient Procedure
@Usage           Stores Patient Procedures
@Category        Patient
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,PRO_ID
*/

CREATE TABLE dbo.PAT_PRO
(
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    PRO_ID               INTEGER NOT NULL,                       /* Procedure Internal ID */
    DRG_ID               INTEGER,                                /* Drug Internal ID */
    MED_PASS             INTEGER,                                /* Med Pass # */
    PROCEDURE_DATE       DATETIME,                               /* Procedure Date */
    PROCEDURE_TIME       DATETIME,                               /* Procedure Time */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Entry */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Who Entered Record */
    RESULTS              VARCHAR(60),                            /* Results of Procedure */
    DCOMMENT             VARCHAR(255),                           /* Free Text Comment */

    CONSTRAINT PK_PAT_PRO PRIMARY KEY (PAT_ID,PRO_ID,SYS_DATE,SYS_TIME)
);


/*
@Table           Patient 3P
@Usage           Stores Patient Third Parties
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PAT_ID,THP_ID
*/

CREATE TABLE dbo.PAT_THP
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal */
    THP_ID               VARCHAR(12) NOT NULL,                   /* Third Party Initial */
    ID_NUMBER            VARCHAR(20) NOT NULL,                   /* Cardholder ID [C2] */
    GRP_NUMBER           VARCHAR(15) NOT NULL,                   /* Group Number [C1] */
    RELATION             CHAR(1) NOT NULL,                       /* Relationship to Cardholder [C6] */
    PERSON_CODE          VARCHAR(3),                             /* Person Code [C3] */
    BILL_ORDER           INTEGER NOT NULL,                       /* Order for Billing Third Parties */
    ELIGIBLE             CHAR(1) NOT NULL,                       /* Eligibility Clarification [C9] */
    EFF_DATE             DATETIME,                               /* Date Insurance Takes Effect */
    EXP_DATE             DATETIME,                               /* Date Insurance Expires */
    DORMANT              CHAR(1) NOT NULL,                       /* Third Party Dormant */
    CARD_LNAME           VARCHAR(20),                            /* Last Name on Card [CC] */
    CARD_FNAME           VARCHAR(20),                            /* First Name on Card [CD] */
    PROCESSOR            VARCHAR(10),                            /* Processor Control Number [A4] */
    HOME_PLAN            VARCHAR(3),                             /* Home Plan [CE] */
    COVERAGE             CHAR(1) NOT NULL,                       /* Other Coverage [C8] */
    CUS_LOC              CHAR(1) NOT NULL,                       /* Customer Location [C7] */
    ID_NUMBERQ           CHAR(1) NOT NULL,                       /* Patient ID Qualifier [CX] */
    OTHER_NUMBER         VARCHAR(20),                            /* Other Patient Number [CY] */
    BRAND_FEE            DECIMAL(10,4),                          /* Brand Fee */
    BRAND_COPAY          DECIMAL(10,4),                          /* Brand Copay */
    GENERIC_FEE          DECIMAL(10,4),                          /* Generic Fee */
    GENERIC_COPAY        DECIMAL(10,4),                          /* Generic Copay */

    CONSTRAINT PK_PAT_THP PRIMARY KEY (ID)
);


/*
@Table           PC Terminal
@Usage           Cips Terminals
@Category        System
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PCT
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    TERM_NAME            VARCHAR(255) NOT NULL,                  /* Terminal Name */

    CONSTRAINT PK_PCT PRIMARY KEY (ID)
);


/*
@Table           Saved Form Printer Assignment
@Usage           
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PFR
(
    ID                   INTEGER NOT NULL,                       /* ID */
    FRM_ID               INTEGER NOT NULL,                       /* Saved Form */
    PCT_ID               INTEGER NOT NULL,                       /* Terminal */
    PRINTER_NAME         VARCHAR(255) NOT NULL,                  /* Name */
    TRAY                 VARCHAR(100) NOT NULL,                  /* Name */

    CONSTRAINT PK_PFR PRIMARY KEY (ID)
);


/*
@Table           Price Group
@Usage           Used to Group Facility Price Tables
@Category        Price
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PGR
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    DCODE                VARCHAR(10) NOT NULL,                   /* Short Code Identifier */
    DTEXT                VARCHAR(60),                            /* Detailed Description */
    PRC_ID               INTEGER NOT NULL,                       /* Price Table Internal ID */

    CONSTRAINT PK_PGR PRIMARY KEY (ID)
);


/*
@Table           Pharmacy
@Usage           Stores Pharmacy Record Information
@Category        Pharmacy
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DCODE
*/

CREATE TABLE dbo.PHR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Pharmacy Record */
    DNAME                VARCHAR(40) NOT NULL,                   /* Name Of Pharmacy */
    DCODE                VARCHAR(4) NOT NULL,                    /* Short Code For This Pharmacy Record */
    CONTACT              VARCHAR(40),                            /* Contact Name of Person at Pharmacy */
    ADDRESS1             VARCHAR(30),                            /* Pharmacy Address 1 */
    ADDRESS2             VARCHAR(30),                            /* Pharmacy Address 2 */
    CITY                 VARCHAR(20),                            /* City The Pharmacy Is Located In */
    ST                   VARCHAR(2),                             /* State The Pharmacy Is Located In */
    ZIP                  VARCHAR(10),                            /* Zip Code Of The Pharmacy */
    PHONE1               VARCHAR(14),                            /* Primary Phone Number */
    PHONE2               VARCHAR(14),                            /* Secondary Phone Number */
    EMAIL                VARCHAR(50),                            /* Pharmacy E-Mail Address */
    DEA                  VARCHAR(9),                             /* DEA Number of Pharmacy */
    NPI                  VARCHAR(10),                            /* NPI Number of Pharmacy */
    NABP                 VARCHAR(7),                             /* NABP Number of Pharmacy */
    GROUPING             VARCHAR(4),                             /* Special Grouping Field for Reporting */
    DCOMMENT             VARCHAR(255),                           /* Free Text Comments */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Dormant Pharmacies are no longer shown */
    RX_NUM_DEA0          CHAR(1),                                /* 1st Category For Rx# For Dea #'s */
    RX_NUM_DEA1          CHAR(1),                                /* 2nd Category For Rx# For Dea #'s */
    RX_NUM_DEA2          CHAR(1),                                /* 3rd Category For Rx# For Dea #'s */
    RX_NUM_DEA3          CHAR(1),                                /* 4th Category For Rx# For Dea #'s */
    RX_NUM_DEA4          CHAR(1),                                /* 5th Category For Rx# For Dea #'s */
    RX_NUM_DEA5          CHAR(1),                                /* 6th Category For Rx# For Dea #'s */
    RX_NUM_DEA6          CHAR(1),                                /* 7th Category For Rx# For Dea #'s */
    RX_NUM_STOCK_DEA0    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 0 */
    RX_NUM_STOCK_DEA1    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 1 */
    RX_NUM_STOCK_DEA2    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 2 */
    RX_NUM_STOCK_DEA3    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 3 */
    RX_NUM_STOCK_DEA4    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 4 */
    RX_NUM_STOCK_DEA5    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 5 */
    RX_NUM_STOCK_DEA6    CHAR(1),                                /* Rx# Category For Stock Scripts Dea # 6 */
    RX_NUM_VENDOR        CHAR(1),                                /* Rx# Category For Outside Vendor Scripts */
    MEDISPAN_PROXY       CHAR(1) NOT NULL,                       /* Generate Primary or Primary/Secondary Medical Conditions */
    AUTO_MEDISPAN        CHAR(1) NOT NULL,                       /* Medispan Results Will Automatically Pop Up During Filling If This Flag Is Set */
    USE_DI               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Scripts For Drug Interactions */
    USE_PR               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Scripts For Allergy Problems */
    USE_TD               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Scripts For Drug Therapy */
    USE_DC               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Scripts For Dosage Problems */
    USE_DZ               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Scripts For Drug Disease */
    USE_CA               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Scripts For Drug Compliance */
    USE_PE               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Allow Patient Education To Be Printed */
    USE_PM               CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Allow Patient Monograph To Be Printed */
    REF_AS_NEW_FLAG      CHAR(1) NOT NULL,                       /* Turning This Flag On Tells CIPS To Screen Each Refill as A New Prescription */
    DRG_IMG_FOLDER       VARCHAR(255),                           /* Use Images from this folder instead of the Images from Medispan */
    ACTIVE_SHEET         CHAR(1) NOT NULL,                       /* Tells CIPS Which Tab Sheet to Default To... */
    ROLL_REA_ID          VARCHAR(8),                             /* Reason Code To Use When DC'ing Because of Rollover */
    VOID_REA_ID          VARCHAR(8),                             /* Cips Will Use this Reason when Scripts are Automatically Dc'd */
    CREDIT_REA_ID        VARCHAR(8),                             /* Cips Will Use this Reason when Scripts are Automatically Credited */
    THP_CRD_REA_ID       VARCHAR(8),                             /* Cips Will Use this Reason when Scripts are Automatically Credited */
    DEBIT_REA_ID         VARCHAR(8),                             /* Cips Will Use this Reason when Scripts are Automatically Debited */
    THP_DEB_REA_ID       VARCHAR(8),                             /* Cips Will Use this Reason when Scripts are Automatically Debited */
    USE_SHORT_TERM       CHAR(1) NOT NULL,                       /* Short Term Scripts can be used by this Pharmacy */
    VERIFY_CTLS          CHAR(1) NOT NULL,                       /* Verify that Controlled Scripts Have a Hard Copy */
    QTY_THRESHHOLD       DECIMAL(10,4),                          /* CIPS Will not Allow A Refill If Quantity Due is Less than This Field */
    GPI_LENGTH           CHAR(1) NOT NULL,                       /* This Field Tells CIPS How Many Characters to Compare For Matches */
    GPI_REFILL_LENGTH    CHAR(1) NOT NULL,                       /* This Field Tells CIPS How Many Characters of the Drug GPI to Check on Refills */
    MAX_DAY_SUP          INTEGER,                                /* Maximum Days A Script Can Be Filled For At This Pharmacy */
    XOFFSET              INTEGER,                                /* X Offset */
    YOFFSET              INTEGER,                                /* Y Offset */
    ROLLOVER_GPI_DIGITS  CHAR(1) NOT NULL,                       /* The Number of GPI Digits a Drug Match on a Rollover */
    APPROVAL_DAYS        INTEGER,                                /* Number of Approval Days */
    DST_PHR_ID           INTEGER,                                /* Pharmacy Distribution comes out of */
    USE_RMT_QTY          CHAR(1) NOT NULL,                       /* CIPS Will Auto-Fill Stock Orders from Remote Operator */
    FIFO_FLAG            CHAR(1),                                /* Turning This Flag On Tells CIPS To Use First In, First Out Costing */
    TRACK_INV            CHAR(1) NOT NULL,                       /* Specifies inventory system */
    STOCK_FLAG           CHAR(1) NOT NULL,                       /* Allow Dispense of Drugs that Are Out of Stock */
    USE_LOTS_FLAG        CHAR(1) NOT NULL,                       /* Fill Out Drug Lot Information When Entering Prescriptions */
    PICK_FAC_FLAG        CHAR(1) NOT NULL,                       /* Allow Facility to be Selected and Locked In for Filling */
    KEEP_DOC_FLAG        CHAR(1) NOT NULL,                       /* Keep Doctor when Generally Clearing Filling Screen */
    USE_QTY_DUE          CHAR(1) NOT NULL,                       /* CIPS Will Use Quantity Due In Calculations */
    ENTER_RX_NUMBER      CHAR(1) NOT NULL,                       /* Manually Type In The Rx Number */
    PRO_BRAND_NAME_FLAG  CHAR(1) NOT NULL,                       /* Appends Brand Name To The End Of Drug Name In Patient Profile */
    PRO_DFL_FLAG         CHAR(1) NOT NULL,                       /* Merge In Voided Fills With Fills On Rx History */
    PRO_SIG_FLAG         CHAR(1) NOT NULL,                       /* Display Sig On Rx Profile */
    ABB_INDICATOR_FLAG   CHAR(1) NOT NULL,                       /* If Set, CIPS Will Only Try To Resolve Words Beginning With A Semicolon */
    AUTO_PAT_ALC_FLAG    CHAR(1) NOT NULL,                       /* Patient Allergies Will Automatically Pop Up During Filling If This Flag Is Set */
    AUTO_PAT_NOT_FLAG    CHAR(1) NOT NULL,                       /* Patient Notes Will Automatically Pop Up During Filling If This Flag Is Set */
    AUTO_PAT_NMC_FLAG    CHAR(1) NOT NULL,                       /* Patient Aliases Will Automatically Pop Up During Filling If This Flag Is Set */
    AUTO_RXF_NOT_FLAG    CHAR(1) NOT NULL,                       /* Rx Notes Will Automatically Pop Up During Filling If This Flag Is Set */
    AUTO_DRG_NOT_FLAG    CHAR(1) NOT NULL,                       /* Drug Notes Will Automatically Pop Up During Filling If This Flag Is Set */
    AUTO_DOC_NOT_FLAG    CHAR(1) NOT NULL,                       /* Doctor Notes Will Automatically Pop Up During Filling If This Flag Is Set */
    TAKEN_ON_EXP_FLAG    CHAR(1),                                /* CIPS Will Use This Flag to Figure the Stop Date */
    ALL_MESSAGES_FLAG    CHAR(1) NOT NULL,                       /* Shows All Messages During Filling */
    AUTO_DRG_ALT_FLAG    CHAR(1) NOT NULL,                       /* Alternate Matching Drugs Will Be Shown Automatically During Filling */
    USE_TECH_FLAG        CHAR(1) NOT NULL,                       /* Force Entry of Tech Initials During Filling */
    USE_SCRCHANGE_FLAG   CHAR(1) NOT NULL,                       /* Shows Script Change if true */
    ALLOW_EARLY_REFILL   CHAR(1) NOT NULL,                       /* Works in Conjunction With Facility % Window */
    ALLOW_RFL_CTL        CHAR(1) NOT NULL,                       /* Allow Refill of Controlled Drugs */
    ALLOW_MULTIPLE_STOCK CHAR(1) NOT NULL,                       /* Allow More Than One Stock Script To Be Filled At A Time */
    USE_DOC_FAC_FLAG     CHAR(1) NOT NULL,                       /* Show only Doctors attached to the Facility being Filled */
    WORKFLOW_FLAG        CHAR(1) NOT NULL,                       /* CIPS will send script information to the workflow system for this pharmacy */
    ONE_FILL_FLAG        CHAR(1) NOT NULL,                       /* CIPS will restrict all prescriptions to one fill per day */
    REFILL_DUE_FLAG      CHAR(1) NOT NULL,                       /* Will Refill Due Records Be Generated For This Pharmacy? */
    USE_DEL_SHEETS_FLAG  CHAR(1) NOT NULL,                       /* Will Delivery Sheets Be Generated For This Pharmacy? */
    FAC_LOG              CHAR(1) NOT NULL,                       /* Facility Log ( Discrepancies ) Will Print on The Delivery Sheet */
    USE_PRN_FLAG         CHAR(1) NOT NULL,                       /* Tab Stop on PRN? */
    PRN_REFILLS_FLAG     CHAR(1) NOT NULL,                       /* Include Fills Allowed in Tabbing Order. */
    QTY_ROUND_UP_FLAG    CHAR(1) NOT NULL,                       /* Round Up Quantity to the Nearest Whole Number */
    USE_ADMIN_DATE_FLAG  CHAR(1) NOT NULL,                       /* Use Administration Date instead of Fill Date to figure if too much Qty is being dispensed */
    USE_PROP_DAYS        CHAR(1) NOT NULL,                       /* Use Total Days to Calc Fill Days */
    SCRIPT_FORM_FOCUS    CHAR(1) NOT NULL,                       /* Set Focus Here When Filling From the Queue */
    FORCE_STOP_FLAG      CHAR(1) NOT NULL,                       /* Force the Stop Date / Days Supply to Be Entered Manually */
    USE_LABELS           CHAR(1) NOT NULL,                       /* Print Rx Labels Through Cips? */
    THP_LABEL_FLAG       CHAR(1) NOT NULL,                       /* Never Print Labels for Rejected Third Party Claims */
    USE_MAR_LABELS       CHAR(1) NOT NULL,                       /* Print MAR Labels Through Cips Remote? */
    USE_ORDER_FORM       CHAR(1) NOT NULL,                       /* Print Order Form Through Cips Remote? */
    AUTOMED_LABEL_FLAG   CHAR(1) NOT NULL,                       /* Print Labels for Machine Meds on New Scripts */
    BATCH_NEW_FLAG       CHAR(1) NOT NULL,                       /* Use Batch Labels for NEW Scripts */
    BATCH_REFILL_FLAG    CHAR(1) NOT NULL,                       /* Use Batch Labels for Refills */
    ORG_LABEL_FLAG       CHAR(1) NOT NULL,                       /* Use Original Script Label for the Refill Label */
    SEPARATE_PE_FLAG     CHAR(1) NOT NULL,                       /* When Labels Print, Print Patient Education Separately */
    USE_LABEL_NAME_FLAG  CHAR(1) NOT NULL,                       /* Use the Drug Label Name instead of the Drug Name for Display */
    VIS_COPIES           INTEGER,                                /* Number of times to Print an Encounter */
    RX_LABELS            INTEGER,                                /* Default Number of Pharmacy Labels to Print */
    RX_DEA_TWO_LABELS    INTEGER,                                /* Default Number of Labels for Schedule Two Drugs */
    CARD_FLAG            CHAR(1) NOT NULL,                       /* Should labels be refigured based on a quantity */
    PAT_NUMBER_OPT       CHAR(1) NOT NULL,                       /* Choose What Patient Number You Want to Show on Reports */
    DC_LABEL_FLAG        CHAR(1) NOT NULL,                       /* Should a MAR label be Printed After a Script is Discontinued */
    PROF_LAB_FLAG        CHAR(1) NOT NULL,                       /* Default Profiled Script To Zero Labels */
    USE_REVIEW           CHAR(1) NOT NULL,                       /* Force Entry Of Pharmacist Review Fields On a New Script */
    USE_REF_REVIEW       CHAR(1) NOT NULL,                       /* Force Entry Of Pharmacist Review Fields On a Refill Script */
    PHARM_REQ_REVIEW     CHAR(1) NOT NULL,                       /* For a Pharmacist Entered Fill, is Review Still Required? */
    STOCK_REVIEW         CHAR(1) NOT NULL,                       /* Stock Requires Review */
    USE_VERIFY           CHAR(1) NOT NULL,                       /* Tech Checks the Bottle for Correct Medication. */
    FORCE_VERIFY         CHAR(1) NOT NULL,                       /* Tech Must Use Scannner for Checks for Correct Medication. */
    VERIFY_MACH_FLAG     CHAR(1) NOT NULL,                       /* Use Rx Verification on Machine Scripts */
    PHARM_CORRECT        CHAR(1) NOT NULL,                       /* When can a Pharmacist (or Administrator) Correct a Script? */
    NONPHARM_CORRECT     CHAR(1) NOT NULL,                       /* When can a Non-Pharmacist Correct a Script? */
    AUTO_REVIEW_USR_ID   INTEGER,                                /* This user automatically is assigned when a fill skips the review queue */
    R_AUTO_PAT_ALC_FLAG  CHAR(1) NOT NULL,                       /* Patient Allergies Will Automatically Pop Up During Review If This Flag Is Set */
    R_AUTO_PAT_NOT_FLAG  CHAR(1) NOT NULL,                       /* Patient Notes Will Automatically Pop Up During Review If This Flag Is Set */
    R_AUTO_PAT_NMC_FLAG  CHAR(1) NOT NULL,                       /* Patient Aliases Will Automatically Pop Up During Review If This Flag Is Set */
    R_AUTO_RXF_NOT_FLAG  CHAR(1) NOT NULL,                       /* Rx Notes Will Automatically Pop Up During Review If This Flag Is Set */
    R_AUTO_DRG_NOT_FLAG  CHAR(1) NOT NULL,                       /* Patient Notes Will Automatically Pop Up During Review If This Flag Is Set */
    R_AUTO_DOC_NOT_FLAG  CHAR(1) NOT NULL,                       /* Doctor Notes Will Automatically Pop Up During Review If This Flag Is Set */
    USE_LOG_FLAG         CHAR(1) NOT NULL,                       /* Turning This Flag On Enables CIPS to Log Data Changes */
    DEFAULT_DAYS_SUPPLY  INTEGER,                                /* Default # Of Days To Dispense */
    RPT_SUMMARY_FLAG     CHAR(1) NOT NULL,                       /* Print Summary Page On Reports */
    DEFAULT_STATE        VARCHAR(2),                             /* Default State Location */
    CARDINAL_VEN_ID      INTEGER,                                /* Vendor to use in Cardinal Processes */
    AMS_VEN_ID           INTEGER,                                /* Vendor to use in Amerisource Processes */
    MCKESSON_VEN_ID      INTEGER,                                /* Vendor to use in McKesson Processes */
    SMITH_VEN_ID         INTEGER,                                /* Vendor to use in Smith Processes */
    WHOLESALE_VEN_ID     INTEGER,                                /* Vendor to use in Wholesale Processes */
    CON_ID               INTEGER,                                /* No Consent Given Record From the Consent Table */
    RTN_TYPE             CHAR(1) NOT NULL,                       /* This determines how returns are posted into the system */
    REF_PICK_FAC_FLAG    CHAR(1) NOT NULL,                       /* Force Facility to be Chosen for Batch Refill */
    IMAGE_DIRECTORY      VARCHAR(255),                           /* This Is Where Images Are Dropped For CIPS to Pick Up */
    IMAGE_FLAG           CHAR(1) NOT NULL,                       /* This turns on and off the script image server */
    IMAGE_WORKING        VARCHAR(255),                           /* This Is Where Images Are When Being Modified */
    IMAGE_CACHE          VARCHAR(255),                           /* This Is Where Images Are Found After Catalogued Into Database */
    FAC_PRE_SCAN_FLAG    CHAR(1) NOT NULL,                       /* Use Facility Pre-Scan in Warehouse */
    FAC_POST_SCAN_FLAG   CHAR(1) NOT NULL,                       /* Use Facility Post-Scan in Warehouse */
    CLARIFY_REA_ID       VARCHAR(8),                             /* Reason For When Script is DC'd Needing Clarification */
    CLARIFIED_REA_ID     VARCHAR(8),                             /* Reason For When Script is Clarified After Being DC'd */
    USE_DIAGNOSIS        CHAR(1) NOT NULL,                       /* Include Diagnosis in the tabbing order */
    FORCE_DIAGNOSIS      CHAR(1) NOT NULL,                       /* Force a diagnosis to be entered */
    RESTRICT_SIG         CHAR(1) NOT NULL,                       /* Can Only Choose Selected SIGS In Order Entry */
    USE_ORDER_TYPE       CHAR(1) NOT NULL,                       /* Allow User to Enter Order Type in Order Entry */
    HIDE_PRICE_FLAG      CHAR(1) NOT NULL,                       /* Hide All Pricing Information In Remote */
    REM_RXF_NOT_FLAG     CHAR(1) NOT NULL,                       /* Rx Notes Can Be Shown During Filling In Remote If This Flag Is Set */
    BUSINESS_DATE_FLAG   CHAR(1) NOT NULL,                       /* Use Business Date */
    BUSINESS_DATE_TIME   DATETIME,                               /* The Time that Scripts Start Getting Next Business Day's Date */
    BUSINESS_DATE_NEXT   DATETIME,                               /* When Filling Ahead, this is the Date it will Use */
    THP_QUE_ID           INTEGER,                                /* Claims with Errors will go into this Queue... */
    THP_CLAIM_SEND       CHAR(1) NOT NULL,                       /* When to Send Third Party Claim */
    THP_DSP_RSP          CHAR(1) NOT NULL,                       /* Checked - Display All Claim Responses, Unchecked - Display Only Non-Approved Claims */
    THP_SEND_TIME        DATETIME,                               /* The Time that Scripts Start Getting Sent to FilePro even if not Resolved */
    SERVICE_TYPE         CHAR(1) NOT NULL,                       /* Pharmacy Service Type */

    CONSTRAINT PK_PHR PRIMARY KEY (ID)
);


/*
@Table           Pharmacy Printer Forms
@Usage           Pharmacy Printer Forms
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PHR_PRF
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    PRF_EVENT            CHAR(1) NOT NULL,                       /* Event When This Form Will Be Printed */
    FR_NAME              VARCHAR(100),                           /* FR Filename */
    PRT_ID               INTEGER,                                /* Printer ID */

    CONSTRAINT PK_PHR_PRF PRIMARY KEY (ID)
);


/*
@Table           Pharmacist Intervention
@Usage           Stores Pharmacist Interventions
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PIN
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FAC_ID               INTEGER,                                /* Facility Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Internal ID */
    RXF_ID               INTEGER,                                /* Rx Internal ID */
    DOC_ID               INTEGER,                                /* Doctor Internal ID */
    TRAN_DATE            DATETIME,                               /* Transaction Date */
    TIME_SPENT           DATETIME,                               /* Time Spent */
    PHARM_USR_ID         INTEGER NOT NULL,                       /* Pharmacist */
    PHARMACIST           VARCHAR(3),                             /* Pharmacist's Initials */
    AMOUNT               DECIMAL(10,4),                          /* Dollar Amount */
    DTEXT                VARCHAR(255),                           /* Comment Text */
    ADRG_ID              INTEGER,                                /* Drug ID's for Involved Drugs */
    BDRG_ID              INTEGER,                                /* Drug ID's for Involved Drugs */
    CDRG_ID              INTEGER,                                /* Drug ID's for Involved Drugs */
    DDRG_ID              INTEGER,                                /* Drug ID's for Involved Drugs */
    EDRG_ID              INTEGER,                                /* Drug ID's for Involved Drugs */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_PIN PRIMARY KEY (ID)
);


/*
@Table           Patient Location Change
@Usage           Stores Patient Location Changes
@Category        Patient,Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PLC
(
    ID                   INTEGER NOT NULL,                       /* ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient */
    FAC_ID               INTEGER NOT NULL,                       /* Facility */
    OLD_FAC_ID           INTEGER,                                /* Old Facility */
    CHG_ID               INTEGER,                                /* Charge */
    PAT_STATUS           CHAR(1) NOT NULL,                       /* Patient's Status */
    PAT_LOCATION         VARCHAR(40),                            /* Patient's Location */
    OLD_PAT_LOCATION     VARCHAR(40),                            /* Old Patient's Location */
    PAT_UNIT             VARCHAR(10),                            /* Patient's Unit */
    OLD_PAT_UNIT         VARCHAR(10),                            /* Old Patient's Unit */
    PAT_WING             VARCHAR(10),                            /* Patient's Wing */
    OLD_PAT_WING         VARCHAR(10),                            /* Old Patient's Wing */
    PAT_ROOM             VARCHAR(10),                            /* Patient's Room */
    OLD_PAT_ROOM         VARCHAR(10),                            /* Old Patient's Room */
    PAT_BED              VARCHAR(10),                            /* Patient's Bed */
    OLD_PAT_BED          VARCHAR(10),                            /* Old Patient's Bed */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Patient Moved To this Location */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Patient Moved To this Location */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged in to Cips at Record Creation */
    END_DATE             DATETIME,                               /* Date Patient Moved Out of this Location */
    END_TIME             DATETIME,                               /* Time Patient Moved Out of this Location */

    CONSTRAINT PK_PLC PRIMARY KEY (ID)
);


/*
@Table           Pharmacist Intervention
@Usage           Stores Pharmacist Intervention
@Category        Pharmacist Intervention
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PNT
(
    ID                   INTEGER NOT NULL,                       /* Drug Internal Id */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    RXF_ID               INTEGER,                                /* Script Internal ID */
    DOC_ID               INTEGER NOT NULL,                       /* Doctor Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    DRG_TEXT             VARCHAR(255),                           /* Text Containing All Drugs */
    DRG_INT_FLAG         CHAR(1) NOT NULL,                       /* Drug-Drug Interaction */
    NUT_INT_FLAG         CHAR(1) NOT NULL,                       /* Drug-Nutrient Interaction */
    DIS_INT_FLAG         CHAR(1) NOT NULL,                       /* Drug-Disease Interaction */
    THERAP_DUP_FLAG      CHAR(1) NOT NULL,                       /* Therapeutic Duplication */
    COM_AVAIL_FLAG       CHAR(1) NOT NULL,                       /* Available in Commissary */
    DOSING_REG_FLAG      CHAR(1) NOT NULL,                       /* Dosing Regimen */
    PRECAUTION_FLAG      CHAR(1) NOT NULL,                       /* Contraindication/Precaution */
    DRG_MIS_FLAG         CHAR(1) NOT NULL,                       /* Apparent Drug Misuse or Excessive Dose */
    PRI_AUTH_FLAG        CHAR(1) NOT NULL,                       /* Prior Authorization Necessary */
    OTHER_TEXT           VARCHAR(30),                            /* Other Text */
    EXPLANATION          VARCHAR(255),                           /* Explanation */
    RECOMENDATION        VARCHAR(255),                           /* Recomendation */
    SYS_USR_ID           INTEGER,                                /* User who entered Record */
    SYS_DATE             DATETIME,                               /* Date Record was entered */
    SYS_TIME             DATETIME,                               /* Time Record was entered */

    CONSTRAINT PK_PNT PRIMARY KEY (ID)
);


/*
@Table           Purchase Order Category
@Usage           Stores Purchase Order Categories
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DCODE
*/

CREATE TABLE dbo.POC
(
    DCODE                VARCHAR(4) NOT NULL,                    /* Descriptive Code of Purchase Order */
    DTEXT                VARCHAR(30),                            /* Free Text Description of Purchase Order Category */

    CONSTRAINT PK_POC PRIMARY KEY (DCODE)
);


/*
@Table           Pharmacy Purchase Order
@Usage           Stores Pharmacy Purchase Orders
@Category        Inventory,Pharmacy
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PHR_ID,REF_NUMBER
*/

CREATE TABLE dbo.PPO
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    REF_NUMBER           VARCHAR(30) NOT NULL,                   /* Reference Number */
    CONTRACT_NUM         VARCHAR(30),                            /* Contract Number */
    DTEXT                VARCHAR(60),                            /* Descriptive Text */
    ORDER_TYPE           CHAR(1) NOT NULL,                       /* Order Type */
    SALES_CODE           CHAR(1) NOT NULL,                       /* Sales Code */
    SPECIAL_CODE         CHAR(1) NOT NULL,                       /* Does Special Date Apply? */
    SPECIAL_DATE         DATETIME,                               /* Special Delivery Date */
    VEN_ID               INTEGER NOT NULL,                       /* Vendor Internal ID */
    STATUS               CHAR(1) NOT NULL,                       /* Status of Order-(O)pen,(C)losed,(I)n Use */
    ORDER_ON_DATE        DATETIME,                               /* Date PO was Ordered */
    DELIVER_ON_DATE      DATETIME,                               /* Date to be Delivered */
    COMPLETE_DATE        DATETIME,                               /* Complete Date */
    INVENTORY_ADJ_DATE   DATETIME,                               /* Inventory Adjust Date */
    INV_NUM              VARCHAR(10),                            /* Inventory Number */
    SYS_USR_ID           INTEGER,                                /* User who Added the Purchase Order */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Purchase Order Addition */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Purchase Order Addition */
    POST_USR_ID          INTEGER,                                /* User who Posted the Purchase Order */
    POST_DATE            DATETIME,                               /* Date the Purchase Order was Posted */
    POST_TIME            DATETIME,                               /* Time the Purchase Order was Posted */
    CONFIRM_NUM          INTEGER,                                /* Confirmation Number */

    CONSTRAINT PK_PPO PRIMARY KEY (ID)
);


/*
@Table           Pharmacy Purchase Order Item
@Usage           Stores Pharmacy Purchase Orders Items
@Category        Inventory,Pharmacy
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PPO_ID,SEQ_NUM
*/

CREATE TABLE dbo.PPO_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PPO_ID               INTEGER NOT NULL,                       /* PPO Internal ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Item Sequence Number */
    DRG_ID               INTEGER,                                /* Drug Internal ID */
    CAT_ID               INTEGER,                                /* Catalog Internal ID */
    ITEM_NO              VARCHAR(15) NOT NULL,                   /* Item Number */
    DTEXT                VARCHAR(60),                            /* Descriptive Text */
    ACQ_COST             DECIMAL(10,4) NOT NULL,                 /* Cost of Quantity */
    ORDER_QTY            DECIMAL(10,4) NOT NULL,                 /* Quantity to Order */
    PUR_QTY              DECIMAL(10,4),                          /* Drug Purchase Quantity, Purchased in Multiples */
    SELL_PRICE           DECIMAL(10,4),                          /* Selling Price */
    MULTIPLIER           DECIMAL(10,4),                          /* Multiplier for Price */
    PRODUCT_IDENTIFIER   CHAR(1) NOT NULL,                       /* (N)one,(L)abel,(P)riceUpdate,Price(S)ticker,(R)Catalog */
    PRICE_CODE           CHAR(1) NOT NULL,                       /* Price Code */
    MULTIPLIER_CODE      CHAR(1) NOT NULL,                       /* Multiplier Code */
    PROMISED_QTY         DECIMAL(10,4) NOT NULL,                 /* Promised Quantity */
    RECEIVED_QTY         DECIMAL(10,4) NOT NULL,                 /* Received Quantity */
    POSTED_QTY           DECIMAL(10,4) NOT NULL,                 /* Posted Quantity */
    POSTED_FLAG          CHAR(1) NOT NULL,                       /* Posted Flag */
    UNIT_CODE            CHAR(1) NOT NULL,                       /* Unit Code */
    UPDATE_DRG_FLAG      CHAR(1) NOT NULL,                       /* Update Drug Record? */
    SYS_USR_ID           INTEGER,                                /* User who Entered Record */
    SYS_DATE             DATETIME,                               /* Date of Record Entry */
    SYS_TIME             DATETIME,                               /* Time of Record Entry */

    CONSTRAINT PK_PPO_ITM PRIMARY KEY (ID)
);


/*
@Table           Price
@Usage           Stores Pricing Information
@Category        Pricing
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.PRC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DCODE                VARCHAR(8) NOT NULL,                    /* Lookup Code for Price Table */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Description of Price Table */
    ROUND_TO             DECIMAL(10,4),                          /* Amount to Round to */
    MIN_PRICE            DECIMAL(10,4),                          /* Minimum Price Allowed with Price Table */
    MIN_UNIT_PRICE       DECIMAL(10,4),                          /* Minimum Unit Price Allowed with Price Table */
    BREAKTYPE            CHAR(1) NOT NULL,                       /* (D)ollar,(Q)uantity, (U)nit Cost */
    ADD_FEE_FLAG         CHAR(1) NOT NULL,                       /* Add Fee Before Multiplying by Factor */
    STATIC_FLAG          CHAR(1) NOT NULL,                       /* If set, cents will be equal to 'Round To', otherwise price will round to nearest 'Round To' ( .10 = round to nearest 10 cents ) */
    ACQ_COST_FLAG        CHAR(1) NOT NULL,                       /* Allow Cost to be less than Acquisition Cost */
    COST_BASIS           CHAR(1) NOT NULL,                       /* Cost Basis to use for Price Table */
    CARD_FEE             DECIMAL(10,4),                          /* Fee Per 30 Pills on Card Fills */
    MARKUP_FACTOR        DECIMAL(10,4),                          /* CIPS Will Multiply Cost * Markup Factor if Figured Price < Cost */
    MARKUP_FEE           DECIMAL(10,4),                          /* Fee Can Be Added On If Price < Acq Cost */

    CONSTRAINT PK_PRC PRIMARY KEY (ID)
);


/*
@Table           Price Item
@Usage           Stores Price Table Item Info
@Category        Pricing
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PRC_ID,UPTO
*/

CREATE TABLE dbo.PRC_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PRC_ID               INTEGER NOT NULL,                       /* Link To Price Table */
    UPTO                 DECIMAL(10,4),                          /* A Cost Below This Amount Will Use Corresponding Factor and Fee */
    DFACTOR              DECIMAL(10,4),                          /* CIPS Will Multiply Cost * Factor */
    MARKUP_FACTOR        DECIMAL(10,4),                          /* CIPS Will Multiply Cost * Markup Factor if Figured Price < Cost */
    FEE_TYPE             CHAR(1) NOT NULL,                       /* Fee Type */
    FEE                  DECIMAL(10,4),                          /* Fee Can Be Added On */
    MARKUP_FEE           DECIMAL(10,4),                          /* Fee Can Be Added On If Price < Acq Cost */

    CONSTRAINT PK_PRC_ITM PRIMARY KEY (ID)
);


/*
@Table           Priority
@Usage           Used To Assign Priorities To Prescriptions
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.PRI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PRIORITY             INTEGER NOT NULL,                       /* Level of Priority ( 1 Being the Highest ) */
    DCODE                VARCHAR(8) NOT NULL,                    /* Short Description of Record */
    DTEXT                VARCHAR(255) NOT NULL,                  /* Long Description of Record */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Flag: Priority is Dormant */

    CONSTRAINT PK_PRI PRIMARY KEY (ID)
);


/*
@Table           Procedures
@Usage           Stores Procedures
@Category        Patient
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PRO
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    FREQUENCY            CHAR(1),                                /* Interval to be Administered,per: d(A)y,(D)rug,(P)ass */
    DTEXT                VARCHAR(60),                            /* Reason Description */

    CONSTRAINT PK_PRO PRIMARY KEY (ID)
);


/*
@Table           Terminal Printer Assignment
@Usage           Terminal Printer Routes
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PRR
(
    ID                   INTEGER NOT NULL,                       /* ID */
    PRT_ID               INTEGER NOT NULL,                       /* Printer */
    PCT_ID               INTEGER NOT NULL,                       /* Terminal */
    PRINTER_NAME         VARCHAR(255) NOT NULL,                  /* Name */
    TRAY                 VARCHAR(100) NOT NULL,                  /* Name */
    LEFT_OFFSET          DECIMAL(10,4),                          /* (-1.0) = 1 inch Left | (1.0) = 1 inch Right */
    TOP_OFFSET           DECIMAL(10,4),                          /* (-1.0) = 1 inch Up | (1.0) = 1 inch Down */

    CONSTRAINT PK_PRR PRIMARY KEY (ID)
);


/*
@Table           Printer Type
@Usage           Printer Information
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.PRT
(
    ID                   INTEGER NOT NULL,                       /* ID */
    DNAME                VARCHAR(30) NOT NULL,                   /* Name */
    DESCRIPTION          VARCHAR(50) NOT NULL,                   /* Description */
    INTERCON_FLAG        CHAR(1) NOT NULL,                       /*  */
    LEFT_OFFSET          DECIMAL(10,4),                          /* (-1.0) = 1 inch Left | (1.0) = 1 inch Right */
    TOP_OFFSET           DECIMAL(10,4),                          /* (-1.0) = 1 inch Up | (1.0) = 1 inch Down */
    REMOTE_FLAG          CHAR(1) NOT NULL,                       /* Use This Printer Config in Remote */

    CONSTRAINT PK_PRT PRIMARY KEY (ID)
);


/*
@Table           Purchase Category
@Usage           Stores Procedures
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CATEGORY_CODE
*/

CREATE TABLE dbo.PUC
(
    CATEGORY_CODE        VARCHAR(11) NOT NULL,                   /* Purchase Category being worked with */
    MIN_DS_ONHAND        INTEGER,                                /* Minimum Day supply Onhand, used if Requisitioning by Dialy Usage */
    MAX_DS_ONHAND        INTEGER,                                /* Maximum Day supply Onhand, used if Requisitioning by Dialy Usage */
    DTEXT                VARCHAR(30),                            /* Free Text Description */

    CONSTRAINT PK_PUC PRIMARY KEY (CATEGORY_CODE)
);


/*
@Table           Pharmacy Warehouse Resriction
@Usage           Stores Restrictions for Pharmacies Ordering Drugs
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PHR_ID,GPI
*/

CREATE TABLE dbo.PWR
(
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    GPI                  VARCHAR(16) NOT NULL,                   /* GPI */

    CONSTRAINT PK_PWR PRIMARY KEY (PHR_ID,GPI)
);


/*
@Table           Queue
@Usage           Prescription Queue
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.QUE
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DCODE                VARCHAR(8) NOT NULL,                    /* Short Code */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Queue Description */
    USE_CUT_TIME_FLAG    CHAR(1) NOT NULL,                       /* Use Cut Time */
    CUT_TIME             DATETIME,                               /* The Time that Scripts Stop Being Processed for Today */

    CONSTRAINT PK_QUE PRIMARY KEY (ID)
);


/*
@Table           Reason
@Usage           Stores Reasons for Things
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.REA
(
    ID                   VARCHAR(8) NOT NULL,                    /* Short Code */
    DTYPE                CHAR(1) NOT NULL,                       /* Type */
    DTEXT                VARCHAR(60) NOT NULL,                   /* Reason Description */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Flag: Reason is Dormant */

    CONSTRAINT PK_REA PRIMARY KEY (ID)
);


/*
@Table           Database Registry
@Usage           Stores Information for Database Registry
@Category        System
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.REG
(
    ID                   VARCHAR(64) NOT NULL,                   /* Internal Id */
    DDATA                VARCHAR(255) NOT NULL,                  /* Data */

    CONSTRAINT PK_REG PRIMARY KEY (ID)
);


/*
@Table           Release Code
@Usage           Release Code
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.REL
(
    ID                   INTEGER NOT NULL,                       /* ID */
    DCODE                VARCHAR(10) NOT NULL,                   /* Short Code */
    DTEXT                VARCHAR(50) NOT NULL,                   /* Description */

    CONSTRAINT PK_REL PRIMARY KEY (ID)
);


/*
@Table           Requisition Base
@Usage           Stores Requisition Information
@Category        Pharmacy,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.REQ
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PICK_DATE            DATETIME,                               /* Date it was pulled off the Shelf */
    PICK_TIME            DATETIME,                               /* Time it was pulled off the Shelf */
    PICK_USR_ID          INTEGER,                                /* User who pulled it off the Shelf */
    SHIP_DATE            DATETIME,                               /* Date it was Shipped */
    SHIP_TIME            DATETIME,                               /* Time it was Shipped */
    SHIP_USR_ID          INTEGER,                                /* User who Shipped it */
    RECV_DATE            DATETIME,                               /* Date it was Received */
    RECV_TIME            DATETIME,                               /* Time it was Received */
    RECV_USR_ID          INTEGER,                                /* User who Received it */
    PICK_FACTOR          DECIMAL(10,4),                          /* Overriding Multiplier of the Max Amount that can be Requisitioned */
    REQUISITION_NUM      VARCHAR(10),                            /* Data */
    PHR_ID               INTEGER,                                /* Pharmacy that Initiated the Requisition */
    FAC_ID               INTEGER,                                /* Facility to Ship the Requisition Straight to */
    NONFORMULARY_CODE    INTEGER,                                /* if Nonformulary, Link to the Approval Record */
    DNOTE                VARCHAR(255),                           /* Note */
    STATUS               CHAR(1),                                /* Status of the Requisition */

    CONSTRAINT PK_REQ PRIMARY KEY (ID)
);


/*
@Table           Requisition Item
@Usage           Stores Requisition Item Information
@Category        Pharmacy,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        REQ_ID,SEQ_NUM
*/

CREATE TABLE dbo.REQ_ITM
(
    REQ_ID               INTEGER NOT NULL,                       /* Requisition ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Line Number for a Certain Requisition */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    QTY_ORDERED          INTEGER NOT NULL,                       /* Quantity Ordered */
    QTY_SHIPPED          INTEGER,                                /* Quantity Shipped */
    QTY_RECEIVED         INTEGER,                                /* Quantity Receieved */
    QTY_COST             DECIMAL(10,4),                          /* Cost for the Quantity that was Ordered */
    QTY_ONHAND_BFR_ORD   DECIMAL(10,4),                          /* Quantity Onhand at Start of Order */
    FRIDGE_FLAG          CHAR(1) NOT NULL,                       /* T/F This Drug should be Refrigerated */
    DCOMMENT             VARCHAR(80),                            /* Free Text Comment */

    CONSTRAINT PK_REQ_ITM PRIMARY KEY (REQ_ID,SEQ_NUM)
);


/*
@Table           Requisition/Warehouse Purchase Order
@Usage           Stores Warehouse Requisitions
@Category        Pharmacy,Warehouse,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        REQ_ID,REQ_ITM_SEQ_NUM,WPO_PO_NUM,WPO_ITM_SEQ_NUM
*/

CREATE TABLE dbo.REQ_WPO
(
    REQ_ID               INTEGER NOT NULL,                       /* Requisition ID */
    REQ_ITM_SEQ_NUM      INTEGER NOT NULL,                       /* Requisition Item Line # */
    WPO_PO_NUM           INTEGER NOT NULL,                       /* Warehouse Purchase Order # */
    WPO_ITM_SEQ_NUM      INTEGER NOT NULL,                       /* Warehouse Purchase Order Item Line # */
    QTY_ON_PO            INTEGER NOT NULL,                       /* Quantity on Purchase Order */

    CONSTRAINT PK_REQ_WPO PRIMARY KEY (REQ_ID,REQ_ITM_SEQ_NUM,WPO_PO_NUM,WPO_ITM_SEQ_NUM)
);


/*
@Table           Refill Due
@Usage           Stores Scripts and the Dates they are Due to be Refilled
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID
*/

CREATE TABLE dbo.RFD
(
    RXF_ID               INTEGER NOT NULL,                       /* RXF Internal ID */
    DATE_DUE             DATETIME NOT NULL,                      /* Date Script is to be Refilled */
    TIME_DUE             DATETIME NOT NULL,                      /* Time Script is to be Refilled */
    TYPE_CODE            CHAR(1) NOT NULL,                       /* Record Type ( Auto Refill, Batch Refill, etc... ) */
    PAS_ID               VARCHAR(10),                            /* Pass */

    CONSTRAINT PK_RFD PRIMARY KEY (RXF_ID)
);


/*
@Table           Region
@Usage           Defines Regions (for Facilities to be put in)
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.RGN
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Region */
    DCODE                VARCHAR(10) NOT NULL,                   /* Short Code for Region */
    DNAME                VARCHAR(20) NOT NULL,                   /* Name of Region */
    DCOMMENT             VARCHAR(255),                           /* Description of Region */
    PRIMARY_FLAG         CHAR(1) NOT NULL,                       /* This is a Primary Region */
    FORMULARY_FLAG       CHAR(1) NOT NULL,                       /* The formulary is consistent at all facilities in this region. */
    DELIVERY_FLAG        CHAR(1) NOT NULL,                       /* All Fills for facilities in this region show up in Delivery Sheet Scanning. */

    CONSTRAINT PK_RGN PRIMARY KEY (ID)
);


/*
@Table           Region Facility
@Usage           Groups Facilities in Regions
@Category        Facility
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FAC_ID,RGN_ID
*/

CREATE TABLE dbo.RGN_FAC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    RGN_ID               INTEGER NOT NULL,                       /* Internal ID of this Region */
    FAC_ID               INTEGER NOT NULL,                       /* Internal ID of this Facility */

    CONSTRAINT PK_RGN_FAC PRIMARY KEY (ID)
);


/*
@Table           Rejection Codes
@Usage           Stores Description of Rejection Codes
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RJT
(
    ID                   VARCHAR(4) NOT NULL,                    /* Rejection Code */
    DTEXT                VARCHAR(60) NOT NULL,                   /* Rejection Description */
    SEC_CARRIER_FLAG     CHAR(1) NOT NULL,                       /* Secondary Carrier */
    FIELDS_PIE           VARCHAR(16),                            /* Fields Possibly in Error */

    CONSTRAINT PK_RJT PRIMARY KEY (ID)
);


/*
@Table           Remote Fill
@Usage           Stores Remote Fills
@Category        Script,Pharmacy
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        FIL_ID
*/

CREATE TABLE dbo.RMT
(
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */

    CONSTRAINT PK_RMT PRIMARY KEY (FIL_ID)
);


/*
@Table           Report Grouping
@Usage           Used to group reports into sections
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        TITLE
*/

CREATE TABLE dbo.RPG
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    TITLE                VARCHAR(60) NOT NULL,                   /* Title of this group */
    USERTYPE             CHAR(1) NOT NULL,                       /* Which User Type will this report show up for? */
    RPG_ID               INTEGER,                                /* Group within a group */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User who entered Record */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record was entered */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record was entered */

    CONSTRAINT PK_RPG PRIMARY KEY (ID)
);


/*
@Table           Report Grouping Item
@Usage           Used to group reports into sections
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RPG_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    TITLE                VARCHAR(60),                            /* Title of this group */
    RPG_ID               INTEGER,                                /* Group within a group */
    RPT_ID               INTEGER,                                /* Report ID */
    CLASSNAME            VARCHAR(60),                            /* Class Name */
    FRM_ID               INTEGER,                                /* Form ID */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User who entered Record */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record was entered */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record was entered */

    CONSTRAINT PK_RPG_ITM PRIMARY KEY (ID)
);


/*
@Table           Report
@Usage           Stores info for building Custom Reports
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME,DTEXT
*/

CREATE TABLE dbo.RPT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    DNAME                VARCHAR(60) NOT NULL,                   /* Name for this Custom Report */
    DTEXT                VARCHAR(255),                           /* Description for this Custom Report */
    ORIENTATION          CHAR(1) NOT NULL,                       /* Portrait, Landscape, or Cips Decides */
    SHOW_DETAIL_BOX_FLAG CHAR(1) NOT NULL,                       /* Show CheckBox to Show Detail or only Summary */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged In at Record Creation */

    CONSTRAINT PK_RPT PRIMARY KEY (ID)
);


/*
@Table           Report Display
@Usage           Stores Display info for building Custom Reports
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RPT_ID,FIELD_PATH
*/

CREATE TABLE dbo.RPT_DSP
(
    RPT_ID               INTEGER NOT NULL,                       /* RPT Internal ID */
    FIELD_PATH           VARCHAR(255) NOT NULL,                  /* Path for Field to be Displayed */
    SEQ_NUM              INTEGER NOT NULL,                       /* Fields Displayed in Order of Sequence # */
    HEADING              VARCHAR(50) NOT NULL,                   /* What should print for this column's header? */
    SUMMARY              CHAR(1) NOT NULL,                       /* Should this Field be (S)ummed, (C)ounted Uniquely, or (N)othing? */
    DISPLAY_FLAG         CHAR(1) NOT NULL,                       /* Will this Field Display as a Normal Data Field? */
    GRP_ID               INTEGER NOT NULL,                       /* Group Number of Display Field */
    MAX_DISPLAY          INTEGER NOT NULL,                       /* Maximum Length Field Should Take on Report */

    CONSTRAINT PK_RPT_DSP PRIMARY KEY (RPT_ID,SEQ_NUM)
);


/*
@Table           Report Filter
@Usage           Stores Filter( Parameter ) info for building Custom Reports
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RPT_ID,FIELD_PATH
*/

CREATE TABLE dbo.RPT_FLT
(
    RPT_ID               INTEGER NOT NULL,                       /* RPT Internal ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number */
    FIELD_PATH           VARCHAR(255) NOT NULL,                  /* Path for Field to be Filtered on */
    FIELD_TYPE           CHAR(1) NOT NULL,                       /* Type of Parameter to show on Report */
    FIELD_VALUE_FLAG     CHAR(1) NOT NULL,                       /* If True, Field will be Hard Coded, and will NOT show up on Report */
    FIELD_VALUE          VARCHAR(255),                           /* Where Statement if Hard Coded */
    LIKE_FLAG            CHAR(1) NOT NULL,                       /* Is this parameter filtering by Like instead of equals? */
    REQUIRED_FLAG        CHAR(1) NOT NULL,                       /* Is this Filter Required to be Set? */

    CONSTRAINT PK_RPT_FLT PRIMARY KEY (RPT_ID,FIELD_PATH)
);


/*
@Table           Report Schedule
@Usage           Schedule for Running Reports
@Category        Report Schedule
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RPT_SCH
(
    ID                   INTEGER NOT NULL,                       /* Short Report Schedule Identifier */
    FRM_ID               INTEGER NOT NULL,                       /* Saved Report */
    RPT_FILE             VARCHAR(255),                           /* Report File Name */
    RPT_ID               INTEGER,                                /* Custom Report */
    LAST_SYS_DATE        DATETIME,                               /* Date the Report was Last Run */
    LAST_SYS_TIME        DATETIME,                               /* Time the Report was Last Run */
    PRT_ID               INTEGER,                                /* Printer ID */
    ACTIVE_FLAG          CHAR(1) NOT NULL,                       /* Is this Report Active? */
    RTYPE                CHAR(1) NOT NULL,                       /* Type of Report */
    OUTPUT_TYPE          CHAR(1) NOT NULL,                       /* Report Output Type */
    DTYPE                CHAR(1) NOT NULL,                       /* Schedule Type */
    RUN_TIME             DATETIME,                               /* When Should this Report Run? */
    DAY_OF_MONTH         INTEGER,                                /* Day of the Month the Report Should Run */
    DAY_OF_WEEK          CHAR(1) NOT NULL,                       /* Day of the Week the Report Should Run */
    TSK_DTYPE            VARCHAR(10) NOT NULL,                   /* Task Type */
    HOURLY_OFFSET        INTEGER,                                /* How Many Minutes After The Hour The Report Will Run */

    CONSTRAINT PK_RPT_SCH PRIMARY KEY (ID)
);


/*
@Table           Report Sort
@Usage           Stores Sort by info for building Custom Reports
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RPT_ID,FIELD_PATH
*/

CREATE TABLE dbo.RPT_SRT
(
    RPT_ID               INTEGER NOT NULL,                       /* RPT Internal ID */
    DNAME                VARCHAR(30) NOT NULL,                   /* Name to show up for this Sort */
    SORT_KEY             INTEGER NOT NULL,                       /* ID to be Used for Tracking Preloaded Sorts */
    FIELD_PATH           VARCHAR(255) NOT NULL,                  /* Path for Field to be Sorted by */
    SEQ_NUM              INTEGER NOT NULL,                       /* Fields Sorted in Order of Sequence # */
    GROUP_BY             CHAR(1) NOT NULL,                       /* (G)roup By, (N)o Group, (P)age Break */
    DISPLAY_HEADER_FLAG  CHAR(1) NOT NULL,                       /* Should this HeaderBand Show a Display? */

    CONSTRAINT PK_RPT_SRT PRIMARY KEY (RPT_ID,DNAME,SEQ_NUM)
);


/*
@Table           Report Table
@Usage           Stores Joining Tables for building Custom Reports
@Category        Report
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RPT_ID,TABLE_PATH
*/

CREATE TABLE dbo.RPT_TBL
(
    RPT_ID               INTEGER NOT NULL,                       /* RPT Internal ID */
    TABLE_PATH           VARCHAR(255) NOT NULL,                  /* Path for Joining Tables */

    CONSTRAINT PK_RPT_TBL PRIMARY KEY (RPT_ID,TABLE_PATH)
);


/*
@Table           Requisition Abbreviation
@Usage           Stores Requisition Abbreviations
@Category        Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RQA
(
    ID                   VARCHAR(10) NOT NULL,                   /* Internal ID */
    DTEXT                VARCHAR(80),                            /* Descriptive Text */

    CONSTRAINT PK_RQA PRIMARY KEY (ID)
);


/*
@Table           Refusal Reason
@Usage           Stores Refusal Reasons
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RRE
(
    ID                   VARCHAR(4) NOT NULL,                    /* Internal ID */
    DTEXT                VARCHAR(30),                            /* Descriptive Text */
    REFUSED_FLAG         CHAR(1) NOT NULL,                       /* T/F is a Refusal */

    CONSTRAINT PK_RRE PRIMARY KEY (ID)
);


/*
@Table           3P Claim Rsp
@Usage           Stores Third Party Claim Response Record
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RSP
(
    ID                   INTEGER NOT NULL,                       /* Internal ID Of Claim Response Record */
    FIL_THP_ID           INTEGER NOT NULL,                       /* Third Party Billing Internal */
    STATUS               CHAR(1),                                /* Status of Response */
    RSP_DATE             DATETIME,                               /* Date Claim Submitted */
    RSP_TIME             DATETIME,                               /* Time Claim Submitted */
    CLAIM                VARCHAR(1000),                          /* Claim Buffer */
    RESPONSE             VARCHAR(1000),                          /* Response Buffer */
    PORT                 VARCHAR(12),                            /* Communication Port Used */
    PRINTED              CHAR(1) NOT NULL,                       /* Response Printed? */

    CONSTRAINT PK_RSP PRIMARY KEY (ID)
);


/*
@Table           Return Meds
@Usage           Stores Med Returns
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RTN
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    RXF_ID               INTEGER NOT NULL,                       /* Rx Internal ID */
    REA_ID               VARCHAR(8) NOT NULL,                    /* Reason Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    USR_ID               INTEGER NOT NULL,                       /* User Internal ID */
    RTN_DATE             DATETIME,                               /* Date of Return */
    RTN_TIME             DATETIME,                               /* Time of Return */
    INV_UPDATED_FLAG     CHAR(1) NOT NULL,                       /* T/F Inventory has been Updated */
    AT_ZERO_COST_FLAG    CHAR(1) NOT NULL,                       /* T/F Meds have been Returned at Zero Cost */
    QUANTITY             DECIMAL(10,4),                          /* Quantity Returned */
    RESTOCK_FEE          DECIMAL(10,4),                          /* Fee to Restock */
    RETURN_COST          DECIMAL(10,4),                          /* Cost of Medicine for Amount Returned */
    RETURN_FEE           DECIMAL(10,4),                          /* Fee for Amount Returned */
    CREDIT               DECIMAL(10,4),                          /* How Much Was Credited Back to Customer */
    DTEXT                VARCHAR(255),                           /* Free Text Comment */
    CREDIT_TYPE          CHAR(1),                                /* Credit Type */

    CONSTRAINT PK_RTN PRIMARY KEY (ID)
);


/*
@Table           Refill Too Soon
@Usage           List of Scripts Filled Too Soon for a Facility
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RTS
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    RXF_ID               INTEGER NOT NULL,                       /* Script Internal ID */
    FIL_ID               INTEGER NOT NULL,                       /* Fill Internal ID */
    PRV_FIL_ID           INTEGER NOT NULL,                       /* Previous Fill Internal ID */
    QTY_DSP              DECIMAL(10,4),                          /* Quantity Dispensed to Patient */
    PRICE                DECIMAL(10,4),                          /* Price Cips Figured */
    DAYS_SUPPLY          INTEGER,                                /* Days Supply of Quantity */
    NUM_DAYS             INTEGER,                                /* Number of Days Refilled Too Soon */
    COMMENT              VARCHAR(255),                           /* Reason Refilling Too Soon */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged In at Record Creation */

    CONSTRAINT PK_RTS PRIMARY KEY (ID)
);


/*
@Table           Script
@Usage           Stores Scripts for Patients
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RX_NUMBER
*/

CREATE TABLE dbo.RXF
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RX_NUMBER            INTEGER NOT NULL,                       /* Script Number */
    REF_USED             INTEGER,                                /* Number Refills Used to Date */
    ACT_REF_USED         INTEGER,                                /* Number Refills Used to Date(Doesn't Count 0 Fills or Voids) */
    REF_LEFT             INTEGER,                                /* Number Refills Left at the Time the Last Fill Was Saved */
    SIG                  VARCHAR(255),                           /* Directions for Script */
    EXPANDED_SIG         VARCHAR(255),                           /* Expanded SIG */
    EXPANDED_ALT_SIG     VARCHAR(255),                           /* Expanded Alternate Language SIG */
    EXPAND_SIG_FLAG      CHAR(1) NOT NULL,                       /* Should this sig be expanded? */
    ROA                  VARCHAR(2) NOT NULL,                    /* Route of Administration */
    REF_DAYS_SUPPLY      INTEGER,                                /* Default # Days a Refill will Last */
    DAYS_SUPPLY          INTEGER,                                /* # of Days the Whole Script will Last */
    NEXT_FIL_TYPE        CHAR(1) NOT NULL,                       /* (Self Carry, Pill Line, Med Cart) */
    PRN_FLAG             CHAR(1) NOT NULL,                       /* Is This A PRN Script? */
    FILLS_ALLOWED        INTEGER,                                /* Total Fills Authorized (Used for PRN Orders and Controlled Drugs) */
    SIG_PRN_FLAG         CHAR(1) NOT NULL,                       /* Sig includes as needed Dosing Instructions */
    DAW                  CHAR(1) NOT NULL,                       /* Dispense As Written */
    ORIGIN               CHAR(1) NOT NULL,                       /* Prescription Origin Code */
    SCRIPTTYPE           CHAR(1) NOT NULL,                       /* (C)onverted Script,(N)ormal Script */
    DC_REA_ID            VARCHAR(8),                             /* Reason Script was DC'd */
    ORDER_NUMBER         VARCHAR(20),                            /* Order Number from Another System */
    SPLIT_ID             INTEGER,                                /* ID that links this rx to others */
    FIL_ID               INTEGER,                                /* Fill Internal ID */
    PAT_ID               INTEGER NOT NULL,                       /* Patient Internal ID */
    NM9_ID               VARCHAR(10),                            /* Order Diagnosis */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    DOC_ID               INTEGER NOT NULL,                       /* Doctor Internal ID */
    PHR_ID               INTEGER,                                /* Pharmacy Internal ID */
    NEW_RXF_ID           INTEGER,                                /* New Script Internal ID */
    NEW_RXF_ORD_ID       INTEGER,                                /* New Order Internal ID */
    OLD_RXF_ID           INTEGER,                                /* Old Script Internal ID */
    NFR_ID               INTEGER,                                /* NonFormulary Request ID */
    SCH_ID               INTEGER,                                /* Schedule for taking the Drug */
    RXF_CON_ID           INTEGER,                                /* Rx Consent Internal ID */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged In at Record Creation */
    RXF_ORD_ID           INTEGER,                                /* Internal ID of the Rx Order */
    RXF_ORD_ORDER_NUM    VARCHAR(60),                            /* Order Number */
    RXF_ORD_TYPE         VARCHAR(10),                            /* Task Type */
    RXF_ORD_CODE         VARCHAR(10),                            /* Task Code */
    ST_RX_SERIAL_NUM     VARCHAR(20),                            /* State Issued Rx Serial Number */
    TOT_QTY_DUE          DECIMAL(10,4),                          /* Total Quantity To Be Dispensed For This Order */
    QTY_DUE              DECIMAL(10,4),                          /* Quantity Still Due or Quantity Given for PRN */
    QTY_USED             DECIMAL(10,4),                          /* Total Quantity Dispensed */
    QTY_DOSE             DECIMAL(10,4),                          /* Quantity per Dose of Meds */
    DLY_QTY              DECIMAL(10,4),                          /* Quantity Taken per Day */
    REF_QTY              DECIMAL(10,4),                          /* Refill Quantity */
    QTY_RETURNED         DECIMAL(10,4),                          /* Quantity of Drug Returned */
    REPLACE_QTY          DECIMAL(10,4),                          /* Quantity of Drug Replaced */
    ORG_DATE             DATETIME NOT NULL,                      /* Original Date of Script */
    FIRST_ORG_DATE       DATETIME,                               /* Date this Order Originated */
    EXP_DATE             DATETIME NOT NULL,                      /* Date Script Expires */
    DC_DATE              DATETIME,                               /* Discontinue Date */
    ORD_DATE             DATETIME,                               /* Date Ordered */
    LAST_FIL             DATETIME,                               /* Date of Last Fill */
    DISCARD_DATE         DATETIME,                               /* Discard Date */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Record Creation */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Record Creation */
    DC_FLAG              CHAR(1) NOT NULL,                       /* T/F Rx has been manually DC'd */
    UNEVEN_DOSE_FLAG     CHAR(1) NOT NULL,                       /* Dosage Varies */
    STOCK_FLAG           CHAR(1) NOT NULL,                       /* T/F this script is stock */
    DISTRIBUTION_FLAG    CHAR(1) NOT NULL,                       /* This Rx is dispensed from distribution */
    MAR_PRINT_FLAG       CHAR(1) NOT NULL,                       /* Has this Script been printed for the MAR Weekly Report? */
    RELEASE_FLAG         CHAR(1) NOT NULL,                       /* When Patient is Released, does this med go with him/her? */
    SHORT_TERM_FLAG      CHAR(1) NOT NULL,                       /* This is a Short Term Script */
    EPCS_FLAG            CHAR(1) NOT NULL,                       /* Script is for a Controlled Substance */
    VC_TECH_USR_ID       INTEGER,                                /* Verify Control Tech Usr ID */
    VC_TECH_SYS_DATE     DATETIME,                               /* Verify Control Tech Date */
    VC_TECH_SYS_TIME     DATETIME,                               /* Verify Control Tech Time */
    VC_RPH_USR_ID        INTEGER,                                /* Verify Control Pharmacist Usr ID */
    VC_RPH_SYS_DATE      DATETIME,                               /* Verify Control Pharmacist Date */
    VC_RPH_SYS_TIME      DATETIME,                               /* Verify Control Pharmacist Time */

    CONSTRAINT PK_RXF PRIMARY KEY (ID)
);


/*
@Table           Rx Consent
@Usage           Stores Consents and the Rx's they belong to
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RXF_CON
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of the Rxf_Con Record */
    RXF_ID               INTEGER,                                /* Script Internal ID */
    RXF_ORD_ID           INTEGER,                                /* Script Order Internal ID */
    CON_ID               INTEGER,                                /* Consent Internal ID */
    START_DATE           DATETIME NOT NULL,                      /* Date Consent Starts */
    STOP_DATE            DATETIME NOT NULL,                      /* Date Consent Expires */
    CONSENT_NAME         VARCHAR(60),                            /* Person that Gave Consent */
    DTEXT                VARCHAR( MAX ),                         /* Clarifying Comment */
    COMPERABLE           VARCHAR( MAX ),                         /* Why comperable drugs in Formulary, if applicable, will not suffice */
    UNSUCCESSFUL         VARCHAR( MAX ),                         /* Previous unsuccessful therapy including Dosage and Duration */
    OBJECTIVE            VARCHAR( MAX ),                         /* Objective measures of failure, if applicable */
    EVIDENCE             VARCHAR( MAX ),                         /* New high quality evidence in literature (Web Address) */
    DETAILS              VARCHAR( MAX ),                         /* Details of problem of which drug is being reequested incuding nature, frequency, severity, impact of symptoms, how diagnosis was made */
    OTHER                VARCHAR( MAX ),                         /* Other information to support your request */
    CON_DATE             DATETIME,                               /* Date Record was approved */
    CON_TIME             DATETIME,                               /* Time Record was approved */
    CON_USR_ID           INTEGER,                                /* User who approved record */
    CON_QUEUE_FLAG       CHAR(1) NOT NULL,                       /* This consent was sent a queue for approval */
    PAT_ID               INTEGER,                                /* Patient Internal ID */
    FAC_ID               INTEGER,                                /* Facility Internal ID */
    GPI                  VARCHAR(14),                            /* Drug for Approval */
    SYS_DATE             DATETIME NOT NULL,                      /* Date Record was entered */
    SYS_TIME             DATETIME NOT NULL,                      /* Time Record was entered */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User who entered Record */

    CONSTRAINT PK_RXF_CON PRIMARY KEY (ID)
);


/*
@Table           Rx Extension
@Usage           Keeps track of each time rx is extended
@Category        Rx
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RXF_EXT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    RXF_ID               INTEGER NOT NULL,                       /* Internal ID of Rx */
    EXT_DATE             DATETIME NOT NULL,                      /* Date Rx was Extended */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Record Entry */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */

    CONSTRAINT PK_RXF_EXT PRIMARY KEY (ID)
);


/*
@Table           Script Note
@Usage           Stores Script Notes for Patients
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RXF_NOT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RXF_ID               INTEGER NOT NULL,                       /* RXF Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    TITLE                VARCHAR(30) NOT NULL,                   /* Note Title */
    DTEXT                VARCHAR( MAX ),                         /* The Note */
    NOTETYPE             CHAR(1) NOT NULL,                       /* (S)cript Screen Notes, Plain (T)ext */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Change */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */

    CONSTRAINT PK_RXF_NOT PRIMARY KEY (ID)
);


/*
@Table           Rx Orders
@Usage           Pending Rx Orders
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ORDER_NUM
*/

CREATE TABLE dbo.RXF_ORD
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    MESSAGE_TYPE         VARCHAR(10) NOT NULL,                   /* Task */
    MESSAGE_CODE         VARCHAR(10) NOT NULL,                   /* Task Message Code */
    STATUS               CHAR(1) NOT NULL,                       /* (I)n Process, (V)oid, (C)omplete */
    PAT_ID               INTEGER,                                /* Patient Internal ID */
    PAT_LNAME            VARCHAR(20),                            /* Patient's Last Name */
    PAT_FNAME            VARCHAR(20),                            /* Patient's First Name */
    PAT_MNAME            VARCHAR(10),                            /* Patient's Middle Name */
    PAT_DOB              DATETIME,                               /* Date This Patient Was Born */
    PAT_ACCT_NUMBER      VARCHAR(20),                            /* Account Number */
    PAT_BOOK_NUMBER      VARCHAR(20),                            /* Booking Number */
    PAT_GENDER           CHAR(1) NOT NULL,                       /* Gender Of Patient */
    RXF_CON_ID           INTEGER,                                /* Consent ID */
    DOC_ID               INTEGER,                                /* Doctor Internal ID */
    DOC_NAME             VARCHAR(255),                           /* Doctor Name - Unlinked */
    DOC_SPI              VARCHAR(13),                            /* Doctor SureScripts Provider ID - Unlinked */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy Internal ID */
    FAC_ID               INTEGER NOT NULL,                       /* Facility Internal ID */
    RXF_ID               INTEGER,                                /* Rx Internal ID */
    INI_ID               INTEGER,                                /* INI Internal ID */
    INO_ID               INTEGER,                                /* INO Internal ID */
    RXF_ORD_DATE         DATETIME,                               /* Rx Order Date */
    RXF_ORG_DATE         DATETIME NOT NULL,                      /* Rx Original Date */
    RXF_EXP_DATE         DATETIME NOT NULL,                      /* Rx Expiration Date */
    RXF_QTY_DOSE         DECIMAL(10,4),                          /* Quantity Per Dose of Meds */
    RXF_DLY_QTY          DECIMAL(10,4),                          /* Quantity Taken per Day */
    RXF_REF_QTY          DECIMAL(10,4),                          /* Refill Quantity */
    RXF_PRN_FLAG         CHAR(1) NOT NULL,                       /* Is This A PRN Script? */
    RXF_FILLS_ALLOWED    INTEGER,                                /* Refills Authorized for PRN */
    RXF_DAW              CHAR(1),                                /* Dispense Orders */
    RXF_ROA              VARCHAR(2) NOT NULL,                    /* Route of Administration */
    RXF_RELEASE_FLAG     CHAR(1) NOT NULL,                       /* When Patient is Released, does this med go with him/her? */
    RXF_SIG              VARCHAR(510),                           /* Directions for Script */
    RXF_EXPANDED_SIG     VARCHAR(510),                           /* Expanded SIG */
    RXF_EXPANDED_ALT_SIG VARCHAR(510),                           /* Expanded Alternate Language SIG */
    RXF_SIG_PRN_FLAG     CHAR(1) NOT NULL,                       /* T/F SIG is PRN */
    RXF_DAYS_SUPPLY      INTEGER,                                /* Days Supply for Order */
    RXF_TOT_QTY_DUE      DECIMAL(10,4),                          /* Quantity Due For Order */
    RXF_ORG_TOT_QTY      DECIMAL(11,5),                          /* Original Quantity Requested in Order */
    RXF_ORDER_TYPE       CHAR(1) NOT NULL,                       /* Order Type */
    OLD_RXF_ID           INTEGER,                                /* Old Script Internal ID */
    RXF_SCH_ID           INTEGER,                                /* Schedule Internal ID */
    NM9_ID               VARCHAR(10),                            /* Order Diagnosis */
    VIS_ID               INTEGER,                                /* Visit Internal Id */
    DRG_ID               INTEGER,                                /* Drug IDs for Involved Drugs */
    DRG_NDC              VARCHAR(13),                            /*  */
    DRG_GPI              VARCHAR(14),                            /*  */
    DRG_NAME             VARCHAR(255),                           /*  */
    DRG_FULL_NAME        VARCHAR(255),                           /*  */
    DRG_NON_MED_FLAG     CHAR(1) NOT NULL,                       /* T/F not an actual drug, like a blanket or Band-Aid */
    DRG_MULTI_ING_FLAG   CHAR(1) NOT NULL,                       /* Drug has multiple ingredients */
    DRG_STRENGTH         VARCHAR(255),                           /*  */
    DRG_DOSAGE           VARCHAR(255),                           /*  */
    DRG_USR_ID           INTEGER,                                /* User who assigned DRG */
    DRG_SYS_DATE         DATETIME,                               /* Date DRG was assigned */
    DRG_SYS_TIME         DATETIME,                               /* Time DRG was assigned */
    TER_ID               INTEGER,                                /* ID for Potency Unit Code */
    USR_ID               VARCHAR(50),                            /*  */
    USR_LNAME            VARCHAR(50),                            /*  */
    USR_FNAME            VARCHAR(50),                            /*  */
    FIL_LABEL_COUNT      INTEGER,                                /* Number of Labels to Print ( Per Set ) */
    FIL_ORIGIN           CHAR(1),                                /* Origin of Script */
    FIL_DEA              CHAR(1),                                /* DEA Number */
    FIL_QTY_DSP          DECIMAL(10,4),                          /* Quantity Dispensed */
    FIL_AUTH_NOTE        VARCHAR(30),                            /* Authorization Comment Field */
    FIL_KOP              CHAR(1),                                /* How The Pills Are Given To The Patient */
    FIL_SAFETY_CAP_FLAG  CHAR(1) NOT NULL,                       /* T/F Medicine Requires Safety Cap */
    FIL_PAT_LOCATION     VARCHAR(40),                            /* Patient Location */
    FIL_DISPENSE_TYPE    CHAR(1),                                /* Fill Dispense Type */
    FIL_CHG_ID           INTEGER,                                /* Charge Internal ID */
    FIL_PRI_ID           INTEGER,                                /* Priority Level For This Fill */
    VOID_REA_ID          VARCHAR(8),                             /* Reason ID of Void Order */
    VOID_SYS_USR_ID      INTEGER,                                /* User ID who Voided Record */
    VOID_SYS_DATE        DATETIME,                               /* Date Record was Voided */
    VOID_SYS_TIME        DATETIME,                               /* Time Record was Voided */
    VOID_VIS_ID          INTEGER,                                /* Visit Internal Id */
    PROFILE_FLAG         CHAR(1),                                /* Quantity to be Dispensed Right Now */
    DCOMMENT             VARCHAR(60),                            /* Comment */
    ORDER_NUM            VARCHAR(60) NOT NULL,                   /* Order Number from Another System */
    DOCUTRACK_ID         INTEGER,                                /* DocuTrack Document ID */
    PROCESS_USR_ID       INTEGER,                                /* User Logged into System when Record was Processed */
    PROCESS_SYS_DATE     DATETIME,                               /* Date of Processing */
    PROCESS_SYS_TIME     DATETIME,                               /* Time of Processing */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Record Entry */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    EPCS_FLAG            CHAR(1) NOT NULL,                       /* Order is for a Controlled Substance */
    EPCS_SIGN_DATE       DATETIME,                               /* Date Controlled Substance Order Was Signed */

    CONSTRAINT PK_RXF_ORD PRIMARY KEY (ID)
);


/*
@Table           Rx Schedule
@Usage           Stores the Med Schedule for an Rx
@Category        Schedule
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RXS
(
    ID                   INTEGER NOT NULL,                       /* ID */
    RXF_ID               INTEGER NOT NULL,                       /* Rxf ID */
    START_DATE           DATETIME NOT NULL,                      /* First Dose Date */
    START_PASS           VARCHAR(10) NOT NULL,                   /* First Dose Pass */
    STOP_DATE            DATETIME NOT NULL,                      /* Last Dose Date */
    STOP_PASS            VARCHAR(10) NOT NULL,                   /* Last Dose Pass */
    DIRECTIONS           VARCHAR( MAX ) NOT NULL,                /* Code Generated Description of Schedule */

    CONSTRAINT PK_RXS PRIMARY KEY (ID)
);


/*
@Table           Rx Dispense Item
@Usage           Stores Individual Dispensing Records
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RXS_DSP
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RXS_ID               INTEGER NOT NULL,                       /* Schedule ID */
    PAS_DATE             DATETIME NOT NULL,                      /* Date */
    PAS_ID               VARCHAR(10) NOT NULL,                   /* Pass ID */
    TAKE_DATE            DATETIME NOT NULL,                      /* Take Date */
    TAKE_TIME            DATETIME NOT NULL,                      /* Take Time */
    QTY                  DECIMAL(10,4),                          /* Quantity Per Dose */
    FAC_ID               INTEGER NOT NULL,                       /* Facility ID */
    USR_ID               INTEGER NOT NULL,                       /* User ID */

    CONSTRAINT PK_RXS_DSP PRIMARY KEY (ID)
);


/*
@Table           Rx Schedule Item
@Usage           Stores Individual Sch Records
@Category        Rx
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.RXS_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RXS_ID               INTEGER NOT NULL,                       /* Schedule ID */
    PAS_ID               VARCHAR(10) NOT NULL,                   /* Pass ID */
    START_DAY            INTEGER,                                /* Start Day */
    DAYS                 INTEGER,                                /* Number of Days */
    INTERVAL             INTEGER,                                /* Days Between Doses (0 = single dose) */
    QTY                  DECIMAL(10,4),                          /* Quantity Per Dose */
    SUNDAY               CHAR(1) NOT NULL,                       /* Taken on Sunday */
    MONDAY               CHAR(1) NOT NULL,                       /* Taken on Monday */
    TUESDAY              CHAR(1) NOT NULL,                       /* Taken on Tuesday */
    WEDNESDAY            CHAR(1) NOT NULL,                       /* Taken on Wednesday */
    THURSDAY             CHAR(1) NOT NULL,                       /* Taken on Thursday */
    FRIDAY               CHAR(1) NOT NULL,                       /* Taken on Friday */
    SATURDAY             CHAR(1) NOT NULL,                       /* Taken on Saturday */

    CONSTRAINT PK_RXS_ITM PRIMARY KEY (ID)
);


/*
@Table           Schedule
@Usage           Stores Schedules for Medicine Administration
@Category        Dosage
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DTEXT
*/

CREATE TABLE dbo.SCH
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    FAC_ID               INTEGER,                                /* Link To Facility Table */
    DCODE                VARCHAR(10) NOT NULL,                   /* Schedule Code */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Descriptive Text */
    DISPLAY_FLAG         CHAR(1) NOT NULL,                       /* T/F display flag */

    CONSTRAINT PK_SCH PRIMARY KEY (ID)
);


/*
@Table           Schedule Item
@Usage           Stores Specific Times for Medicine Administration
@Category        Dosage
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.SCH_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    SCH_ID               INTEGER NOT NULL,                       /* Schedule ID */
    PAS_ID               VARCHAR(10) NOT NULL,                   /* Pass ID */
    START_DAY            INTEGER,                                /* Start Day */
    DAYS                 INTEGER,                                /* Number of Days */
    INTERVAL             INTEGER,                                /* Days Between Doses (0 = single dose) */
    QTY                  DECIMAL(10,4),                          /* Quantity Per Dose */
    SUNDAY               CHAR(1) NOT NULL,                       /* Taken on Sunday */
    MONDAY               CHAR(1) NOT NULL,                       /* Taken on Monday */
    TUESDAY              CHAR(1) NOT NULL,                       /* Taken on Tuesday */
    WEDNESDAY            CHAR(1) NOT NULL,                       /* Taken on Wednesday */
    THURSDAY             CHAR(1) NOT NULL,                       /* Taken on Thursday */
    FRIDAY               CHAR(1) NOT NULL,                       /* Taken on Friday */
    SATURDAY             CHAR(1) NOT NULL,                       /* Taken on Saturday */
    STRENGTH             VARCHAR(12),                            /* Drug Strength */

    CONSTRAINT PK_SCH_ITM PRIMARY KEY (ID)
);


/*
@Table           Security
@Usage           Stores Security Information
@Category        Security
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.SEC
(
    ID                   INTEGER NOT NULL,                       /* Security Internal ID */
    DNAME                VARCHAR(30) NOT NULL,                   /* User Friendly Record Identifier */
    DTEXT                VARCHAR(50),                            /* Record Descriptive Text */
    ONACCESS             CHAR(1) NOT NULL,                       /* Security Level for Accessing a RecordProgram */
    ONADD                CHAR(1) NOT NULL,                       /* Security Level for Adding a Record */
    ONCHANGE             CHAR(1) NOT NULL,                       /* Security Level for Changing a Record */
    ONDELETE             CHAR(1) NOT NULL,                       /* Security Level for Deleting a Record */

    CONSTRAINT PK_SEC PRIMARY KEY (ID)
);


/*
@Table           Security User Groups
@Usage           Stores Security Levels for User Groups
@Category        Security
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        SEC_ID,UGP_ID
*/

CREATE TABLE dbo.SEC_UGP
(
    ID                   INTEGER NOT NULL,                       /* Security User Group Internal ID */
    SEC_ID               INTEGER NOT NULL,                       /* Security Internal ID */
    UGP_ID               INTEGER NOT NULL,                       /* User Group Internal ID */
    ONACCESS             CHAR(1) NOT NULL,                       /* Security Level for Accessing a Record */
    ONADD                CHAR(1) NOT NULL,                       /* Security Level for Adding a Record */
    ONCHANGE             CHAR(1) NOT NULL,                       /* Security Level for Changing a Record */
    ONDELETE             CHAR(1) NOT NULL,                       /* Security Level for Deleting a Record */

    CONSTRAINT PK_SEC_UGP PRIMARY KEY (ID)
);


/*
@Table           Security User
@Usage           Stores Security Levels for Users
@Category        Security
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        SEC_ID,USR_ID
*/

CREATE TABLE dbo.SEC_USR
(
    ID                   INTEGER NOT NULL,                       /* Security User Internal ID */
    SEC_ID               INTEGER NOT NULL,                       /* Security Internal ID */
    USR_ID               INTEGER NOT NULL,                       /* User Internal ID */
    ONACCESS             CHAR(1) NOT NULL,                       /* Security Level for Accessing a Record */
    ONADD                CHAR(1) NOT NULL,                       /* Security Level for Adding a Record */
    ONCHANGE             CHAR(1) NOT NULL,                       /* Security Level for Changing a Record */
    ONDELETE             CHAR(1) NOT NULL,                       /* Security Level for Deleting a Record */

    CONSTRAINT PK_SEC_USR PRIMARY KEY (ID)
);


/*
@Table           Station
@Usage           Talyst Station
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.STA
(
    ID                   VARCHAR(5) NOT NULL,                    /* Short Code */
    DTEXT                VARCHAR(30) NOT NULL,                   /* Station Description */
    PATH                 VARCHAR(255),                           /* Path */
    DTYPE                CHAR(1) NOT NULL,                       /* Machine Type */
    PAT_DTYPE            CHAR(1) NOT NULL,                       /* Pat Number */
    DRG_DTYPE            CHAR(1) NOT NULL,                       /* Drug Number */
    PHARMACY_FLAG        CHAR(1) NOT NULL,                       /* This Machine is physically located in the pharmacy. */
    RECONCILE_FLAG       CHAR(1) NOT NULL,                       /* This Machine sends back reconciliation data */
    TSK_ID               INTEGER,                                /* Task ID */

    CONSTRAINT PK_STA PRIMARY KEY (ID)
);


/*
@Table           Standard Order
@Usage           Standard Med Order
@Category        Standard Order
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.STD
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DCODE                VARCHAR(8) NOT NULL,                    /* Standard Order Code */
    DNAME                VARCHAR(60) NOT NULL,                   /* Standard Order Name */
    DNOTE                VARCHAR(255) NOT NULL,                  /* Standard Order Note */
    USE_FLAG             CHAR(1) NOT NULL,                       /* Can this Order be Used? */

    CONSTRAINT PK_STD PRIMARY KEY (ID)
);


/*
@Table           Standard Order Item
@Usage           Standard Med Order Item
@Category        Standard Order Item
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.STD_ITM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    STD_ID               INTEGER NOT NULL,                       /* Standard Order */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    DAYS_SUPPLY          INTEGER NOT NULL,                       /* Days Supply of Quantity */
    SIG                  VARCHAR(255),                           /* Directions for Script */
    PROFILE_FLAG         CHAR(1) NOT NULL,                       /* Profile This Standard Order Item */
    SCH_ID               INTEGER,                                /* Schedule for taking the Drug */
    QTY_PER_DOSE         DECIMAL(10,4),                          /* Quantity Per Dose */
    DAILY_QTY            DECIMAL(10,4),                          /* Daily Quantity */
    FUTURE_START_DAYS    INTEGER,                                /* CIPS Will Add This # Of Days To Today For a Start Date */
    ICD9                 VARCHAR(20),                            /* ICD9 Code */

    CONSTRAINT PK_STD_ITM PRIMARY KEY (ID)
);


/*
@Table           Terminology Translations
@Usage           SureScripts Terminology
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TER
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    NCLT_SUBSET_CODE     VARCHAR(10) NOT NULL,                   /* NCIT Subset Code */
    NCLT_CODE            VARCHAR(10) NOT NULL,                   /* NCIT Code */
    NCPDP_SUBSET_PR_TERM VARCHAR(40),                            /* NCPDP Subset Preferred Term */
    NCPDP_PR_TERM        VARCHAR(70),                            /* NCPDP Preferred Term */
    NCLT_PR_TERM         VARCHAR(80),                            /* NCIT Preferred Term */

    CONSTRAINT PK_TER PRIMARY KEY (ID)
);


/*
@Table           Therapeutic Class
@Usage           Stores Therapeutic Classes
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.THC
(
    ID                   VARCHAR(10) NOT NULL,                   /* Therapeutic Class Code from First Databank */
    DSHORT               CHAR(1) NOT NULL,                       /* T/F ID is 2 Chars - Show in Short List */
    DTEXT                VARCHAR(60),                            /* Text Description of Class */

    CONSTRAINT PK_THC PRIMARY KEY (ID)
);


/*
@Table           Third Party
@Usage           Stores Third Party Information
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID,DNAME
*/

CREATE TABLE dbo.THP
(
    ID                   VARCHAR(12) NOT NULL,                   /* Third Party Initial */
    DNAME                VARCHAR(30) NOT NULL,                   /* Third Party Name */
    PLAN_NUMBER          VARCHAR(8),                             /* Plan Number */
    BINNUMBER            INTEGER,                                /* BIN Number of Third Party */
    PROCESSOR            VARCHAR(10),                            /* Processor ( Switch ) */
    PHARMACY             VARCHAR(15),                            /* Pharmacy ID Number */
    PHARMACYQ            CHAR(1) NOT NULL,                       /* Pharmacy ID Qualifier */
    VERSION              CHAR(1) NOT NULL,                       /* Version to Send */
    DOCTORQ              CHAR(1) NOT NULL,                       /* Doctor ID Qualifier */
    COMMENT              VARCHAR(255),                           /* Comment */
    NUM_REFILLS          INTEGER,                                /* Maximum Number of Refills */
    DAYS_REFILLS         INTEGER,                                /* Minimum Number of Days Between Refills */
    PCNT_DAYS_REFILLS    DECIMAL(5,2),                           /* Percent Days to Refill */
    ADDRESS1             VARCHAR(30),                            /*  */
    ADDRESS2             VARCHAR(30),                            /*  */
    CITY                 VARCHAR(20),                            /*  */
    ST                   VARCHAR(2),                             /*  */
    ZIP                  VARCHAR(10),                            /*  */
    PHONE                VARCHAR(14),                            /*  */
    CONTACT              VARCHAR(30),                            /*  */
    LABEL_TEXT           VARCHAR(60),                            /*  */
    WEBSITE_URL          VARCHAR(255),                           /*  */
    IP1                  VARCHAR(14),                            /* IP Address to Use */
    IP2                  VARCHAR(14),                            /* IP Address to Use */
    MEDICAID_FLAG        CHAR(1),                                /* This is a Medicaid Third Party */
    MEDICARE_FLAG        CHAR(1),                                /* This is a Medicare Third Party */
    PLAN_ID              VARCHAR(8),                             /* Plan ID */
    PLAN_TYPE            CHAR(1) NOT NULL,                       /* Plan Type */
    WORKCOMP_FLAG        CHAR(1) NOT NULL,                       /* Workman's Comp Claims Accepted */
    HCFA_FLAG            CHAR(1) NOT NULL,                       /* HCFA Claims Accepted */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* This Third Party Is Not Available */
    BND_PRC_ID           INTEGER,                                /* Brand Price Code */
    GEN_PRC_ID           INTEGER,                                /* Generic Price Code */
    USE_DRG_PRC          CHAR(1) NOT NULL,                       /* Use Drug Price Code */
    ADDON                DECIMAL(10,4),                          /* Addon Amount for All Claims */
    CASH_FLAG            CHAR(1) NOT NULL,                       /* Use Cash Pricing */
    USUAL_FLAG           CHAR(1) NOT NULL,                       /* Use Usual Pricing */
    SEND_PRC_FLAG        CHAR(1) NOT NULL,                       /* Send Figured Third Party Price as Usual and Customary */
    BILL_FLAG            CHAR(1) NOT NULL,                       /* Bill Full Price on Secondary */
    SVCN                 VARCHAR(10),                            /* Software Vendor Certification Number */
    ACCEPT_ASSIGN        CHAR(1) NOT NULL,                       /* Pharmacy Accepts Assignments */
    CMS_FACILITY         CHAR(1) NOT NULL,                       /* CMS Part D Defined Qualified Facility */
    SEGMENT_AM02_FLAG    CHAR(1) NOT NULL,                       /* Whether or not to send the AM02 segment in NCPDP 5.1 or D.0 */
    SEGMENT_AM05_FLAG    CHAR(1) NOT NULL,                       /* Whether or not to send the AM05 segment in NCPDP 5.1 or D.0 */
    SEGMENT_AM08_FLAG    CHAR(1) NOT NULL,                       /* Whether or not to send the AM08 segment in NCPDP 5.1 or D.0 */
    SEGMENT_AM10_FLAG    CHAR(1) NOT NULL,                       /* Whether or not to send the AM10 segment in NCPDP 5.1 or D.0 */
    SEGMENT_AM13_FLAG    CHAR(1) NOT NULL,                       /* Whether or not to send the AM13 segment in NCPDP 5.1 or D.0 */
    SEGMENT_AM15_FLAG    CHAR(1) NOT NULL,                       /* Whether or not to send the AM15 segment in NCPDP D.0 */
    P3P_ID_NUMBER        CHAR(1) NOT NULL,                       /* Type of Number the Third Party Uses for Validation */
    GRP_NUMBER           VARCHAR(15),                            /* Group Number */
    PERSON_CODE          VARCHAR(3),                             /* Person Code */
    CARD_ID_MASK         VARCHAR(20),                            /* Cardholder ID Mask */
    RELATION             CHAR(1) NOT NULL,                       /* Relationship to Cardholder */
    RX_ORIGIN            CHAR(1) NOT NULL,                       /* Default Prescription Origin Code */
    RX_DAW               CHAR(1) NOT NULL,                       /* Default Prescription DAW */

    CONSTRAINT PK_THP PRIMARY KEY (ID)
);


/*
@Table           Third Party GPI
@Usage           Logic for whether a drug should be submitted to third party
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        THP_ID,SEQ_NUM
*/

CREATE TABLE dbo.THP_GPI
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    THP_ID               VARCHAR(12) NOT NULL,                   /* Third Party ID */
    SEQ_NUM              INTEGER,                                /* Sequence Number */
    ACTION               CHAR(1) NOT NULL,                       /* If the Criteria is Met, Apply This Action */
    GPI                  VARCHAR(25),                            /* Criteria: GPI */
    BILL_DISC            CHAR(1) NOT NULL,                       /* Bill Full Amount on Rx Discontinue */

    CONSTRAINT PK_THP_GPI PRIMARY KEY (ID)
);


/*
@Table           Groups
@Usage           Stores Groups for Third Parties
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        THP_ID,NUMBER
*/

CREATE TABLE dbo.THP_GRP
(
    ID                   INTEGER NOT NULL,                       /* Internal */
    THP_ID               VARCHAR(12) NOT NULL,                   /* Third Party Initial */
    NUMBER               VARCHAR(15) NOT NULL,                   /* Group Number */
    DTEXT                VARCHAR(60) NOT NULL,                   /* Group Description */
    BRAND_FEE            DECIMAL(10,4),                          /* Brand Fee */
    BND_PRICE_FLAG       CHAR(1) NOT NULL,                       /* Brand Customary Price */
    GENERIC_FEE          DECIMAL(10,4),                          /* Generic Fee */
    GEN_PRICE_FLAG       CHAR(1) NOT NULL,                       /* Generic Customary Price */
    FORCE_HOT_SUBMIT     CHAR(1) NOT NULL,                       /* If a price code exists in the drug exception, allow claim to be submitted */

    CONSTRAINT PK_THP_GRP PRIMARY KEY (ID)
);


/*
@Table           Third Party Claim Format
@Usage           Tells How to Handle Fields For Claims
@Category        Third Party
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        THP_ID,FIELD
*/

CREATE TABLE dbo.THP_FMT
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Record */
    THP_ID               VARCHAR(12) NOT NULL,                   /* Third Party Initial ID */
    FIELD                VARCHAR(2) NOT NULL,                    /* Field */
    ACTION               CHAR(1) NOT NULL,                       /* Action */
    DEF_VALUE            VARCHAR(30),                            /* Default Value */

    CONSTRAINT PK_THP_FMT PRIMARY KEY (ID)
);


/*
@Table           Talyst Batch Item
@Usage           Talyst Batch Item
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TBI
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    TBX_ID               VARCHAR(23) NOT NULL,                   /* Batch Number */
    METHOD               CHAR(1) NOT NULL,                       /* Per Dose, Etc. */
    PAS_DATE             DATETIME NOT NULL,                      /* Date */
    PAS_ID               VARCHAR(10),                            /* Description of Time to take Meds, AM, PM, HS */
    FIL_ID               INTEGER NOT NULL,                       /* Fill ID of this order */
    QTY                  DECIMAL(10,4) NOT NULL,                 /* Quantity Dispensed */
    LABEL                CHAR(1) NOT NULL,                       /* Label Printed */
    FORWARD_TBX_ID       VARCHAR(23),                            /* Forward Batch Number */
    TRANS_ID             VARCHAR(32),                            /* Transaction Number */
    DISP_DATE            DATETIME,                               /* Date */
    DISP_TIME            DATETIME,                               /* Time */
    LINE_NUMBER          INTEGER,                                /* Line Item Number */
    AUTOMED_BAG_ID       INTEGER,                                /* Automed Bag ID */

    CONSTRAINT PK_TBI PRIMARY KEY (ID)
);


/*
@Table           Talyst Batch
@Usage           Talyst Batch Information
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TBX
(
    ID                   VARCHAR(23) NOT NULL,                   /* Internal Id */
    PARENT_ID            VARCHAR(23),                            /* Batch Number */
    FAC_ID               INTEGER,                                /* Facility Unit ID */
    STA_ID               VARCHAR(5),                             /* Location */
    USR_ID               INTEGER,                                /* Operator ID */
    METHOD               CHAR(1) NOT NULL,                       /* Per Dose, Etc. */
    PAS_DATE             DATETIME,                               /* Dispense Date */
    PAS_ID               VARCHAR(10),                            /* Description of Time to take Meds, AM, PM, NOON */
    LAST_ADD_DATE        DATETIME,                               /* Date Sent */
    LAST_ADD_TIME        DATETIME,                               /* Time Sent */
    SERVER_SEND_DATE     DATETIME,                               /* Date Sent */
    SERVER_SEND_TIME     DATETIME,                               /* Time Sent */
    LAST_RECV_DATE       DATETIME,                               /* Date Sent */
    LAST_RECV_TIME       DATETIME,                               /* Time Sent */

    CONSTRAINT PK_TBX PRIMARY KEY (ID)
);


/*
@Table           Tapered Dose
@Usage           Stores Tapered Dose Schedules
@Category        Dosage
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID,DOSE_NUM
*/

CREATE TABLE dbo.TPD
(
    RXF_ID               INTEGER NOT NULL,                       /* RXF Internal ID */
    DOSE_NUM             INTEGER NOT NULL,                       /* Dose Number in Sequence */
    QTY_PER_DAY          DECIMAL(10,4),                          /* Quantity of Medication Taken for the Day */
    QTY_PER_DOSE         DECIMAL(10,4),                          /* Quantity of Medication Taken Per Dose */
    DAYS_SUPPLY          INTEGER,                                /* Number of Days at this Dosage */
    SIG                  VARCHAR(151),                           /* Sig Instructions */

    CONSTRAINT PK_TPD PRIMARY KEY (RXF_ID,DOSE_NUM)
);


/*
@Table           Transaction Code
@Usage           Stores Transaction Codes
@Category        Transaction
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TRC
(
    ID                   VARCHAR(4) NOT NULL,                    /* Internal ID */
    ADJ_CODE             CHAR(1),                                /* Type of Adjustment */
    DTEXT                VARCHAR(25),                            /* Descriptive Text */

    CONSTRAINT PK_TRC PRIMARY KEY (ID)
);


/*
@Table           Patient Rx Transfer
@Usage           Used to keep history of scripts transferred between patients
@Category        Script
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        RXF_ID
*/

CREATE TABLE dbo.TRF
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    RXF_ID               INTEGER,                                /* Rx ID */
    RXF_ORD_ID           INTEGER,                                /* Rx Ord ID */
    USR_ID               INTEGER NOT NULL,                       /* User ID */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    TO_PAT_ID            INTEGER NOT NULL,                       /* Script was transferred TO this patient */
    FROM_PAT_ID          INTEGER NOT NULL,                       /* Script was transferred FROM this patient */

    CONSTRAINT PK_TRF PRIMARY KEY (ID)
);


/*
@Table           Terminal
@Usage           Log Of Cips Terminals
@Category        System
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TRM
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DOMAIN_NAME          VARCHAR(255) NOT NULL,                  /* Domain Name */
    TERM_NAME            VARCHAR(255) NOT NULL,                  /* Terminal Name */
    DTYPE                CHAR(1),                                /* Which Program? */
    LOG_VERSION          VARCHAR(12) NOT NULL,                   /* The Version Cips was User Logged In */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Entry */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Entry */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Logged into System at Record Entry */

    CONSTRAINT PK_TRM PRIMARY KEY (ID)
);


/*
@Table           Tiny Rx
@Usage           Tiny Rx
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TRX
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    RXF_ID               INTEGER,                                /* Rx ID */
    PAS_DATE             DATETIME NOT NULL,                      /* Date */
    PAS_ID               VARCHAR(10) NOT NULL,                   /* Description of Time to take Meds, AM, PM, HS */
    QTY                  DECIMAL(10,4) NOT NULL,                 /* Quantity Due (Max on PRN) */
    SCANNED_DATE         DATETIME,                               /* Date Scanned */
    SCANNED_TIME         DATETIME,                               /* Time Scanned */
    SCANNED_USR_ID       INTEGER,                                /* The User Who Scannned */
    HIDE_MISMATCH        CHAR(1) NOT NULL,                       /* Hide Mismatch */
    RTN_SCANNED_DATE     DATETIME,                               /* Date Scanned */
    RTN_SCANNED_TIME     DATETIME,                               /* Time Scanned */
    RTN_SCANNED_USR_ID   INTEGER,                                /* The User Who Scannned the Return */

    CONSTRAINT PK_TRX PRIMARY KEY (ID)
);


/*
@Table           Task
@Usage           CIPS Task
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TSK
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    DTYPE                VARCHAR(10) NOT NULL,                   /* Task Type */
    DCODE                VARCHAR(10) NOT NULL,                   /* Facility, Region, Pharmacy or Instance that will use this task */
    DELAY                INTEGER,                                /* Delay Between Running Task */
    RUN_DATE             DATETIME,                               /* Last Run Date */
    RUN_TIME             DATETIME,                               /* Daily Run Time */
    OFFLINE_FLAG         CHAR(1) NOT NULL,                       /* Interface is Offline */
    IP_ADDRESS           VARCHAR(100),                           /* TCP/IP Server Address or Web URL */
    IP_PORT              INTEGER,                                /* TCP/IP Server Port */
    USERNAME             VARCHAR(30),                            /* Used for FTP */
    PASSWORD             VARCHAR(30),                            /* Used for FTP */
    FOLDER               VARCHAR(255),                           /* Watch Folder */
    MASK                 VARCHAR(100),                           /* Included Files */
    MIN_LINES            INTEGER,                                /* Minimum Lines to Process File */
    MIN_LENGTH           INTEGER,                                /* Minimum Line Length to Process Line */
    ENDOFFILE            CHAR(1) NOT NULL,                       /* ENDOFFILE at end of file. */
    OUTBOUND_FOLDER      VARCHAR(255),                           /* Outbound Folder */
    START_LINE           INTEGER,                                /* The Line The Interface Starts At On Each File */
    FAC_ID               INTEGER,                                /* Facility ID */
    RGN_ID               INTEGER,                                /* Region ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy ID */
    USR_ID               INTEGER NOT NULL,                       /* User ID */
    RELEASE_WINDOW       INTEGER,                                /* Number of hours to wait before final release */
    FAC_BY_NAME_FLAG     CHAR(1) NOT NULL,                       /*  */
    PAT_FLAG             CHAR(1) NOT NULL,                       /*  */
    DRG_FLAG             CHAR(1) NOT NULL,                       /*  */
    RXF_FLAG             CHAR(1) NOT NULL,                       /*  */
    FIL_FLAG             CHAR(1) NOT NULL,                       /* When to send the Fill */
    ORD_FLAG             CHAR(1) NOT NULL,                       /*  */
    TBX_FLAG             CHAR(1) NOT NULL,                       /*  */
    PHARM_SCAN_FLAG      CHAR(1) NOT NULL,                       /*  */
    FAC_SCAN_FLAG        CHAR(1) NOT NULL,                       /*  */
    ERROR_FLAG           CHAR(1) NOT NULL,                       /*  */
    VOID_FLAG            CHAR(1) NOT NULL,                       /*  */
    VOID_FLAG_ALWAYS     CHAR(1) NOT NULL,                       /* Send Void/Delete Messages For E-Orders Every Time */
    PING                 CHAR(1) NOT NULL,                       /* CIPS Requested a Response from this task */

    CONSTRAINT PK_TSK PRIMARY KEY (ID)
);


/*
@Table           SureScripts Doctor
@Usage           SureScripts Doctors
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TSK_DOC
(
    ID                   INTEGER NOT NULL,                       /* Internal Id */
    NUMBER               VARCHAR(50) NOT NULL,                   /* SureScripts Provider ID (SPI) Number */
    DEA                  VARCHAR(25),                            /* DEA */
    STATE_LICENSE        VARCHAR(35),                            /* State License */
    ORGANIZATION_ID      VARCHAR(10),                            /* Provider Organization ID */
    SPECIALTY_CODE       VARCHAR(15),                            /* Specialty Code */
    SPECIALTY_QUALIFIER  VARCHAR(2),                             /* Specialty Code Qualifier */
    PREFIX_NAME          VARCHAR(10),                            /* Prefix */
    LNAME                VARCHAR(50) NOT NULL,                   /* Last Name */
    FNAME                VARCHAR(50),                            /* First Name */
    MNAME                VARCHAR(50),                            /* Middle Name */
    SUFFIX_NAME          VARCHAR(15),                            /* Suffix */
    CLINIC_NAME          VARCHAR(50),                            /* Clinic Name */
    ADDRESS1             VARCHAR(50),                            /* Address 1 */
    ADDRESS2             VARCHAR(50),                            /* Address 2 */
    CITY                 VARCHAR(50),                            /* City */
    STATE                VARCHAR(2),                             /* State */
    ZIP                  VARCHAR(11),                            /* Zip */
    STD_ADDRESS1         VARCHAR(100),                           /* Standardized Address 1 */
    STD_ADDRESS2         VARCHAR(100),                           /* Standardized Address 2 */
    STD_CITY             VARCHAR(50),                            /* Standardized City */
    STD_STATE            VARCHAR(2),                             /* Standardized State */
    STD_ZIP              VARCHAR(11),                            /* Standardized Zip */
    PRIMARY_PHONE        VARCHAR(25),                            /* Phone Number */
    FAX                  VARCHAR(25),                            /* Fax Number */
    EMAIL                VARCHAR(80),                            /* Email Address */
    PHONE1_Q             VARCHAR(3),                             /* Phone 1 Qual */
    PHONE1               VARCHAR(25),                            /* Phone 1 */
    PHONE2_Q             VARCHAR(3),                             /* Phone 2 Qual */
    PHONE2               VARCHAR(25),                            /* Phone 2 */
    PHONE3_Q             VARCHAR(3),                             /* Phone 3 Qual */
    PHONE3               VARCHAR(25),                            /* Phone 3 */
    PHONE4_Q             VARCHAR(3),                             /* Phone 4 Qual */
    PHONE4               VARCHAR(25),                            /* Phone 4 */
    PHONE5_Q             VARCHAR(3),                             /* Phone 5 Qual */
    PHONE5               VARCHAR(25),                            /* Phone 5 */
    PHONE6_Q             VARCHAR(3),                             /* Phone 6 Qual */
    PHONE6               VARCHAR(25),                            /* Phone 6 */
    START_DATE           DATETIME,                               /* Start Date */
    STOP_DATE            DATETIME,                               /* Stop Date */
    SERVICE_LEVEL        VARCHAR(50),                            /* Service Level */
    OLD_SERVICE_LEVEL    VARCHAR(50),                            /* Old Service Level */
    PARTNER_ACCOUNT      VARCHAR(50),                            /* Partner Account */
    LAST_MODIFIED        DATETIME,                               /* Last Modified */
    NPI                  VARCHAR(15),                            /* NPI */
    NPI_LOCATION         VARCHAR(15),                            /* NPI Location */
    SPECIALTY1           VARCHAR(35),                            /* Specialty 1 */
    SPECIALTY2           VARCHAR(35),                            /* Specialty 2 */
    SPECIALTY3           VARCHAR(35),                            /* Specialty 3 */
    SPECIALTY4           VARCHAR(35),                            /* Specialty 4 */
    FILE_ID              VARCHAR(35),                            /* File ID */
    UPIN                 VARCHAR(35),                            /* UPIN */
    MEDICARE_ID          VARCHAR(35),                            /* Medicare ID */
    MEDICAID_ID          VARCHAR(35),                            /* Medicaid ID */
    PPO_NUMBER           VARCHAR(35),                            /* PPO Number */
    SSN                  VARCHAR(35),                            /* SSN */
    PA_ID                VARCHAR(35),                            /* Prior Authorization */
    DENTAL_ID            VARCHAR(35),                            /* Dental ID */
    VERSION              VARCHAR(10),                            /* SureScripts Version */
    NETWORK_TYPE         CHAR(1) NOT NULL,                       /* Network Type */
    DORMANT_FLAG         CHAR(1) NOT NULL,                       /* Dormant */
    SYS_DATE             DATETIME NOT NULL,                      /* System Date */
    SYS_TIME             DATETIME NOT NULL,                      /* System Time */

    CONSTRAINT PK_TSK_DOC PRIMARY KEY (ID)
);


/*
@Table           Task Log
@Usage           Task Log
@Category        
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.TSK_LOG
(
    ID                   INTEGER IDENTITY(1,1) NOT NULL,         /* Internal Id */
    DTYPE                VARCHAR(10) NOT NULL,                   /* Task Type */
    DCODE                VARCHAR(10) NOT NULL,                   /* Task Code */
    SOURCEFILE           VARCHAR(255),                           /*  */
    SOURCELINE           VARCHAR(255),                           /*  */
    DTEXT                VARCHAR( MAX ),                         /* Log Entry Text */
    SYS_DATE             DATETIME NOT NULL,                      /* Date of Change */
    SYS_TIME             DATETIME NOT NULL,                      /* Time of Change */
    SYS_USR_ID           INTEGER NOT NULL,                       /* User Internal ID */
    CONTACT              VARCHAR(35),                            /* Contact */
    RELATED_CONTROL_ID   VARCHAR(60),                            /* Related Control ID */
    INI_ID               INTEGER,                                /* Incoming */
    INO_ID               INTEGER,                                /* Outgoing */

    CONSTRAINT PK_TSK_LOG PRIMARY KEY (ID)
);


/*
@Table           User Groups
@Usage           Stores User Group Information
@Category        Security
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.UGP
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Group Record */
    DNAME                VARCHAR(40) NOT NULL,                   /* Name of Group */
    DCOMMENT             VARCHAR(255),                           /* Description of Group */

    CONSTRAINT PK_UGP PRIMARY KEY (ID)
);


/*
@Table           User
@Usage           Stores CIPS User Information
@Category        User
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        LNAME,FNAME
*/

CREATE TABLE dbo.USR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this User Record */
    LNAME                VARCHAR(25) NOT NULL,                   /* Last Name Of User */
    FNAME                VARCHAR(20) NOT NULL,                   /* First Name Of User */
    LOGINID              VARCHAR(100) NOT NULL,                  /* User Name To Log In With */
    INITIALS             VARCHAR(3),                             /* User Initials */
    LOGINPASS            VARCHAR(60) NOT NULL,                   /* User's Password To Log In With */
    OLD_LOGINPASS        VARCHAR(60),                            /* User's Old Password */
    PHR_ID               INTEGER NOT NULL,                       /* Internal ID of the Pharmacy This User Is Tied To */
    FAC_ID               INTEGER,                                /* Internal ID of the Facility This User Is Tied To */
    RGN_ID               INTEGER,                                /* If set, a remote user will be prompted to pick a facility that is part of this region */
    ACCESSMODE           CHAR(1) NOT NULL,                       /* User Default Security Access Setting */
    USERTYPE             CHAR(1) NOT NULL,                       /* User's Position In The Organization */
    ACTIVE_STATUS        CHAR(1) NOT NULL,                       /* User's Status (i.e. Active, Inactive) */
    AUTO_LOGIN           CHAR(1) NOT NULL,                       /* Automatically Login With Windows Username */
    AUTO_INITIAL         CHAR(1) NOT NULL,                       /* Display Initials Automatically During Filling */
    PASS_EXP_DATE        DATETIME,                               /* Last Day User Will Be Able To Access The System */
    PASS_EXP_DAYS        INTEGER,                                /* Days From Password Change the Password Is Good For */
    DOC_ID               INTEGER,                                /* Doctor Who Will Be Displayed When Entering Order */
    USR_DOC_ID           INTEGER,                                /* Doctor Who Is This User */
    EMAIL                VARCHAR(50),                            /* User's E-Mail Address */
    PHR_INITIALS         VARCHAR(3),                             /* Pharmacist Initials To Use When Auto-Populating */
    TCH_INITIALS         VARCHAR(3),                             /* Tech Initials To Use When Auto-Populating */
    NPI                  VARCHAR(20),                            /* National Provider */
    NONFORMULARY_ROLE    CHAR(1) NOT NULL,                       /* How Much Power Does The User Have In Non Formulary Approvals? */
    DOCSIGN_ROLE         CHAR(1) NOT NULL,                       /* Does User Have Ability To Sign Electronic Orders? */
    QUE_ID               INTEGER,                                /* Use This Queue If None Other Found */
    LAST_LOGIN_DATE      DATETIME,                               /* The Last Date This User Logged In */
    LAST_LOGIN_TIME      DATETIME,                               /* The Last Time This User Logged In */

    CONSTRAINT PK_USR PRIMARY KEY (ID)
);


/*
@Table           User User Group
@Usage           Places a User in a User Group
@Category        Security,User
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        USR_ID,UGP_ID
*/

CREATE TABLE dbo.USR_UGP
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this User Group Record */
    USR_ID               INTEGER NOT NULL,                       /* User Internal ID */
    UGP_ID               INTEGER NOT NULL,                       /* User Group Internal ID */

    CONSTRAINT PK_USR_UGP PRIMARY KEY (ID)
);


/*
@Table           Vendor
@Usage           Stores CIPS Vendor Information
@Category        Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        DNAME
*/

CREATE TABLE dbo.VEN
(
    ID                   INTEGER NOT NULL,                       /* Internal ID of this Vendor Record */
    DNAME                VARCHAR(30) NOT NULL,                   /* Vendor Name */
    MIN_AMOUNT           DECIMAL(10,4),                          /* Minimum Order Amount */
    MIN_QUANT            DECIMAL(10,4),                          /* Minimum Order Quantity */
    LAGTIME              INTEGER,                                /* Lag in Days Between Order and Delivery ( No bearing on auto ordering ) */
    ADDRESS              VARCHAR(20),                            /* Vendor Address */
    CITY                 VARCHAR(20),                            /* Vendor City */
    ST                   VARCHAR(2),                             /* Vendor State */
    TYPECODE             CHAR(1) NOT NULL,                       /* Vendor Type */
    ZIP                  VARCHAR(10),                            /* Vendor Zip Code */
    PHONE                VARCHAR(14),                            /* Vendor Phone Number */
    EMAIL                VARCHAR(50),                            /* Vendor Email */
    DEA                  VARCHAR(12),                            /* Vendor DEA Number */
    ORDER_PHONE          VARCHAR(14),                            /* Vendor Phone Number for Orders */
    CUSTOMER_ID          VARCHAR(12),                            /* Vendor Supplied Customer Number */
    DELIVER_DAY          CHAR(1) NOT NULL,                       /* Day of Week for Delivery */

    CONSTRAINT PK_VEN PRIMARY KEY (ID)
);


/*
@Table           Warehouse Adjustment Batch
@Usage           Adjusts Warehouse Inventory for Inventory Counts
@Category        Inventory,Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.WAB
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    COUNT_DATE           DATETIME,                               /* Date of Initial Count */
    RECOUNT_DATE         DATETIME,                               /* Date of Recount */
    ADJ_DATE             DATETIME NOT NULL,                      /* Date the User Enters for this Drug Inventory Adjustment */
    STATUS               CHAR(1),                                /* (O)pen,(C)losed,(I)n use,(V)oided */
    REF_NUM              VARCHAR(30),                            /* Batch Number from Other System */
    DTEXT                VARCHAR(60),                            /* Batch Description */

    CONSTRAINT PK_WAB PRIMARY KEY (ID)
);


/*
@Table           Warehouse Adjustment Batch Item
@Usage           Adjusts Warehouse Inventory for Specific Items
@Category        Inventory,Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        WAB_ID,DRG_ID
*/

CREATE TABLE dbo.WAB_ITM
(
    WAB_ID               INTEGER NOT NULL,                       /* WAB Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    FIRST_COUNT          DECIMAL(10,4),                          /* Initial Count */
    RECOUNT              DECIMAL(10,4),                          /* Recount */
    QTY_ONHAND           DECIMAL(10,4),                          /* Quantity Onhand */
    DCOMMENT             VARCHAR(30),                            /* Free Text Comment */

    CONSTRAINT PK_WAB_ITM PRIMARY KEY (WAB_ID,DRG_ID)
);


/*
@Table           Warning GPI
@Usage           Used to Cross Reference Warnings for a GPI
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        GPI,PRIOR_CODE
*/

CREATE TABLE dbo.WGP
(
    GPI                  VARCHAR(14) NOT NULL,                   /* GPI Code */
    PRIOR_CODE           INTEGER NOT NULL,                       /* Priority Code */
    MEDI_CODE            VARCHAR(6),                             /* Medi Code for Other Lookups */
    CHANGED_ON           DATETIME,                               /* Date of Last Change */

    CONSTRAINT PK_WGP PRIMARY KEY (GPI,PRIOR_CODE)
);


/*
@Table           Warehouse Cage Incoming
@Usage           Used to Track Requisitions coming back from the PHR
@Category        Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.WHI
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* Pharmacy that these Drugs came from */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    NDC                  VARCHAR(13) NOT NULL,                   /* NDC Number 5-4-2 Format */
    QTY                  INTEGER NOT NULL,                       /* Quantity Received */
    COST                 DECIMAL(10,4) NOT NULL,                 /* Cost for the Quantity Received */
    RETURN_DATE          DATETIME,                               /* Date the Drugs Entered the Cage, came back from PHR */
    EXPIRE_DATE          DATETIME,                               /* Date Drugs have to be used by */
    SHIP_BY_DATE         DATETIME,                               /* Date to be Shipped back out by */
    TRAN_TYPE            CHAR(1),                                /* (R)ecall, (O)utdate, (D)elete, (U)nusable, (O)ther */
    STATUS               CHAR(1),                                /* Status of this Drug */
    REA_ID               VARCHAR(8),                             /* Reason for Return */
    MANUFACTURER         VARCHAR(10),                            /* Manufacturer Free Text */
    LOT_NUM              VARCHAR(12),                            /* Lot Number */
    UNIT                 VARCHAR(15),                            /* Free Text */
    REF_NUM              VARCHAR(11),                            /* Reference Number */
    DCOMMENT             VARCHAR(34),                            /* Free Text Comment */
    SYS_DATE             DATETIME,                               /* Date of Record Entry */
    SYS_TIME             DATETIME,                               /* Time of Record Entry */
    SYS_USR_ID           INTEGER,                                /* User who Entered Record */

    CONSTRAINT PK_WHI PRIMARY KEY (ID)
);


/*
@Table           Warehouse Cage Outgoing
@Usage           Tracks Shipments of Drugs to be Destroyed or Sent Back to the Manufacturer
@Category        Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        WHI_ID,SEQ_NUM
*/

CREATE TABLE dbo.WHO
(
    WHI_ID               INTEGER NOT NULL,                       /* WHI Internal ID */
    REF_NUM              VARCHAR(11) NOT NULL,                   /* Reference # to Group Sequence Numbers together */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequential Number within Reference Number */
    QTY                  INTEGER NOT NULL,                       /* Quantity of Drug being dealt with */
    TRAN_TYPE            CHAR(1),                                /* (D)estroy,(C)redit,(V)oid */
    SYS_USR_ID           INTEGER,                                /* User who entered the Record in CIPS */
    SYS_DATE             DATETIME,                               /* Date the Record was entered in CIPS */
    DISPOSE_USR_ID       INTEGER,                                /* User who Destroyed the Drugs */
    WITNESS_USR_ID       INTEGER,                                /* User who Witnessed the Drugs Destroyed */
    DISPOSE_DATE         DATETIME,                               /* Date the Drugs were Destroyed */
    POST_USR_ID          INTEGER,                                /* User who Entered (who Destroyed the Drugs) and (the Witness) */
    POST_DATE            DATETIME,                               /* Date Posted */
    DCOMMENT             VARCHAR(34),                            /* Free Text Comment */

    CONSTRAINT PK_WHO PRIMARY KEY (WHI_ID,SEQ_NUM)
);


/*
@Table           Warehouse Return
@Usage           Tracks Returns from Pharmacies
@Category        Warehouse,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.WHR
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    PHR_ID               INTEGER NOT NULL,                       /* PHR Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* DRG Internal ID */
    QTY                  INTEGER NOT NULL,                       /* Quantity */
    COST                 DECIMAL(10,4) NOT NULL,                 /* Cost of the Drugs being Returned */
    RETURN_DATE          DATETIME NOT NULL,                      /* Date Returned */
    REA_ID               VARCHAR(8),                             /* Reason for Return (REA Internal ID) */
    TRC_ID               VARCHAR(4),                             /* TRC ID */
    REF_NUM              VARCHAR(11),                            /* Reference Number */
    DCOMMENT             VARCHAR(34),                            /* Free Text Comment */

    CONSTRAINT PK_WHR PRIMARY KEY (ID)
);


/*
@Table           Warehouse Inventory Count
@Usage           Tracks Inventories for the Warehouse
@Category        Warehouse,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        ID
*/

CREATE TABLE dbo.WIC
(
    ID                   INTEGER NOT NULL,                       /* Internal ID */
    START_DATE           DATETIME,                               /* Date of Start of Inventory */
    REVIEW_DATE          DATETIME,                               /* Date of Review */
    STATUS               CHAR(1),                                /* (O)pen,(C)losed,(I)n use,(V)oided */
    REF_NUM              VARCHAR(30),                            /* Batch Number from other System */
    DTEXT                VARCHAR(60),                            /* Batch Description */

    CONSTRAINT PK_WIC PRIMARY KEY (ID)
);


/*
@Table           Warehouse Inventory Count Item
@Usage           Tracks Inventories for the Warehouse
@Category        Warehouse,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        WIC_ID,DRG_ID,SEQ_NUM
*/

CREATE TABLE dbo.WIC_ITM
(
    WIC_ID               INTEGER NOT NULL,                       /* WIC Internal ID */
    DRG_ID               INTEGER NOT NULL,                       /* Drug Internal ID */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number */
    AINVENTORY_DATE      DATETIME,                               /* Date of Start of Inventory */
    ACHANGE_QTY          DECIMAL(10,4),                          /* Initial Quantity to Change */
    ATRC_ID              VARCHAR(4),                             /* Transaction Code to Add or Subtract */
    ADTEXT               VARCHAR(30),                            /* Free Text Comment for Reason of Change */
    BINVENTORY_DATE      DATETIME,                               /* Date of Start of 2nd Count */
    BCHANGE_QTY          DECIMAL(10,4),                          /* Verification of Quantity to Change */
    BTRC_ID              VARCHAR(4),                             /* Transaction Code to Add or Subtract */
    BDTEXT               VARCHAR(30),                            /* Free Text Comment for Reason of Change */
    ACQ_COST             DECIMAL(10,4),                          /* Acquisition Cost of the Change in Qty */
    QTY_ONHAND_SNAPSHOT  DECIMAL(10,4),                          /* Snap Shot of Quantity Onhand after 1st Inventory */

    CONSTRAINT PK_WIC_ITM PRIMARY KEY (WIC_ID,DRG_ID,SEQ_NUM)
);


/*
@Table           Warning Message
@Usage           Stores Medispan Warning Messages in Various Languages
@Category        Medispan
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        MEDI_CODE,LANG_CODE,SEQ_NUM
*/

CREATE TABLE dbo.WMS
(
    MEDI_CODE            VARCHAR(6) NOT NULL,                    /* Medispan MEDI Code */
    LANG_CODE            VARCHAR(2) NOT NULL,                    /* Language Code */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number of Text for Multiple Records per MEDI Code */
    CHANGED_ON           DATETIME,                               /* Date of Last Change */
    DTEXT                VARCHAR(100),                           /* Text of Warning Label Message */

    CONSTRAINT PK_WMS PRIMARY KEY (MEDI_CODE,LANG_CODE,SEQ_NUM)
);


/*
@Table           Warehouse Purchase Order
@Usage           Stores Purchase Orders for the Warehouse
@Category        Warehouse,Purchase Order
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PO_NUM
*/

CREATE TABLE dbo.WPO
(
    PO_NUM               VARCHAR(12) NOT NULL,                   /* Purchase Order Number */
    PO_DATE              DATETIME,                               /* Purchase Order Date */
    VEN_ID               INTEGER,                                /* VEN Internal ID */
    POC_CODE             VARCHAR(4),                             /* Purchase Order Category Code */
    STATUS               CHAR(1),                                /* Status of Purchase Order */
    COMPLETED_DATE       DATETIME,                               /* Date Purchase Order was Closed */
    COMPLETED_USR_ID     INTEGER,                                /* User who Completed Purchase Order */

    CONSTRAINT PK_WPO PRIMARY KEY (PO_NUM)
);


/*
@Table           Warehouse Purchase Order Item
@Usage           Stores Purchase Order Items for the Warehouse
@Category        Warehouse,Purchase Order
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        PO_NUM,SEQ_NUM
*/

CREATE TABLE dbo.WPO_ITM
(
    PO_NUM               VARCHAR(12) NOT NULL,                   /* Purchase Order Number */
    SEQ_NUM              INTEGER NOT NULL,                       /* Sequence Number */
    DRG_ID               INTEGER NOT NULL,                       /* DRG Internal ID */
    REQ_ID               INTEGER,                                /* REQ Internal ID */
    MAN_ID               INTEGER,                                /* MAN Internal ID */
    QTY_ORDERED          INTEGER NOT NULL,                       /* Quantity Ordered */
    QTY_RECEIVED         INTEGER,                                /* Quantity Received */
    PQ_UNIT_COST         DECIMAL(10,4),                          /* Purchase Quantity Unit Cost */
    PUR_AMOUNT           INTEGER,                                /* Purchase Amount */
    CONTRACT_CODE        VARCHAR(20),                            /* Contract Code */

    CONSTRAINT PK_WPO_ITM PRIMARY KEY (PO_NUM,SEQ_NUM)
);


/*
@Table           Warehouse Shelf Location
@Usage           Stores Warehouse Item Shelf Locations
@Category        Warehouse,Inventory
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        CODE
*/

CREATE TABLE dbo.WSL
(
    CODE                 VARCHAR(20) NOT NULL,                   /* Unique Code */
    DTEXT                VARCHAR(50),                            /* Descriptive Text */

    CONSTRAINT PK_WSL PRIMARY KEY (CODE)
);


/*
@Table           Warning Cross Reference
@Usage           Used to find Label Codes for Architect Laser Jet SIMMS, Intercom DLL
@Category        Warehouse
@Related         0
@LOG_ENABLE      TRUE
@LOG_TEXT        MEDI_CODE,LANG_CODE,SOURCE_CODE
*/

CREATE TABLE dbo.WXR
(
    MEDI_CODE            VARCHAR(6) NOT NULL,                    /* Unique Code */
    LANG_CODE            VARCHAR(2) NOT NULL,                    /* Descriptive Text */
    SOURCE_CODE          VARCHAR(3) NOT NULL,                    /* Descriptive Text */
    LABEL_CODE           VARCHAR(6),                             /* Descriptive Text */
    GRAPH_CODE           VARCHAR(6),                             /* Descriptive Text */
    CHANGED_ON           DATETIME,                               /* Descriptive Text */

    CONSTRAINT PK_WXR PRIMARY KEY (MEDI_CODE,LANG_CODE,SOURCE_CODE)
);


