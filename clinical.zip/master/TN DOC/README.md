Data Dictionary Export
----------------------
Account for Removed Columns
Export CIPS List Values
Use for Website


QS1 Table Name
--------------
* QS1.dbo.DATA
* 40K Rows
* Insert Time


Other SQL
---------
* Export Previous Data Before 
* Add Extended Database Properties
* Add Column Defaults
* Update from Custom Table Settings
* Bulk Insert Medispan Import

CIPS Tables
-----------
* Pharmacy (1)
* Registry (??)
* Medispan Tables (???)
* Facilty (Row Count)
* Fills (???)
* Rx (???)
* Drug (???)
* Doctor (???)
* Patient (???)
* Patient Insurance (???)
* Insurance (???)
* Insurance Group (???) 
* Users (Pharmacy and Tech)
* Med Passes For Each Facility (????)
* Schedules By Facility (???)
* Abbreviations (???)
* Drug Abbreviations (???)
* Drug Acquistion Cost Records (???)

Dump Data From CIPS Previous to Data folder and Check In
---------------------------------------------------------
* Medispan Bulk Insert Data 
* Pharmacy (1)
* Registry (??)
* Facilty (Row Count)
* Regions and Queues (Export DCODES)
* Custom Table Settings (Used to Setup Facilities)

Bulk Insert
--------------
* MSDN [https://msdn.microsoft.com/en-us/library/ms188365.aspx] 
* C:\\QS12CIPS\\DATA\\QS1.TXT

CIPS Requested Columns
-----------------------

* Doctor Last Name (Doctor Primary Key)
* Doctor First Name (Doctor Primary Key)
* Doctor DEA Number (Doctor Primary Key)
* Drug NDC Number (Drug Primary Key)
* Drug Name (Drug Primary Key)
* Patient Number (Patient Primary Key) (Patient Insurance Primary Key)
* Patient Last Name (Patient Primary Key) (Patient Insurance Primary Key)
* Patient First Name (Patient Primary Key) (Patient Insurance Primary Key)
* Patient Birthdate (Patient Primary Key) (Patient Insurance Primary Key)
* Patient Allergies Comma Separated
* Rx Number (Fill Primary Key) (Rx Primary Key)
* Rx Controlled Substance Number
* Rx Date Written
* Rx Expiration Date
* Rx DC Date
* Rx Directions
* Rx Refill Quantity
* Rx Refills Left
* Fill Date (Fill Primary Key)
* Fill Price
* Fill Refill Number (Fill Primary Key)
* Fill Quantity Dispensed
* Fill Delivery Location
* Fill Pharmacist Last Name
* Fill Pharmacist First Name
* Fill Tech Last Name
* Fill Tech First Name
* Fill Document Number
* Insurance BIN   (Insurance Primary Key) (Patient Insurance Primary Key)
* Insurance PCN   (Insurance Primary Key) (Patient Insurance Primary Key)
* Insurance Paid Amount
* Insurance Copay Amount
* Insurance CardHolder ID (Patient Insurance Primary Key)
* Insurance Group Number (Patient Insurance Primary Key)

Clinical Solutions Additional Requested Columns
-----------------------------------------------
* Formulary Flag
* Brand Name
* Generic Name
* Generic Available
* Drug DEA Class
* GPI Number
* Purchase Quantity
* Facility Code
* Booking Number

Missing Columns
---------------
* Facility Name (Fill Delivery Location)
* Account (Charge Code and Region)
* Primary Region


QS1 Columns
--------------

* [First Name(35)] - Patient First Name - Not Used
* [Last Name(25)] - Patient Last Name - Not Used
* [Last Name(35)] - Patient Last Name - Not Used
* [Doctor Name(25)] - Not Used
* [Doctor Name(50)] - Not Used
* [Doctor Alias] - Short Name ?
* [Doctor DEA Nbr] - DOC.DEA
* [Doctor Code] - Short Name (SNAME)
* [Doctor NPI#] - DOC.NPI
* [Doctor DEA Suffix] - DOC.DEA_SUFFIX
* [NDC Nbr] - FIL.NDC, DRG.NDC
* [Drug Name 30] - DRG.DNAME
* [Drug Name 27]
* [Patient ID]
* [Patient Code]
* [Patient Last Name] - PAT.LNAME
* [Patient First Nme] - PAT.FNAME
* [Birthdate x/x/x] - Not USed
* [Patient Birthdate] - PAT.DOB - Not Required
* [Soc Sec#] - PAT.SSN
* [Allergy Not Found] 
* [No Knwn Allergies]
* [Rx Number] - RXF.RX_NUMBER
* [Class2 Number] - RXF.????
* [Rx# Original Date] - RXF.ORG_DATE
* [Rx Stop Date] - RXF.EXP_DATE
* [Rx Sig Code] - RXF.SIG  (Sometimes Constains RX1203911????)
* [RX Drug Class] - 
* [Date Entered] - FIL.SYS_DATE
* [Date Written] - RXF.ORD_DATE
* [Time.Of.Fill] - FIL.SYS_TIME
* [Start Date] - ??
* [Stop Date] - ??
* [Drug Name] - Not Used
* [Drug Exp. Date] - ??
* [Date Refill Due] - RFD.DATE_DUE
* [Qty Authorized]
* [Qty Dispensed] - FIL.QTY_DSP
* [Refills Rem] - RXF.REF_LEFT
* [Refill Auth. By] 
* [Refills Auth] - FILL_ALLOWED ( Add 1 )
* [Entered-Phar Code] - FIL.SYS_USR_ID
* [Phar ErrorRes]
* [Pharm Last Updt]
* [Entered-Tech Code] - FIL.TECH_USR_ID
* [Tech ErrorRes]
* [Tech Last Updt]
* [Time Entered]
* [Time Verified] - FIL.PV_SYS_TIME
* [Total Qty Remain] - RXF.QTY_DUE
* [Address] - PAT.ADDRESS1
* [Address 2] - PAT.ADDRESS2
* [City] - PAT.CITY
* [State] - PAT.STATE
* [Zip Code] - PAT.ZIP
* [Insurance Company] - THP.ID
* [Carr #]
* [Carrier Id]
* [Client Id#] - FAC.DCODE
* [Employer Code]
* [Cardholder Code]
* [Employer ID]
* [Ins Group#] THP_GRP.GRP_NUMBER
* [Ins Policy#]
* [Plan Id]
* [Carr #]
* [Ins Pat Code] 
* [Ins Effctv Dte]
* [Ins Exp Dte]
* [Ins Med/Lmt]
* [Ins Med/Rem]
* [Copay Tab]
* [Family Benefit $$]
* [Family Claim $$]
* [Family Total RXS]
* [Home Plan]
* [Ins Benefit$]
* [Ins Claim$]
* [Rel Cardhldr]
* [Fill List]
* [Patient Group]
* [Patient Location]
* [Patient Room]
* [Sig Line 1]
* [Sig Line 2]
* [Sig Line 3]
* [Sig Line 4]
* [Sig Line 5]
* [Sig Line 6]
* [Sig Line 7]
* [Sig Line 8]
* [Sig Qty / Day]
* [Sig Qty / Dose]
* [Allg Code 01]
* [Allg Code 02]
* [Allg Code 03]
* [Allg Code 04]
* [Allg Code 05]
* [Allg Desc 01]
* [Allg Desc 02]
* [Allg Desc 03]
* [Allg Desc 04]
* [Allg Desc 05]
