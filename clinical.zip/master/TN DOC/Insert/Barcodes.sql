use Import

go

drop table Barcodes

go

CREATE TABLE Barcodes
(
	[DG-NDC Nbr] varchar(50),
	[DG-Drug Name 27] varchar(50),
	[DG-Drug Name 30] varchar(50),
	[DG-Drug GTIN] varchar(50)
);


BULK INSERT Barcodes
   FROM 'C:\AspenGrove\Data\Barcodes.txt'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '","',  
         ROWTERMINATOR = '\n'  
      );
