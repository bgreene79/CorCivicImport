use Import

go

drop table Users

go

CREATE TABLE Users
(
	[First Name] VARCHAR(200),
	[Last Name] VARCHAR(200),
	[QS1 USER CODES] VARCHAR(200),
	[System Generated] VARCHAR(200),
	[CIPS LOGIN] VARCHAR(200)
);


BULK INSERT Users
   FROM 'C:\AspenGrove\Data\Users.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
