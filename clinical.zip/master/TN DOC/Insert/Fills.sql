USE Import
GO
DROP TABLE Fill
GO

CREATE TABLE Fill
(
	[TX-Rx Number] varchar(50),
	[TX-Date Filled] DateTime,
	[TX-Quantity Disp] varchar(50),
	[RX-Time.Of.Fill] VARCHAR(50),
	[DG-NDC Nbr] VARCHAR(50),
	[TX-Entered-Phar] VARCHAR(50),
	[TX-Entered-Tech] VARCHAR(50),
	[TX-Patient Location] VARCHAR(50),
	[Price] varchar(20),
	[Price2] varchar(20),
	[facility] varchar(100),
	[charge] varchar(100)
)

BULK INSERT Fill
   FROM 'C:\AspenGrove\Data\Fills.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );


--update fill set [tx-rx number] = replace([TX-Rx Number], '"', '')

alter table fill alter column [tx-rx number] int

CREATE NONCLUSTERED INDEX [NonClusteredIndex-20161001-120111] ON [dbo].[Fill]
(
	[TX-Rx Number] ASC,
	[TX-Date Filled] ASC
)

go

alter table fill add ident int identity(1,1)
alter table fill add id int 

go

With data As
(
       SELECT
	   	[TX-Rx Number], [TX-Date Filled], ident,
       ROW_NUMBER() OVER (ORDER BY [TX-Rx Number], [TX-Date Filled], ident) as ID
       FROM FILL
)
UPDATE FILL SET fill.ID = data.ID
FROM FILL
INNER JOIN Data ON fill.[TX-Rx Number] = data.[TX-Rx Number] and fill.[TX-Date Filled] = data.[TX-Date Filled] and fill.ident = data.ident



