use QS1
drop table FAcility
CREATE TABLE Facility
(
[Facility Name] VARCHAR(100),
[Code] VARCHAR(50),
[Provider] VARCHAR(50),
[SHP ID] VARCHAR(50),
[Pckg Type] VARCHAR(50),
[Cut off Time] VARCHAR(50),
[Shipping Address] VARCHAR(50),
[City/state/zip] VARCHAR(50),
[State] VARCHAR(50),
[Phone ] VARCHAR(50),
[Fax] VARCHAR(50),
[State DEA] VARCHAR(50),
[Expiration] VARCHAR(50),
[Fed DEA] VARCHAR(50),
[Expiration2] varchar(50)
);


BULK INSERT Facility
   FROM 'C:\QS12CIPS\Data\Facility.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
