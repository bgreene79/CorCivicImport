use Import

go

drop table DoctorState

go

CREATE TABLE DoctorState
(
	[DR-Doctor Name(25)] varchar(50),
	[DR-Doctor Name(50)] varchar(50),
	[DR-First Name(25)] varchar(50),
	[DR-Last Name(25)] varchar(50),
	[DR-Last Name(35)] varchar(50),
	[DR-Last Name(40)] varchar(50),
	[DR-State Lic #] varchar(50),
	[DR-State] varchar(50),
	[DR-State Lic Type] varchar(50)
);


BULK INSERT DoctorState
   FROM 'C:\AspenGrove\Data\DoctorState.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '","',  
         ROWTERMINATOR = '\n'  
      );
