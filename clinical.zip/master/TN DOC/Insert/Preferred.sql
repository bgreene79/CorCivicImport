use Import
go

drop table Preferred
go

CREATE TABLE Preferred
(
	[DG-Drug Name 27] VARCHAR(50),
	[DG-Drug Type] VARCHAR(20),
	[DG-NDC Nbr] VARCHAR(20),
	[DL-Delete Flag] VARCHAR(20)
);


BULK INSERT Preferred
   FROM 'C:\AspenGrove\Data\Preferred.txt'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
	
update Preferred set [DL-Delete Flag] = replace([DL-Delete Flag], '"', '')