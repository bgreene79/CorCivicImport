USE QS1
GO
DROP TABLE Times
GO

CREATE TABLE Times
(
[HOA Code] VARCHAR(50),
[HOA Group] VARCHAR(50),
[HOA Wing] VARCHAR(50),
[Freqncy (Tms/Day)] VARCHAR(50),
[Time 1] VARCHAR(50),
[Time 2] VARCHAR(50),
[Time 3] VARCHAR(50),
[Time 4] VARCHAR(50),
[Time 5] VARCHAR(50)
)

BULK INSERT Times  
   FROM 'C:\fills\Data\Times.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
