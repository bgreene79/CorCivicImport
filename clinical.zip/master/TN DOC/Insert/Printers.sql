use Import
go

drop table Printers
go


CREATE TABLE Printers
(
[label_name] VARCHAR(200),
[Trade Name (substitue for)] VARCHAR(200),
[strength] VARCHAR(200),
[dos_id] VARCHAR(200),
[ndc] VARCHAR(200),
[gpi] VARCHAR(200),
[pur_qty] VARCHAR(200),
[Location] VARCHAR(200),
[Printer Number] VARCHAR(200)
);


BULK INSERT Printers
   FROM 'C:\AspenGrove\Data\Printers.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
