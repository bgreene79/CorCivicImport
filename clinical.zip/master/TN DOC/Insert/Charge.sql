use Import
go

drop table Charge
go

CREATE TABLE Charge
(
	[FACILITIY CHARGED] VARCHAR(200),
	[PRICE CODE] VARCHAR(200),
	[Payor] VARCHAR(200),
	[Code] VARCHAR(200),
	[Code 2] VARCHAR(200),
	[Group Code] VARCHAR(200),
	[Charge Code] VARCHAR(200),
	[Description] VARCHAR(200),
	[Price Table] VARCHAR(200),
	[Comments] VARCHAR(200),
);


BULK INSERT Charge
   FROM 'C:\AspenGrove\Data\Charge.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
