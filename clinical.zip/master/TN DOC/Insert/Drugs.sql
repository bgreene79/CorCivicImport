use Import
go

drop table Drugs
go

CREATE TABLE Drugs
(
[label_name] VARCHAR(200),
[dname] VARCHAR(200),
[DUR Formulary] VARCHAR(200),
[generic_Flag] VARCHAR(200),
[Trade Name (substitue for)] VARCHAR(200),
[strength] VARCHAR(200),
[dos_id] VARCHAR(200),
[NEVER GOES TO TCG] VARCHAR(200),
[ndc] VARCHAR(200),
[dea] VARCHAR(200),
[gpi] VARCHAR(200),
[pur_qty] VARCHAR(200),
[awp_Cost] VARCHAR(200),
[man_abbrev] VARCHAR(200),
[manufacturer] VARCHAR(200),
[Location] VARCHAR(200),
[Printer Number] VARCHAR(200),
[Pre-Pack] VARCHAR(200),
[Pre-Pack QTY 30] VARCHAR(200),
[Pre-Pack QTY 28] VARCHAR(200),
[Pre-Pack QTY  20] VARCHAR(200),
[Pre-Pack QTY  14] VARCHAR(200),
[Pre-Pack QTY 10] VARCHAR(200)
);


BULK INSERT Drugs
   FROM 'C:\AspenGrove\Data\Drugs.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
