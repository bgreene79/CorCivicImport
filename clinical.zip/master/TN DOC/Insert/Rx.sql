USE Import
GO
DROP TABLE Rx
GO

CREATE TABLE Rx
(
[First Name(35)] VARCHAR(50),
[Last Name(25)] VARCHAR(50),
[Last Name(35)] VARCHAR(50),
[Doctor Name(25)] VARCHAR(50),
[Doctor Name(50)] VARCHAR(50),
[Doctor Alias] VARCHAR(50),
[Doctor DEA Nbr] VARCHAR(50),
[Doctor Code] VARCHAR(50),
[Doctor NPI#] VARCHAR(50),
[Doctor DEA Suffix] VARCHAR(50),
[NDC Nbr] VARCHAR(50),
[Drug Name 30] VARCHAR(50),
[Drug Name 27] VARCHAR(50),
[Patient ID] VARCHAR(50),
[Patient Code] VARCHAR(50),
[Patient Last Name] VARCHAR(50),
[Patient First Nme] VARCHAR(50),
[Birthdate x/x/x] VARCHAR(50),
[Patient Birthdate] VARCHAR(50),
[Soc Sec#] VARCHAR(50),
[Allergy Not Found] VARCHAR(50),
[No Knwn Allergies] VARCHAR(50),
[Rx Number] VARCHAR(50),
[Rx Number2] VARCHAR(50),
[Class2 Number] VARCHAR(50),
[Rx# Original Date] VARCHAR(50),
[Rx Stop Date] VARCHAR(50),
[Rx Stop Date2] VARCHAR(50),
[Rx Sig Code] VARCHAR(500),
[RX Drug Class] VARCHAR(50),
[Date Entered] VARCHAR(50),
[Date Written] VARCHAR(50),
[Time.Of.Fill] VARCHAR(50),
[Start Date] VARCHAR(50),
[Stop Date] VARCHAR(50),
[Drug Name] VARCHAR(50),
[Drug Exp. Date] VARCHAR(50),
[Date Refill Due] VARCHAR(50),
[Qty Authorized] VARCHAR(50),
[Qty Dispensed] VARCHAR(50),
[Refills Rem] VARCHAR(50),
[Refill Auth. By] VARCHAR(50),
[Refills Auth] VARCHAR(50),
[Entered-Phar Code] VARCHAR(50),
[Phar ErrorRes] VARCHAR(50),
[Pharm Last Updt] VARCHAR(50),
[Entered-Tech Code] VARCHAR(50),
[Tech ErrorRes] VARCHAR(50),
[Tech Last Updt] VARCHAR(50),
[Time Entered] VARCHAR(50),
[Time Verified] VARCHAR(50),
[Total Qty Remain] VARCHAR(50),
[Address] VARCHAR(50),
[Address 2] VARCHAR(50),
[City] VARCHAR(50),
[State] VARCHAR(50),
[Zip Code] VARCHAR(50),
[Insurance Company] VARCHAR(50),
[Carr #] VARCHAR(50),
[Carrier Id] VARCHAR(50),
[Client Id#] VARCHAR(50),
[Employer Code] VARCHAR(50),
[Cardholder Code] VARCHAR(50),
[Employer ID] VARCHAR(50),
[Ins Group#] VARCHAR(50),
[Ins Policy#] VARCHAR(50),
[Plan Id] VARCHAR(50),
[Carr #2] VARCHAR(50),
[Ins Pat Code] VARCHAR(50),
[Ins Effctv Dte] VARCHAR(50),
[Ins Exp Dte] VARCHAR(50),
[Ins Med/Lmt] VARCHAR(50),
[Ins Med/Rem] VARCHAR(50),
[Copay Tab] VARCHAR(50),
[Family Benefit $$] VARCHAR(50),
[Family Claim $$] VARCHAR(50),
[Family Total RXS] VARCHAR(50),
[Home Plan] VARCHAR(50),
[Ins Benefit$] VARCHAR(50),
[Ins Claim$] VARCHAR(50),
[Rel Cardhldr] VARCHAR(50),
[Fill List] VARCHAR(50),
[Patient Group] VARCHAR(50),
[Patient Location] VARCHAR(50),
[Patient Room] VARCHAR(50),
[Sig Line 1] VARCHAR(50),
[Sig Line 2] VARCHAR(50),
[Sig Line 3] VARCHAR(50),
[Sig Line 4] VARCHAR(50),
[Sig Line 5] VARCHAR(50),
[Sig Line 6] VARCHAR(50),
[Sig Line 7] VARCHAR(50),
[Sig Line 8] VARCHAR(50),
[Sig Qty / Day] VARCHAR(50),
[Sig Qty / Dose] VARCHAR(50),
[Allg Code 01] VARCHAR(50),
[Allg Code 02] VARCHAR(50),
[Allg Code 03] VARCHAR(50),
[Allg Code 04] VARCHAR(50),
[Allg Code 05] VARCHAR(50),
[Allg Desc 01] VARCHAR(50),
[Allg Desc 02] VARCHAR(50),
[Allg Desc 03] VARCHAR(50),
[Allg Desc 04] VARCHAR(50),
[Allg Desc 05] VARCHAR(50),
[HOA Code] VARCHAR(50),
[HOA for Sig 2]	VARCHAR(50),
[HOA for Sig 3]	VARCHAR(50),
[HOA for Sig 4]	VARCHAR(50),
[HOA for Sig 5]	VARCHAR(50),
[DC_CODE] VARCHAR(50),
[DREL] VARCHAR(50),
[BOOKING_NUMBER] VARCHAR(100)
)

BULK INSERT Rx  
   FROM 'C:\AspenGrove\Data\Rx.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '","',  
         ROWTERMINATOR = '"\n'  
      );

go

update rx set [First Name(35)] = substring( [First Name(35)] , 2, len([First Name(35)] ) - 1)
alter table rx add ID int

go

With data As
(
       SELECT [RX NUMBER],
       ROW_NUMBER() OVER (ORDER BY [RX NUMBER]) as ID
       FROM RX
)
UPDATE RX SET ID = data.[Rx Number]
FROM RX
INNER JOIN Data ON RX.[RX NUMBER] = Data.[RX NUMBER]


CREATE CLUSTERED INDEX [ClusteredIndex-20161001-120147] ON [dbo].[Rx]
(
	[Rx Number] ASC
)