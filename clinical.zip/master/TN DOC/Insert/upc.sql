use Import
go

drop table UPC
go

CREATE TABLE UPC
(
[Description] varchar(100),
[Item#]varchar(100),
[NDC#]varchar(100),
[UPC#] varchar(100)
);


BULK INSERT UPC
   FROM 'C:\AspenGrove\Data\UPC.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
