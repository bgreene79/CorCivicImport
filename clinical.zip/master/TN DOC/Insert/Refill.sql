use Import
go

drop table Refill
go

CREATE TABLE Refill
(
	NAME VARCHAR(50),
	Code VARCHAR(50),
	[GROUP]  VARCHAR(50),	
	DOW	 VARCHAR(50),
	StartDAte  VARCHAR(50),
	EndDate  VARCHAR(50)
);


BULK INSERT Refill
   FROM 'C:\AspenGrove\Data\Refill.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );

UPDATE FAC SET CYCLE_START_DATE = (SELECT StartDate FROM IMPORT.dbo.Refill where Code = DCODE)
UPDATE FAC SET CYCLE_TYPE = 'C' where CYCLE_START_DATE IS NOT NULL
UPDATE FAC set CYCLE_START_DATE = CYCLE_START_DATE + (( Convert(int,GETDATE()) - Convert(int, CYCLE_START_DATE) ) / 14) * 14

select cycle_start_date From fac where cycle_start_date is not null