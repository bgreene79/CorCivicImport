use Import
go

drop table ChargeCode
go

CREATE TABLE ChargeCode
(
	[FACILITIY CHARGED] VARCHAR(200),
	[Charge] VARCHAR(200),
	[Price] VARCHAR(200),
	[Group Code] VARCHAR(200),
	[Price Table] VARCHAR(200),
	[Comments] VARCHAR(200)
);


BULK INSERT ChargeCode
   FROM 'C:\AspenGrove\Data\ChargeCode.TXT'  
   WITH   
      (  
         FIRSTROW = 2,
         FIELDTERMINATOR = '\t',  
         ROWTERMINATOR = '\n'  
      );
