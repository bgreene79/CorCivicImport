select distinct rx.[Ins Group#] from import.dbo.rx
