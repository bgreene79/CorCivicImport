update fac set cycle_start_date = '08/14/2016' where CYCLE_start_Date = '1900-02-12 00:00:00.000'
update fac set cycle_start_date = '08/21/2016' where CYCLE_start_Date = '1900-01-29 00:00:00.000'
update fac set cycle_start_date = '08/24/2016' where dcode in ('PISC', 'MAKY', 'OCDC')