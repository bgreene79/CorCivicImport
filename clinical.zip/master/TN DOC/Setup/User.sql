INSERT INTO 
cips_setup.dbo.usr 
select
ROW_NUMBER() over (order by [Last Name], [First Name]) + (SELECT MAX(ID) FROM CIPS_SETUP.dbo.USR),
[Last Name],
[First Name],
[CIPS LOGIN],
null,
'',
null,
1,
null,
null,
'A',
'T',
'A',
'F',
'F',
getdate(),
null,
null,
null,
null, 
null,
null,
[System Generated],
'N',
'N',
null,
null,
null
From Users
where [CIPS LOGIN] != 'MBROWN'

