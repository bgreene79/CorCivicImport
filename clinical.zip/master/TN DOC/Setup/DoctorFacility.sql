Insert into doc_fac
select 
ROW_NUMBER() OVER (ORDER BY DOC_Id, FAC_Id),
DOC_ID,
FAC_ID,
'F',
null,
'F',
null
from
(
select distinct doc.id as doc_id, fac.id as fac_id
from import.dbo.doctorstate
join doc on (doc.lname = [DR-last Name(25)] and doc.fname = [DR-First Name(25)])
join fac on (fac.dcode = doctorstate.[DR-State Lic #])
) AS DOC_FAC