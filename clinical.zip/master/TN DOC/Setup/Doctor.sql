USE Import

go

drop table Doctor

go


Select distinct 
Rx.[Doctor Name(50)]
Into Doctor
From Rx

EXEC sp_rename 'Doctor.[Doctor Name(50)]', 'NAME';  

ALTER TABLE Doctor add id int
go
update doctor set id = null

go

alter table doctor add lname varchar(200)
alter table doctor add fname varchar(200)

go

update doctor set lname = name
update doctor set lname = REPLACE( substring(name, 1, charindex(',', name, 1) - 1), '"', '')
update doctor set fname = REPLACE( substring(name, charindex(',', name, 1) + 2, len(name)), '"', '')

alter table doctor drop column id

select * from CIPS_SETUP.dbo.doc
LEFT OUTER join Doctor on (Doc.LNAME= doctor.lname and doc.fname = doctor.fname)

INSERT INTO CIPS_SETUP.dbo.DOC
(
[ADDRESS1],
[ADDRESS2],
[CERTIFICATE_TEXT],
[CITY],
[CNTRL_LIABILITY_FLAG],
[DEA],
[DEA_EXP],
[DGR_ID],
[DORMANT_FLAG],
[EMAIL],
[EXT1],
[EXT2],
[FAX],
[FNAME],
[GROUPING],
[ID],
[LNAME],
[MNAME],
[NPI],
[PHONE1],
[PHONE2],
[SNAME],
[ST],
[STATE_NUM],
[STATE_NUM_EXP],
[STOCK_LIABILITY_FLAG],
[SUFFIX],
[SUP_DOC_ID],
[TSK_DOC_ID],
[UPIN],
[ZIP]
)
SELECT
NULL, --ADDRESS1
NULL, --ADDRESS2
NULL, --CERTIFICATE_TEXT
NULL, --CITY
'F', --CNTRL_LIABILITY_FLAG
null, --DEA
Null, --DEA_EXP
NULL, --DGR_ID
'F', --DORMANT_FLAG
NULL, --EMAIL
NULL, --EXT1
NULL, --EXT2
NULL, --FAX
doctor.FNAME, --FNAME
NULL, --GROUPING
ROW_NUMBER() OVER(ORDER By doctor.LNAME, doctor.FNAME) + (SELECT MAX(ID) FROM CIPS_SETUP.dbo.doc), --ID
doctor.LNAME, --LNAME
NULL, --MNAME
Null, --NPI
NULL, --PHONE1
NULL, --PHONE2
NULL, --SNAME
' ', --ST
NULL, --STATE_NUM
NULL, --STATE_NUM_EXP
'F', --STOCK_LIABILITY_FLAG
NULL, --SUFFIX
NULL, --SUP_DOC_ID
NULL, --TSK_DOC_ID
NULL, --UPIN
NULL --ZIP
FROM doctor
LEFT OUTER join  CIPS_SETUP.dbo.doc on (Doc.LNAME= doctor.lname and doc.fname = doctor.fname)
WHERE DOC.id is null

