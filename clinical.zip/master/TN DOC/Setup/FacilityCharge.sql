use CIPS_SETUP

insert into FAC_CHG
(
[ACTION],
[BILL_NAM_ID],
[CARD_ID_MASK],
[CHG_ID],
[DEFAULT_TO_INS_FLAG],
[FAC_ID],
[GRP_NUMBER],
[ID],
[NUM_BILL_DAYS],
[PERSON_CODE],
[PROCESSOR],
[RELATION],
[REMIT_NAM_ID],
[RX_DAW],
[RX_ORIGIN],
[SEQ_NUM],
[THP_ID]
)
select
'3', --ACTION
NULL, --BILL_NAM_ID
NULL, --CARD_ID_MASK
CHG.ID, --CHG_ID
'F', --DEFAULT_TO_INS_FLAG
FAC.ID, --FAC_ID
NULL, --GRP_NUMBER
ROW_NUMBER() OVER(ORDER By FAC.ID, chg.id), --ID
NULL, --NUM_BILL_DAYS
NULL, --PERSON_CODE
NULL, --PROCESSOR
'~', --RELATION
NULL, --REMIT_NAM_ID
' ', --RX_DAW
' ', --RX_ORIGIN
NULL, --SEQ_NUM
NULL --THP_ID
from import.dbo.chargecode
join fac on dcode = [Group code]
join chg on chg.dname = [Charge]

insert into PGR
(
[DCODE],
[DTEXT],
[ID],
[PRC_ID]
)
select distinct
price,
price,
Row_number() over (order by Price) + 1,
5
from 
(select distinct [Price] from import.dbo.chargecode)  as PT


insert into FAC_PRC
(
[CHG_ID],
[FILTER1],
[FILTER2],
[ID],
[PGR_ID],
[PRC_ID],
[SEQ_NUM]
)
select distinct
CHG.ID, --CHG_ID
'C', --FILTER1
'N', --FILTER2
Row_number() over (order by Price) + 10,
PGR.ID, --PGR_ID
PRc.ID, --PRC_ID
Row_number() over (order by Price) + 10
from import.dbo.chargecode
join chg on chg.dname = [Charge]
join pgr on pgr.DCODE = [Price]
join prc on prc.dcode = [Price Table]

update fac set PGR_ID = (select id from pgr where dcode = (select top 1 price from import.dbo.chargecode where fac.dcode = [GRoup code]))

