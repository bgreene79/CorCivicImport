USE Import

update cips_setup.dbo.doc
set sname = [DR-State Lic #]
from CIPS_SETUP.dbo.doc
LEFT OUTER join DoctorState on (Doc.LNAME= [DR-last Name(35)] and doc.fname = [DR-First Name(25)])

