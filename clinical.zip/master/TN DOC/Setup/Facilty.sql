USE CIPS_SETUP

update fac set CHG_ID = (select chg.id from chg where chg.dcode = fac.dcode)

update fac set DName = substring(facility.[Facility Name], 1, 30)
from fac
join qs1.dbo.facility on dcode = code


update fac set ADDRESS1 = substring(facility.[Shipping Address], 1, 30)
from fac
join qs1.dbo.facility on dcode = code


update fac set city = REPLACE( substring( [City/state/zip], 1, charindex(',', [City/state/zip], 1) - 1), '"', '')
from fac
join qs1.dbo.facility on dcode = code
where [City/state/zip] like '%,%'


update fac set 
st = left(REPLACE( substring( [City/state/zip], charindex(',',  [City/state/zip], 1) + 2, len( [City/state/zip])), '"', ''), 2)
from fac
join qs1.dbo.facility on dcode = code


update fac set
zip = Right(REPLACE([City/state/zip], '"', ''), 5)
from fac
join qs1.dbo.facility on dcode = code

update fac set fac.Phone1 = left(ltrim(phone), 12)
from
fac
join qs1.dbo.facility on dcode = code

update fac set fac.FAX1 = left(ltrim(fax), 12)
from
fac
join qs1.dbo.facility on dcode = code


update fac set fac.DEA = left(ltrim([FED DEA]), 12)
from
fac
join qs1.dbo.facility on dcode = code

update fac set fac.DEA_LICENSE_EXP_DATE= left(ltrim([Expiration2]), 12)
from
fac
join qs1.dbo.facility on dcode = code

