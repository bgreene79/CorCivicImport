USE IMport

--delete from CIPS_SETUP.dbo.nhi

INSERT INTO CIPS_SETUP.dbo.nhi 
select
ROW_NUMBER() OVER (ORDER BY [allg desc 01]) + (SELECT MAX(id) FROM CIPS_SETUP.dbo.nhi),
Rx.[Allg Desc 01]
From Rx
where Rx.[Allg Desc 01] is not null and [Allg Desc 01] not in (select dtext from CIPS_SETUP.dbo.nhi)
group by Rx.[Allg Desc 01]


INSERT INTO CIPS_SETUP.dbo.nhi
select
ROW_NUMBER() OVER (ORDER BY [allg desc 02]) + (SELECT MAX(id) FROM CIPS_SETUP.dbo.nhi),
[Allg Desc 02]
From Rx
where Rx.[Allg Desc 02] is not null and [Allg Desc 02] not in (select dtext from CIPS_SETUP.dbo.nhi)
group by Rx.[Allg Desc 02]


INSERT INTO CIPS_SETUP.dbo.nhi
select
ROW_NUMBER() OVER (ORDER BY [allg desc 03]) + (SELECT MAX(id) FROM CIPS_SETUP.dbo.nhi),
[Allg Desc 03]
From Rx
where Rx.[Allg Desc 03] is not null and [Allg Desc 03] not in (select dtext from CIPS_SETUP.dbo.nhi)
group by Rx.[Allg Desc 03]


INSERT INTO CIPS_SETUP.dbo.nhi
select
ROW_NUMBER() OVER (ORDER BY [allg desc 04]) + (SELECT MAX(id) FROM CIPS_SETUP.dbo.nhi),
[Allg Desc 04]
From Rx
where Rx.[Allg Desc 04] is not null and [Allg Desc 04] not in (select dtext from CIPS_SETUP.dbo.nhi)
group by Rx.[Allg Desc 04]


INSERT INTO CIPS_SETUP.dbo.nhi
select
ROW_NUMBER() OVER (ORDER BY [allg desc 05]) + (SELECT MAX(id) FROM CIPS_SETUP.dbo.nhi),
[Allg Desc 05]
From Rx
where Rx.[Allg Desc 05] is not null and [Allg Desc 05] not in (select dtext from CIPS_SETUP.dbo.nhi)
group by Rx.[Allg Desc 05]

USE CIPS_SETUP

--select * from tsk

--delete from alc_trn

INSERT INTO ALC_TRN
(
	ID, TRANSLATE_FROM, DNAME, TSK_ID
)
SELECT ID, DTEXT, DTEXT, 5 from Nhi
where DTEXT not in (select translate_from from alc_trn)

update ALC_TRN set ALC_ID = (select ALC.ID from aLC where TRANSLATE_FROM = DTEXT)
update ALC_TRN set NHI_ID = (select NHI.ID from NHI where TRANSLATE_FROM = DTEXT) WHERE ALC_ID is null

update alc_trn set nhi_id = null where alc_id is not null
update alc_trn set nhi_id = null where par_id is not null
update alc_trn set nhi_id = null where med_id is not null
update alc_trn set alc_id = null where par_id is not null

