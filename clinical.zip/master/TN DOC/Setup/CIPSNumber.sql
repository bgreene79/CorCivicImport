use CIPS_SETUP

go

ALTER FUNCTION CIPSNumber
(
	@Param VARCHAR(20)
)
RETURNS decimal(10,4)
AS
BEGIN

    set @param = replace(@param, '"', '')
	set @param = replace(@param, ',', '')
	set @param = replace(@param, '$', '')
	set @param = (select @param where isnumeric(@param) = 1)
	set @param = (select @param where @param < 1000000.0000)
	set @param = (select @param where @param > -1000000.0000)
	
	RETURN @param;

END

go

alter FUNCTION CIPSInteger
(
	@Param VARCHAR(20)
)
RETURNS integer
AS
BEGIN

    set @param = replace(ltrim(replace(@Param, '0', ' ')), ' ', '0')
	
	RETURN @param;

END

go

ALTER FUNCTION CIPSDate
(
	@Param VARCHAR(20),
	@Default datetime
)
RETURNS datetime
AS
BEGIN

    set @param = (select @param where isdate(@param) = 1)
	set @param = convert(date, @param)
	set @param = isnull(@param, @default)

	RETURN @param

END





