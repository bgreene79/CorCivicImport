-- Estimated Time: 5 min.

update rxf set fil_id = null
delete from fil_bil
delete from fil_que
delete from lab
delete From fil
delete from trx
delete from rxs_itm
delete from rxs
delete from rxf

INSERT INTO PAT
(
ACCT_NUMBER,
ADDRESS1,
ADDRESS2,
ADMIT_DATE,
ADMIT_TIME,
AWAY,
BED,
BILL_FLAG,
BODY_SURF,
BOOK_NUMBER,
CHECK_MEDISPAN_FLAG,
CHG_ID,
CITY,
CLASS2_FLAG,
COMMENT1,
COMMENT2,
COMPLIANT_FLAG,
CONTROLLED_ALLOWED,
CREATIN,
DEFAULT_KOP,
DISPENSE_TYPE,
DISPLAY_FLAG,
DOB,
EARLIEST_RELEASE,
EMAIL,
FAC_FROM,
FAC_ID,
FNAME,
GENDER,
GROUPING,
HEIGHT_FT,
HEIGHT_IN,
HOSP_NUMBER,
ID,
LANG,
LEGAL_NAME,
LNAME,
LOCATION,
MNAME,
OMH_LEVEL,
ORIGIN,
PHONE,
PRINTED_DATE,
PRINTED_TIME,
PRINTED_USR_ID,
RACE,
REL_ID,
RELEASE_DATE,
RELEASE_TIME,
RESIDENCE,
ROOM,
SAFETYCAP_FLAG,
SLF_CRY_FLAG,
SPECIAL1,
SPECIAL2,
SS_NUMBER,
ST,
STATUS,
STOCK_FLAG,
SYS_DATE,
UNIT,
WEIGH_DATE,
WEIGHT,
WING,
ZIP
)
select
ACCT_NUMBER, --ACCT_NUMBER
NULL, --ADDRESS1
NULL, --ADDRESS2
NULL, --ADMIT_DATE
NULL, --ADMIT_TIME
'F', --AWAY
NULL, --BED
'T', --BILL_FLAG
NULL, --BODY_SURF
BOOKING_NUMBER, --BOOK_NUMBER
'T', --CHECK_MEDISPAN_FLAG
CHG.ID, --CHG_ID
NULL, --CITY
'T', --CLASS2_FLAG
NULL, --COMMENT1
NULL, --COMMENT2
'T', --COMPLIANT_FLAG
'T', --CONTROLLED_ALLOWED
NULL, --CREATIN
'P', --DEFAULT_KOP
'N', --DISPENSE_TYPE
'T', --DISPLAY_FLAG
[DOB], --DOB
NULL, --EARLIEST_RELEASE
NULL, --EMAIL
NULL, --FAC_FROM
FAC_ID, --FAC_ID
isnull(FNAME,''), --FNAME
'U', --GENDER
NULL, --GROUPING
NULL, --HEIGHT_FT
NULL, --HEIGHT_IN
NULL, --HOSP_NUMBER
QS1PAT.ID, --ID
'E', --LANG
NULL, --LEGAL_NAME
LNAME, --LNAME
NULL, --LOCATION
NULL, --MNAME
'0', --OMH_LEVEL
'NONE', --ORIGIN
NULL, --PHONE
NULL, --PRINTED_DATE
NULL, --PRINTED_TIME
NULL, --PRINTED_USR_ID
'U', --RACE
NULL, --REL_ID
NULL, --RELEASE_DATE
NULL, --RELEASE_TIME
'Z', --RESIDENCE
NULL, --ROOM
'F', --SAFETYCAP_FLAG
'T', --SLF_CRY_FLAG
NULL, --SPECIAL1
NULL, --SPECIAL2
NULL, --SS_NUMBER
' ', --ST
case drel when 'D' then 'R' else 'N' end, --STATUS
'F', --STOCK_FLAG
SYS_DATE, --SYS_DATE
NULL, --UNIT
NULL, --WEIGH_DATE
NULL, --WEIGHT
NULL, --WING
NULL --ZIP
FROM 
(
	SELECT
	ROW_NUMBER() OVER (ORDER BY [Patient Code]) + (SELECT MAX(pat.id) FROM PAT)as ID,
	dbo.cipsDate([Patient Birthdate], null) as DOB,
	[BOOKING_NUMBER],
	[Patient First Nme] as FNAME,
	[Patient Last Name] as LNAME,
	[Patient Code] as ACCT_NUMBER,
	convert(date, getdate()) as SYS_DATE,
	FAC.ID as FAC_ID,
	drel
	From Import.dbo.rx as pf
	Left outer JOIN FAC on (FAC.dcode = pf.[Patient Group])
	WHERE pf.ID IN (SELECT MAX(rx.ID) FROM Import.dbo.Rx GRoup by rx.[PAtient code])
) AS QS1PAT
join fac on (fac.id = fac_id)
left outer join chg on (fac.dcode = chg.dcode)
where not exists (select * from pat where pat.acct_number = qs1pat.acct_number)

go

Insert into pat_thp
(
[BILL_ORDER],
[BRAND_COPAY],
[BRAND_FEE],
[CARD_FNAME],
[CARD_LNAME],
[COVERAGE],
[CUS_LOC],
[DORMANT],
[EFF_DATE],
[ELIGIBLE],
[EXP_DATE],
[GENERIC_COPAY],
[GENERIC_FEE],
[GRP_NUMBER],
[HOME_PLAN],
[ID],
[ID_NUMBER],
[ID_NUMBERQ],
[OTHER_NUMBER],
[PAT_ID],
[PERSON_CODE],
[PROCESSOR],
[RELATION],
[THP_ID]
)
select
1, --BILL_ORDER
NULL, --BRAND_COPAY
NULL, --BRAND_FEE
NULL, --CARD_FNAME
NULL, --CARD_LNAME
'N', --COVERAGE
'N', --CUS_LOC
'F', --DORMANT
null, --EFF_DATE
'N', --ELIGIBLE
NULL, --EXP_DATE
NULL, --GENERIC_COPAY
NULL, --GENERIC_FEE
thp.GRP_NUMBER, --GRP_NUMBER
NULL, --HOME_PLAN
PAT.ID, --ID
cardholder_id, --ID_NUMBER
'N', --ID_NUMBERQ
NULL, --OTHER_NUMBER
PAT.ID, --PAT_ID
NULL, --PERSON_CODE
NULL, --PROCESSOR
'C', --RELATION
THP_ID --THP_ID
from
(
	select 
	distinct
	case substring(rx.[Ins Group#], 1, 4) when 'DIHS' then 'ICE' else 'FED' end as THP_ID,
	[Patient Code] as acct_number,
	[Ins Policy#] as cardholder_id
	from import.dbo.rx
	where [Ins Policy#] is not null
)
as PAT_THP
join pat on (pat_thp.acct_number = pat.acct_number)
join thp on (thp.id = thp_id)

go
INSERT INTO RXF
(
[ACT_REF_USED],
[DAW],
[DAYS_SUPPLY],
[DC_DATE],
[DC_FLAG],
[DC_REA_ID],
[DISCARD_DATE],
[DISTRIBUTION_FLAG],
[DLY_QTY],
[DOC_ID],
[DRG_ID],
[EPCS_FLAG],
[EXP_DATE],
[EXPAND_SIG_FLAG],
[EXPANDED_ALT_SIG],
[EXPANDED_SIG],
[FIL_ID],
[FILLS_ALLOWED],
[FIRST_ORG_DATE],
[ID],
[LAST_FIL],
[MAR_PRINT_FLAG],
[NEW_RXF_ID],
[NEW_RXF_ORD_ID],
[NEXT_FIL_TYPE],
[NFR_ID],
[NM9_ID],
[OLD_RXF_ID],
[ORD_DATE],
[ORDER_NUMBER],
[ORG_DATE],
[ORIGIN],
[PAT_ID],
[PHR_ID],
[PRN_FLAG],
[QTY_DOSE],
[QTY_DUE],
[QTY_RETURNED],
[QTY_USED],
[REF_DAYS_SUPPLY],
[REF_LEFT],
[REF_QTY],
[REF_USED],
[RELEASE_FLAG],
[REPLACE_QTY],
[ROA],
[RX_NUMBER],
[RXF_CON_ID],
[RXF_ORD_CODE],
[RXF_ORD_ID],
[RXF_ORD_ORDER_NUM],
[RXF_ORD_TYPE],
[SCH_ID],
[SCRIPTTYPE],
[SHORT_TERM_FLAG],
[SIG],
[SIG_PRN_FLAG],
[SPLIT_ID],
[ST_RX_SERIAL_NUM],
[STOCK_FLAG],
[SYS_DATE],
[SYS_TIME],
[SYS_USR_ID],
[TOT_QTY_DUE],
[UNEVEN_DOSE_FLAG],
[VC_RPH_SYS_DATE],
[VC_RPH_SYS_TIME],
[VC_RPH_USR_ID],
[VC_TECH_SYS_DATE],
[VC_TECH_SYS_TIME],
[VC_TECH_USR_ID]
)
select
null, --ACT_REF_USED
' ', --DAW
NULL, --DAYS_SUPPLY
null, --DC_DATE
CASE DC_CODE WHEN '#' THEN 'T' ELSE 'F' END, --DC_FLAG
CASE DC_CODE WHEN '#' THEN 'DC' ELSE NULL END, --DC_REA_ID
NULL, --DISCARD_DATE
'F', --DISTRIBUTION_FLAG
dbo.CIPSNumber([Sig Qty / Day]), --DLY_QTY
DOC.ID, --DOC_ID
DRG.ID, --DRG_ID
'F', --EPCS_FLAG
dbo.CIPSDate([Rx Stop Date], dbo.CIPSDate([Date Entered], getdate()) + 365), --EXP_DATE
'F', --EXPAND_SIG_FLAG
'', --EXPANDED_ALT_SIG
Rx.[Sig Line 1] + ' ' + isnull(Rx.[Sig Line 2], '') + ' '  + isnull(Rx.[Sig Line 3], '')+ ' ' +isnull(Rx.[Sig Line 4], '')+ ' ' + isnull(Rx.[Sig Line 5], ''), --EXPANDED_SIG
NULL, --FIL_ID
null, --FILLS_ALLOWED
null, --FIRST_ORG_DATE
dbo.CIPSInteger([Rx Number]),
dbo.CIPSDate(rx.[Date Entered], null), --LAST_FIL
'F', --MAR_PRINT_FLAG
NULL, --NEW_RXF_ID
NULL, --NEW_RXF_ORD_ID
case fac.KOP_PRIMARY when 'D' then case drg.default_kop when 'D' then pat.DEFAULT_KOP else drg.default_kop end else KOP_PRIMARY end, --NEXT_FIL_1TYPE
NULL, --NFR_ID
NULL, --NM9_ID
NULL, --OLD_RXF_ID
dbo.CIPSDate([Date Written], null), --ORD_DATE
NULL, --ORDER_NUMBER
dbo.CIPSDate([Rx# Original Date], null), --ORG_DATE
' ', --ORIGIN
PAT.ID, --PAT_ID
1, --PHR_ID
'F', --PRN_FLAG
dbo.CIPSNumber([Sig Qty / Dose]), --QTY_DOSE
dbo.CIPSNumber([Total Qty Remain]), --QTY_DUE
NULL, --QTY_RETURNED
NULL, --QTY_USED
NULL, --REF_DAYS_SUPPLY
dbo.CIPSNumber([Refills Rem]), --REF_LEFT
NULL, --REF_QTY
NULL, --REF_USED
'F', --RELEASE_FLAG
NULL, --REPLACE_QTY
'  ', --ROA
dbo.CIPSInteger([Rx Number]),
NULL, --RXF_CON_ID
NULL, --RXF_ORD_CODE
NULL, --RXF_ORD_ID
NULL, --RXF_ORD_ORDER_NUM
NULL, --RXF_ORD_TYPE
SCH.ID, --SCH_ID
'N', --SCRIPTTYPE
'F', --SHORT_TERM_FLAG
'', --SIG
'F', --SIG_PRN_FLAG
NULL, --SPLIT_ID
NULL, --ST_RX_SERIAL_NUM
'F', --STOCK_FLAG
dbo.CIPSDate(Rx.[Date Entered], getdate()), --SYS_DATE
dbo.CIPSDate([TIME.Of.Fill], '1899-12-30 00:00:00'), --SYS_TIME
1, --SYS_USR_ID
NULL, --TOT_QTY_DUE
'F', --UNEVEN_DOSE_FLAG
NULL, --VC_RPH_SYS_DATE
NULL, --VC_RPH_SYS_TIME
NULL, --VC_RPH_USR_ID
NULL, --VC_TECH_SYS_DATE
NULL, --VC_TECH_SYS_TIME
NULL --VC_TECH_USR_ID
From Import.dbo.Rx
JOIN PAT on (PAT.ACCT_NUMBER = Rx.[Patient Code])
LEFT OUTER JOIN Import.dbo.doctor on (Doctor.name = Rx.[Doctor Name(50)])
LEFT OUTER join DOC on( DOC.LNAME = Doctor.LNAME and Doc.fname = Doctor.fname)
LEFT OUTER join DRG on (DRG.ID = (select min(d2.id) from DRG AS d2 where d2.FORMATTED_NDC=Rx.[NDC Nbr]))
LEFT OUTER join SCH on ([HOA CODE] = SCH.DCODE)
LEFT OUTER JOIN FAC ON (pat.FAC_ID = Fac.id)
LEFT OUTER JOIN FAC_DRG ON (fac_Drg.fac_id = fac.id and fac_drg.drg_id = drg.id)

go

print 'SIG'

update rxf set dc_Date = exp_Date where DC_FLAG = 'T'

update rxf set EXPANDED_SIG = REPLACE(EXPANDED_SIG, '  ', ' ') where EXPANDED_SIG != REPLACE(EXPANDED_SIG, '  ', ' ')
update rxf set EXPANDED_SIG = REPLACE(EXPANDED_SIG, '  ', ' ') where EXPANDED_SIG != REPLACE(EXPANDED_SIG, '  ', ' ')
update rxf set EXPANDED_SIG = REPLACE(EXPANDED_SIG, '  ', ' ') where EXPANDED_SIG != REPLACE(EXPANDED_SIG, '  ', ' ')
update rxf set EXPANDED_SIG = REPLACE(EXPANDED_SIG, '  ', ' ') where EXPANDED_SIG != REPLACE(EXPANDED_SIG, '  ', ' ')
update rxf set EXPANDED_SIG = REPLACE(EXPANDED_SIG, '  ', ' ') where EXPANDED_SIG != REPLACE(EXPANDED_SIG, '  ', ' ')
update rxf set EXPANDED_SIG = REPLACE(EXPANDED_SIG, '  ', ' ') where EXPANDED_SIG != REPLACE(EXPANDED_SIG, '  ', ' ')

update rxf set expanded_sig = rtrim(expanded_sig)
update RXF SET SIG = EXPANDED_SIG
update rxf set EXPANDED_ALT_SIG = ''

go

INSERT INTO FIL
(
[ACQ_COST],
[ADM_DATE],
[ADM_PASS],
[AUTHORIZE],
[AWP],
[BIL_BAT_ID],
[BIL_DATE],
[BILL_FLAG],
[CARD_QUANT],
[CHG_ID],
[COPAY_PRICE],
[COST],
[COST_BASIS],
[CREDITABLE_FLAG],
[DAYS_SUPPLY],
[DEA],
[DI_SEVERITY],
[DISPENSE_QTY],
[DISPENSE_TEXT],
[DOCUTRACK_ID],
[DRG_ID],
[DSP_FILL_FLAG],
[DSP_ID],
[EMAR],
[END_DATE],
[END_PASS],
[FAC_ID],
[FAC_TYPE],
[FIL_DATE],
[FIL_THP_ID],
[FORMULARY_FLAG],
[GENERIC_FLAG],
[HIGH_ACQ_COST],
[ID],
[INS_PRICE],
[KOP],
[LAB_REQ_FLAG],
[LABEL_COUNT],
[LABEL_SPLITS],
[LOT_DATE],
[LOT_NUMBER],
[MACHINE],
[MAINTENANCE_FLAG],
[MAN_ABB],
[MAN_DNAME],
[MAN_LABELER],
[MANUAL_PRC_FLAG],
[NDC],
[NET_QTY_DSP],
[NFA_ID],
[ORD_DRG_ID],
[ORIGIN],
[OTC_FLAG],
[OVR_ID],
[PACKS_FLAG],
[PAT_ID],
[PAT_LOCATION],
[PHARM_USR_ID],
[PHARMACIST],
[PHARMACY_FLAG],
[PHR_ID],
[PND_USR_ID],
[PR_FLAG],
[PRC_FACTOR],
[PRC_FEE],
[PRC_ID],
[PREFERRED_FLAG],
[PREGNANT_FLAG],
[PRI_ID],
[PRICE],
[PRT_DATE],
[PV_SYS_DATE],
[PV_SYS_TIME],
[PV_TIME_HOUR],
[PV_USR_ID],
[QTY_DSP],
[QTY_PER_BUBBLE],
[QTY_PER_CARD],
[QTY_SENT],
[QTY_UNCOSTED],
[RTN_FLAG],
[RXF_CON_ID],
[RXF_ID],
[RXF_NUMBER],
[RXF_ORD_ID],
[RXF_ORD_ORDER_NUM],
[SAFETY_CAP_FLAG],
[SAVED_VERSION],
[SCREENED],
[SCRIPTTYPE],
[SEQ_NUM],
[SHOW_IN_REVIEW_FLAG],
[STATUS],
[SYS_DATE],
[SYS_TIME],
[SYS_TIME_HOUR],
[SYS_USR_ID],
[TECH],
[TECH_USR_ID],
[THP],
[THREE],
[TIME_DISPENSED],
[U_COST],
[U_COST_BASIS],
[U_PRC_FACTOR],
[U_PRC_FEE],
[U_PRC_ID],
[UNIT],
[USUAL_PRICE],
[VERIFY1_SYS_DATE],
[VERIFY1_SYS_TIME],
[VERIFY1_USR_ID],
[VERIFY2_SYS_DATE],
[VERIFY2_SYS_TIME],
[VERIFY2_USR_ID],
[VERSION],
[VOID_REA_ID],
[VOID_SYS_DATE],
[VOID_SYS_TIME],
[VOID_SYS_USR_ID],
[WAC_COST]
)
SELECT
NULL, --ACQ_COST
dbo.CIPSDAte(rx.[Date Entered], getdate()), --ADM_DATE
NULL, --ADM_PASS
NULL, --AUTHORIZE
NULL, --AWP
NULL, --BIL_BAT_ID
NULL, --BIL_DATE
'T', --BILL_FLAG
null, --CARD_QUANT
CHG.ID, --CHG_ID
0, --COPAY_PRICE
NULL, --COST
'A', --COST_BASIS
'T', --CREDITABLE_FLAG
0, --DAYS_SUPPLY
DRG.DEA, --DEA
NULL, --DI_SEVERITY
NULL, --DISPENSE_QTY
NULL, --DISPENSE_TEXT
NULL, --DOCUTRACK_ID
DRG.ID, --DRG_ID
'F', --DSP_FILL_FLAG
NULL, --DSP_ID
'F', --EMAR
NULL, --END_DATE
NULL, --END_PASS
PAT.fac_id, --FAC_ID
' ', --FAC_TYPE
dbo.CIPSDAte(rx.[Date Entered], getdate()), --FIL_DATE
NULL, --FIL_THP_ID
DRG.FORMULARY_FLAG, --FORMULARY_FLAG
DRG.GENERIC_FLAG, --GENERIC_FLAG
NULL, --HIGH_ACQ_COST
ROW_NUMBER() OVER (ORDER BY [Rx Number]), --ID
NULL, --INS_PRICE
NEXT_FIL_TYPE, --KOP
'F', --LAB_REQ_FLAG
1, --LABEL_COUNT
NULL, --LABEL_SPLITS
NULL, --LOT_DATE
NULL, --LOT_NUMBER
case isnull(fac_drg.machine, 'D') when 'D' then drg.MACHINE else fac_drg.MACHINE end, --MACHINE
'F', --MAINTENANCE_FLAG
NULL, --MAN_ABB
NULL, --MAN_DNAME
NULL, --MAN_LABELER
'T', --MANUAL_PRC_FLAG
DRG.NDC, --NDC
0, --NET_QTY_DSP
NULL, --NFA_ID
DRG.ID, --ORD_DRG_ID
'M', --ORIGIN
DRG.OTC_FLAG, --OTC_FLAG
NULL, --OVR_ID
'F', --PACKS_FLAG
PAT_ID, --PAT_ID
NULL, --PAT_LOCATION
null, --PHARM_USR_ID
null, --PHARMACIST
'T', --PHARMACY_FLAG
1, --PHR_ID
NULL, --PND_USR_ID
'F', --PR_FLAG
NULL, --PRC_FACTOR
NULL, --PRC_FEE
NULL, --PRC_ID
'T', --PREFERRED_FLAG
'F', --PREGNANT_FLAG
NULL, --PRI_ID
0, --PRICE
NULL, --PRT_DATE
NULL, --PV_SYS_DATE
NULL, --PV_SYS_TIME
NULL, --PV_TIME_HOUR
NULL, --PV_USR_ID
0, --QTY_DSP
NULL, --QTY_PER_BUBBLE
null, --QTY_PER_CARD
NULL, --QTY_SENT
0, --QTY_UNCOSTED
'F', --RTN_FLAG
NULL, --RXF_CON_ID
RXF.ID, --RXF_ID
RXF.RX_NUMBER, --RXF_NUMBER
NULL, --RXF_ORD_ID
NULL, --RXF_ORD_ORDER_NUM
'F', --SAFETY_CAP_FLAG
NULL, --SAVED_VERSION
'Y', --SCREENED
'N', --SCRIPTTYPE
0, --SEQ_NUM
'T', --SHOW_IN_REVIEW_FLAG
'F', --STATUS
dbo.CIPSDAte(rx.[Date Entered], getdate()), --FIL_DATE
'1899-12-30 ' + rx.[Time Entered] , --SYS_TIME
NULL, --SYS_TIME_HOUR
NULL, --SYS_USR_ID
null, --TECH
null, --TECH_USR_ID
'F', --THP
'F', --THREE
NULL, --TIME_DISPENSED
NULL, --U_COST
'A', --U_COST_BASIS
NULL, --U_PRC_FACTOR
NULL, --U_PRC_FEE
NULL, --U_PRC_ID
'E', --UNIT
0, --USUAL_PRICE
NULL, --VERIFY1_SYS_DATE
NULL, --VERIFY1_SYS_TIME
NULL, --VERIFY1_USR_ID
NULL, --VERIFY2_SYS_DATE
NULL, --VERIFY2_SYS_TIME
NULL, --VERIFY2_USR_ID
'QS1PROFILE', --VERSION
NULL, --VOID_REA_ID
NULL, --VOID_SYS_DATE
NULL, --VOID_SYS_TIME
NULL, --VOID_SYS_USR_ID
NULL --WAC_COST
FROM Import.dbo.Rx
JOIN RXF on (Rxf.RX_NUMBER = rx.[Rx number] and phr_id = 1)
LEFT OUTER JOIN PAT on (Pat.ID = Rxf.pat_id)
LEFT OUTER JOIN DRG on (DRG.ID = Rxf.drg_Id)
LEFT OUTER JOIN CRD on (DRG.CRD_ID = CRD.Id)
join fac on (fac.id = pat.fac_id)
left outer join chg on (fac.dcode = chg.dcode)
LEFT OUTER JOIN FAC_DRG ON (fac_Drg.fac_id = fac.id and fac_drg.drg_id = drg.id)
WHERE [Rx Number] not in (select [Tx-Rx number] from import.dbo.fill)
go

INSERT INTO FIL
(
[ACQ_COST],
[ADM_DATE],
[ADM_PASS],
[AUTHORIZE],
[AWP],
[BIL_BAT_ID],
[BIL_DATE],
[BILL_FLAG],
[CARD_QUANT],
[CHG_ID],
[COPAY_PRICE],
[COST],
[COST_BASIS],
[CREDITABLE_FLAG],
[DAYS_SUPPLY],
[DEA],
[DI_SEVERITY],
[DISPENSE_QTY],
[DISPENSE_TEXT],
[DOCUTRACK_ID],
[DRG_ID],
[DSP_FILL_FLAG],
[DSP_ID],
[EMAR],
[END_DATE],
[END_PASS],
[FAC_ID],
[FAC_TYPE],
[FIL_DATE],
[FIL_THP_ID],
[FORMULARY_FLAG],
[GENERIC_FLAG],
[HIGH_ACQ_COST],
[ID],
[INS_PRICE],
[KOP],
[LAB_REQ_FLAG],
[LABEL_COUNT],
[LABEL_SPLITS],
[LOT_DATE],
[LOT_NUMBER],
[MACHINE],
[MAINTENANCE_FLAG],
[MAN_ABB],
[MAN_DNAME],
[MAN_LABELER],
[MANUAL_PRC_FLAG],
[NDC],
[NET_QTY_DSP],
[NFA_ID],
[ORD_DRG_ID],
[ORIGIN],
[OTC_FLAG],
[OVR_ID],
[PACKS_FLAG],
[PAT_ID],
[PAT_LOCATION],
[PHARM_USR_ID],
[PHARMACIST],
[PHARMACY_FLAG],
[PHR_ID],
[PND_USR_ID],
[PR_FLAG],
[PRC_FACTOR],
[PRC_FEE],
[PRC_ID],
[PREFERRED_FLAG],
[PREGNANT_FLAG],
[PRI_ID],
[PRICE],
[PRT_DATE],
[PV_SYS_DATE],
[PV_SYS_TIME],
[PV_TIME_HOUR],
[PV_USR_ID],
[QTY_DSP],
[QTY_PER_BUBBLE],
[QTY_PER_CARD],
[QTY_SENT],
[QTY_UNCOSTED],
[RTN_FLAG],
[RXF_CON_ID],
[RXF_ID],
[RXF_NUMBER],
[RXF_ORD_ID],
[RXF_ORD_ORDER_NUM],
[SAFETY_CAP_FLAG],
[SAVED_VERSION],
[SCREENED],
[SCRIPTTYPE],
[SEQ_NUM],
[SHOW_IN_REVIEW_FLAG],
[STATUS],
[SYS_DATE],
[SYS_TIME],
[SYS_TIME_HOUR],
[SYS_USR_ID],
[TECH],
[TECH_USR_ID],
[THP],
[THREE],
[TIME_DISPENSED],
[U_COST],
[U_COST_BASIS],
[U_PRC_FACTOR],
[U_PRC_FEE],
[U_PRC_ID],
[UNIT],
[USUAL_PRICE],
[VERIFY1_SYS_DATE],
[VERIFY1_SYS_TIME],
[VERIFY1_USR_ID],
[VERIFY2_SYS_DATE],
[VERIFY2_SYS_TIME],
[VERIFY2_USR_ID],
[VERSION],
[VOID_REA_ID],
[VOID_SYS_DATE],
[VOID_SYS_TIME],
[VOID_SYS_USR_ID],
[WAC_COST]
)
SELECT
NULL, --ACQ_COST
dbo.CIPSDate([TX-Date Filled], null), --ADM_DATE
NULL, --ADM_PASS
NULL, --AUTHORIZE
NULL, --AWP
NULL, --BIL_BAT_ID
NULL, --BIL_DATE
'T', --BILL_FLAG
null, --CARD_QUANT
isnull(chg.id, chg2.id), --CHG_ID
0, --COPAY_PRICE
NULL, --COST
'A', --COST_BASIS
'T', --CREDITABLE_FLAG
0,
DRG.DEA, --DEA
NULL, --DI_SEVERITY
NULL, --DISPENSE_QTY
NULL, --DISPENSE_TEXT
NULL, --DOCUTRACK_ID
DRG.ID, --DRG_ID
'F', --DSP_FILL_FLAG
NULL, --DSP_ID
'F', --EMAR
NULL, --END_DATE
NULL, --END_PASS
PAT.fac_id, --FAC_ID
' ', --FAC_TYPE
dbo.CIPSDate([TX-Date Filled], null), --FIL_DATE
NULL, --FIL_THP_ID
DRG.FORMULARY_FLAG, --FORMULARY_FLAG
DRG.GENERIC_FLAG, --GENERIC_FLAG
NULL, --HIGH_ACQ_COST
ROW_NUMBER() OVER (ORDER BY [TX-Rx Number], [TX-Date Filled], ident) + (SELECT MAX(ID) FROM FIL), --ID
NULL, --INS_PRICE
NEXT_FIL_TYPE, --KOP
'F', --LAB_REQ_FLAG
1, --LABEL_COUNT
NULL, --LABEL_SPLITS
NULL, --LOT_DATE
NULL, --LOT_NUMBER
case isnull(fac_drg.machine, 'D') when 'D' then drg.MACHINE else fac_drg.MACHINE end, --MACHINE
DRG.MAINTENANCE_FLAG, --MAINTENANCE_FLAG
NULL, --MAN_ABB
NULL, --MAN_DNAME
NULL, --MAN_LABELER
'T', --MANUAL_PRC_FLAG
DRG.NDC, --NDC
dbo.CIPSNumber([TX-Quantity Disp]), --NET_QTY_DSP
NULL, --NFA_ID
DRG.ID, --ORD_DRG_ID
' ', --ORIGIN
DRG.OTC_FLAG, --OTC_FLAG
NULL, --OVR_ID
'F', --PACKS_FLAG
PAT_ID, --PAT_ID
NULL, --PAT_LOCATION
PHARM.ID, --PHARM_USR_ID
PHARM.INITIALS, --PHARMACIST
'T', --PHARMACY_FLAG
1, --PHR_ID
NULL, --PND_USR_ID
'F', --PR_FLAG
NULL, --PRC_FACTOR
NULL, --PRC_FEE
NULL, --PRC_ID
'T', --PREFERRED_FLAG
'F', --PREGNANT_FLAG
NULL, --PRI_ID
0, --PRICE
NULL, --PRT_DATE
NULL, --PV_SYS_DATE
NULL, --PV_SYS_TIME
NULL, --PV_TIME_HOUR
NULL, --PV_USR_ID
dbo.CIPSNumber([TX-Quantity Disp]), --QTY_DSP
NULL, --QTY_PER_BUBBLE
null, --QTY_PER_CARD
NULL, --QTY_SENT
NULL, --QTY_UNCOSTED
'F', --RTN_FLAG
NULL, --RXF_CON_ID
RXF.ID, --RXF_ID
RXF.RX_NUMBER, --RXF_NUMBER
NULL, --RXF_ORD_ID
NULL, --RXF_ORD_ORDER_NUM
'F', --SAFETY_CAP_FLAG
NULL, --SAVED_VERSION
'N', --SCREENED
'N', --SCRIPTTYPE
convert(int, fill.id), --SEQ_NUM
'T', --SHOW_IN_REVIEW_FLAG
'N', --STATUS
dbo.CIPSDate([TX-Date Filled], null), --Sys_DATE
'1899-12-30 ' + rx.[Time Entered], --SYS_TIME
NULL, --SYS_TIME_HOUR
NULL, --SYS_USR_ID
TECH.INITIALS, --TECH
TECH.ID, --TECH_USR_ID
'F', --THP
'F', --THREE
NULL, --TIME_DISPENSED
NULL, --U_COST
'A', --U_COST_BASIS
NULL, --U_PRC_FACTOR
NULL, --U_PRC_FEE
NULL, --U_PRC_ID
'E', --UNIT
NULL, --USUAL_PRICE
NULL, --VERIFY1_SYS_DATE
NULL, --VERIFY1_SYS_TIME
NULL, --VERIFY1_USR_ID
NULL, --VERIFY2_SYS_DATE
NULL, --VERIFY2_SYS_TIME
NULL, --VERIFY2_USR_ID
'QS1', --VERSION
NULL, --VOID_REA_ID
NULL, --VOID_SYS_DATE
NULL, --VOID_SYS_TIME
NULL, --VOID_SYS_USR_ID
NULL --WAC_COST
FROM Import.dbo.Fill
JOIN Import.dbo.Rx on fill.[Tx-Rx number] = rx.[Rx Number]
JOIN RXF on (Rxf.RX_NUMBER = rx.[Rx number] and phr_id = 1)
JOIN PAT on (Pat.ID = Rxf.pat_id)
join fac on (pat.FAC_ID = fac.id)
LEFT OUTER JOIN DRG on (DRG.ID = Rxf.drg_Id)
LEFT OUTER JOIN USR as PHARM on (pharm.NPI = Fill.[TX-Entered-Phar])
LEFT OUTER JOIN USR AS TECH on (tech.NPI = Fill.[TX-Entered-Tech])
left outer join chg on (fill.charge = chg.DNAME)
left outer join chg as chg2 on (fac.dcode = chg2.dcode)
LEFT OUTER JOIN FAC_DRG ON (fac_Drg.fac_id = fac.id and fac_drg.drg_id = drg.id)
go


update pat set chg_id = (select top 1 fil.chg_Id from fil where pat_id = pat.id and chg_id is not null order by fil_Date desc)
UPDATE FIL SET SEQ_NUM = SEQ_NUM - (SELECT MIN(F2.SEQ_NUM) FROM FIL as F2 WHERE FIL.RXF_NUMBER = F2.RXF_NUMBER)

UPDATE RXF SET FIL_ID = (select max(fil.id) from fil where rx_number = rxF_number);
UPDATE RXF SET QTY_USED = (select sum(QTY_DSP) from fil where rx_number = rxF_number);
UPDATE RXF SET REF_USED = (select COUNT(*) from fil where rx_number = rxF_number);
UPDATe RXF SET ACT_REF_USED = REF_USED

UPDATE RXF SET DAYS_SUPPLY = convert(int, EXP_DATE) - convert(int, ORG_DATE)
UPDATE RXF SET TOT_QTY_DUE = QTY_DUE + QTY_USED where QTY_DUE + QTY_USED < 1000000
update RXF set TOT_QTY_DUE = DLY_QTY * DAYS_SUPPLY where QTY_DUE <= 0 and DLY_QTY > 0 and QTY_DUE + QTY_USED < 1000000 and DLY_QTY * days_Supply < 1000000
UPDATE RXF SET LAST_FIL = (SELECT MAX(FIL_DATE) FROM FIL WHERE RX_NUMBER = RXF_NUMBER)

UPDATE RXF SET QTY_DUE = TOT_QTY_DUE - QTY_USED where QTY_DUE <= 0 and DLY_QTY > 0


UPDATE FIL SET FIL.DAYS_SUPPLY = (SELECT FIL.QTY_DSP / RXF.DLY_QTY where RXF.DLY_QTY > 0)
from FIL
JOIN RXF ON (RXF.id = FIL.RXF_ID)
Where FIL.DAYS_SUPPLY is null or FIL.DAYS_SUPPLY = 0

UPDATE RXF SET REF_DAYS_SUPPLY = FIL.DAYS_SUPPLY, REF_QTY = FIL.QTY_DSP
from rXF
JOIN FIL ON (FIL.id = (SELECT MAX(F2.ID) FROM FIL as F2 WHERE RX_NUMBER = F2.RXF_NUMBER and F2.QTY_DSP > 0))
WHERE MACHINE = 'N'

-- Get Next Rx Number

update idd set NEXTID = (Select max(rx_number) + 1 from rxf where rx_number < 2999999) where nextid = 2000000
update idd set NEXTID = (select max(rx_number) + 1 from rxf where rx_number < 4999999) where nextid = 4000000
update idd set NEXTID = (select max(rx_number) + 1 from rxf where rx_number < 7999999) where nextid > 6000000

DELETE FROM IDD WHERE FIELDNAME = 'ID'

go


insert into PAT_ALC 
select
ROW_NUMBER() OVER (ORDER BY pat_id),
PAT_ID,
ALC_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, ALC.ID as alc_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 01])
	join ALC on (ALC.ID = ALC_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_ALC as pn where pn.alc_id = alc.id and pn.pat_id = pat.id)
) as t1

insert into PAT_ALC 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_ALC),
PAT_ID,
ALC_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, ALC.ID as alc_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 02])
	join ALC on (ALC.ID = ALC_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_ALC as pn where pn.alc_id = alc.id and pn.pat_id = pat.id)
) as t1


insert into PAT_ALC 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_ALC),
PAT_ID,
ALC_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, ALC.ID as alc_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 03])
	join ALC on (ALC.ID = ALC_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_ALC as pn where pn.alc_id = alc.id and pn.pat_id = pat.id)
) as t1

insert into PAT_ALC 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_ALC),
PAT_ID,
ALC_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, ALC.ID as alc_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 04])
	join ALC on (ALC.ID = ALC_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_ALC as pn where pn.alc_id = alc.id and pn.pat_id = pat.id)
) as t1

insert into PAT_ALC 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_ALC),
PAT_ID,
ALC_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, ALC.ID as alc_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 05])
	join ALC on (ALC.ID = ALC_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_ALC as pn where pn.alc_id = alc.id and pn.pat_id = pat.id)
) as t1

go

delete from pat_par

insert into PAT_PAR 
select
ROW_NUMBER() OVER (ORDER BY pat_id),
PAT_ID,
PAR_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, PAR.ID as PAR_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 01])
	join PAR on (PAR.ID = PAR_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_PAR as pn where pn.PAR_id = PAR.id and pn.pat_id = pat.id)
) as t1

insert into PAT_PAR 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_PAR),
PAT_ID,
PAR_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, PAR.ID as PAR_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 02])
	join PAR on (PAR.ID = PAR_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_PAR as pn where pn.PAR_id = PAR.id and pn.pat_id = pat.id)
) as t1


insert into PAT_PAR 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_PAR),
PAT_ID,
PAR_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, PAR.ID as PAR_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 03])
	join PAR on (PAR.ID = PAR_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_PAR as pn where pn.PAR_id = PAR.id and pn.pat_id = pat.id)
) as t1

insert into PAT_PAR 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_PAR),
PAT_ID,
PAR_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, PAR.ID as PAR_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 04])
	join PAR on (PAR.ID = PAR_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_PAR as pn where pn.PAR_id = PAR.id and pn.pat_id = pat.id)
) as t1

insert into PAT_PAR 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_PAR),
PAT_ID,
PAR_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, PAR.ID as PAR_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 05])
	join PAR on (PAR.ID = PAR_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_PAR as pn where pn.PAR_id = PAR.id and pn.pat_id = pat.id)
) as t1

go


insert into PAT_MED 
select
ROW_NUMBER() OVER (ORDER BY pat_id),
PAT_ID,
MED_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, MED.ID as MED_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 01])
	join MED on (MED.ID = MED_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_Med as pn where pn.med_id = med.id and pn.pat_id = pat.id)
) as t1

insert into PAT_MED 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_MED),
PAT_ID,
MED_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, MED.ID as MED_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 02])
	join MED on (MED.ID = MED_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_Med as pn where pn.med_id = med.id and pn.pat_id = pat.id)
) as t1


insert into PAT_MED 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_MED),
PAT_ID,
MED_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, MED.ID as MED_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 03])
	join MED on (MED.ID = MED_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_Med as pn where pn.med_id = med.id and pn.pat_id = pat.id)
) as t1

insert into PAT_MED 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_MED),
PAT_ID,
MED_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, MED.ID as MED_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 04])
	join MED on (MED.ID = MED_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_Med as pn where pn.med_id = med.id and pn.pat_id = pat.id)
) as t1

insert into PAT_MED 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_MED),
PAT_ID,
MED_ID, 
null, 'F', 'F', 'F', 'F', 'F', 'F', null
From 
(
	select distinct pat.id as pat_id, MED.ID as MED_id
	from
	import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 05])
	join MED on (MED.ID = MED_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_Med as pn where pn.med_id = med.id and pn.pat_id = pat.id)
) as t1

go

insert into PAT_NHI 
select
ROW_NUMBER() OVER (ORDER BY pat_id),
PAT_ID,
NHI_ID, 
null, 
null
FROM
(
	select distinct PAT.ID as PAT_ID, NHI.ID as NHI_ID
	From import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 01])
	join nhi on (nhi.ID = NHI_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_nhi as pn where pn.nhi_id = nhi.id and pn.pat_id = pat.id)
) as alg


insert into PAT_NHI 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_nhi),
PAT_ID,
NHI_ID, 
null, null
FROM
(
	select distinct PAT.ID as PAT_ID, NHI.ID as NHI_ID
	From import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 02])
	join nhi on (nhi.ID = NHI_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_nhi as pn where pn.nhi_id = nhi.id and pn.pat_id = pat.id)
) as alg

insert into PAT_NHI 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_nhi),
PAT_ID,
NHI_ID, 
null, null
FROM
(
	select distinct PAT.ID as PAT_ID, NHI.ID as NHI_ID
	From import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 03])
	join nhi on (nhi.ID = NHI_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_nhi as pn where pn.nhi_id = nhi.id and pn.pat_id = pat.id)
) as alg



insert into PAT_NHI 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_nhi),
PAT_ID,
NHI_ID, 
null, null
FROM
(
	select distinct PAT.ID as PAT_ID, NHI.ID as NHI_ID
	From import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 04])
	join nhi on (nhi.ID = NHI_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_nhi as pn where pn.nhi_id = nhi.id and pn.pat_id = pat.id)
) as alg


insert into PAT_NHI 
select
ROW_NUMBER() OVER (ORDER BY pat_id) + (SELECT MAX(id) FROM pat_nhi),
PAT_ID,
NHI_ID, 
null, null
FROM
(
	select distinct PAT.ID as PAT_ID, NHI.ID as NHI_ID
	From import.dbo.rx
	join ALC_TRN on (TRANSLATE_FROM = rx.[allg Desc 05])
	join nhi on (nhi.ID = NHI_ID)
	join pat on (pat.ACCT_NUMBER = rx.[Patient Code])
	where not exists (select * from pat_nhi as pn where pn.nhi_id = nhi.id and pn.pat_id = pat.id)
) as alg


go

insert into NFA (id, PAT_ID, RXF_ID, ORG_DATE, EXP_DATE, SYS_USR_ID, SYS_DATE, SYS_TIME)
Select rxf.id, pat_id, rxf.id, org_date, exp_date, 1, org_date, '1899-12-30' 
From rxf where id in (select fil.rxf_id from fil where FORMULARY_FLAG = 'F')

go

UPDATE FAC set CYCLE_START_DATE = (select F2.CYCLE_START_DATE + ((( Convert(int,GETDATE()) - Convert(int, F2.CYCLE_START_DATE) ) / 14) * 14) from CIPS_SETUP.dbo.FAC as F2 where F2.id = fac.id)

insert into rfd
select
RXF.ID,
FAC.CYCLE_START_DATE + 14,
getdate(),
'G',
NULL
From RXF
join fil ON RXF.fil_ID = fil.ID
join drg on fil.drg_id = drg.id
join pat ON RXF.PAT_ID = PAT.ID
join fac ON PAT.FAC_ID = FAC.ID
WHERE drg.refill_due_flag = 'T'
and fil.machine = 'C'
and pat.fac_id in (select rgn_fac.fac_id from rgn_fac where rgn_id in (1,2,3)) -- TCG Regions
and dc_Flag = 'F'
and getdate() < (exp_date + 1)

insert into rfd
select
RXF.ID,
fil.adm_date + fil.days_supply,
getdate(),
'G',
NULL
FROM FAC
JOIN PAT ON PAT.FAC_ID = FAC.ID
join RXF ON RXF.PAT_ID = PAT.ID
join fil ON RXF.fil_ID = fil.ID
join drg on fil.drg_id = drg.id
WHERE drg.refill_due_flag = 'T'
and rxf.id not in (select rxf_ID FROM rfd)
and fil.DAYS_SUPPLY > 0
and dc_Flag = 'F'
and getdate() < (exp_date + 1) 


insert into RXS
select
RXF.ID,
RXF.ID,
RXF.ORG_DATE,
(select top 1 SCH_ITM.PAS_ID FROM SCH_ITM JOIN PAS ON PAS_ID = PAS.ID WHERE SCH.ID = SCH_ITM.SCH_ID ORDER By PAS.DTIME ASC),
(RXF.ORG_DATE + RXF.DAYS_SUPPLY ),
(select top 1 SCH_ITM.PAS_ID FROM SCH_ITM JOIN PAS ON PAS_ID = PAS.ID WHERE SCH.ID = SCH_ITM.SCH_ID ORDER By PAS.DTIME DESC),
''
FROM RXF
JOIN SCH ON SCH_ID = SCH.ID
where sch.id not in (select sch.id from sch where id not in (select sch_id from sch_itm ))

insert into RXS_ITM
select
ROW_NUMBER() OVER( ORDER BY RXF.ID, SCH_ITM.ID) ,
RXF.ID,
SCH_ITM.PAS_ID,
null,
NULL,
1,
RXF.QTY_DOSE,
SCH_ITM.SUNDAY,
SCH_ITM.MONDAY,
SCH_ITM.TUESDAY,
SCH_ITM.WEDNESDAY,
SCH_ITM.THURSDAY,
SCH_ITM.FRIDAY,
SCH_ITM.SATURDAY
FROM RXF
JOIN SCH ON SCH_ID = SCH.ID
JOIN SCH_ITM ON SCH.ID = SCH_ITM.SCH_ID

update rxf set qty_dose = (dly_qty / isnull((select Count(*) from rxs_itm where rxf.id = rxs_id having count(*) > 0), 1))
where qty_dose = 0

update rxs_itm set qty = (select rxf.qty_dose from rxf where rxf.id = rxs_id) where qty = 0

go


INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ABB' FROM ABB;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ABL' FROM ABL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ALC' FROM ALC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ALC_TRN' FROM ALC_TRN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ATR' FROM ATR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ATR_DSC' FROM ATR_DSC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ATR_ITM' FROM ATR_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'BIL_BAT' FROM BIL_BAT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CAO' FROM CAO;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CAT' FROM CAT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CHC' FROM CHC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CHG' FROM CHG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CHG_THP' FROM CHG_THP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CHG_TRN' FROM CHG_TRN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CHL' FROM CHL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CON' FROM CON;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CR9' FROM CR9;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CRD' FROM CRD;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CRT' FROM CRT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CRT_PAS' FROM CRT_PAS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CSA' FROM CSA;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CSO' FROM CSO;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CST' FROM CST;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CST_ITM' FROM CST_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'CTG' FROM CTG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DAB' FROM DAB;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DAC' FROM DAC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DCM' FROM DCM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DCR' FROM DCR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DDR' FROM DDR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DEA' FROM DEA;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DEL' FROM DEL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DEL_BAT' FROM DEL_BAT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DGP' FROM DGP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DGR' FROM DGR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DIS' FROM DIS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DIT' FROM DIT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOC' FROM DOC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOC_FAC' FROM DOC_FAC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOC_ITM' FROM DOC_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOC_LOC' FROM DOC_LOC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOC_LOG' FROM DOC_LOG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOC_NOT' FROM DOC_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOL' FROM DOL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DOM' FROM DOM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRB' FROM DRB;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRB_ITM' FROM DRB_ITM;
delete from idd where TABLENAME = 'DRG'
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG' FROM DRG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_CMP' FROM DRG_CMP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_NM9' FROM DRG_NM9;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_NOT' FROM DRG_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_PHR' FROM DRG_PHR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_SIG' FROM DRG_SIG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_THC' FROM DRG_THC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_TRN' FROM DRG_TRN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRG_VEN' FROM DRG_VEN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRT' FROM DRT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRT_COD' FROM DRT_COD;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DRT_ITM' FROM DRT_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DSP' FROM DSP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'DUR' FROM DUR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC' FROM FAC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_CHG' FROM FAC_CHG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_CTG' FROM FAC_CTG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_DRG' FROM FAC_DRG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_LOG' FROM FAC_LOG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_NOT' FROM FAC_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_PAS' FROM FAC_PAS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_PRC' FROM FAC_PRC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_PRF' FROM FAC_PRF;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_QUE' FROM FAC_QUE;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_RMT' FROM FAC_RMT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_STD' FROM FAC_STD;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_TRN' FROM FAC_TRN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FAC_UNT' FROM FAC_UNT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FCR' FROM FCR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL' FROM FIL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_BIL' FROM FIL_BIL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_CDT' FROM FIL_CDT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_IMG' FROM FIL_IMG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_PCK' FROM FIL_PCK;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_REJ' FROM FIL_REJ;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_SHP' FROM FIL_SHP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FIL_THP' FROM FIL_THP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'FRM' FROM FRM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'GRP' FROM GRP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'HDT' FROM HDT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'IDS' FROM IDS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'IMG_QUE' FROM IMG_QUE;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'INI' FROM INI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'INI_NOT' FROM INI_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'INO' FROM INO;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'INS' FROM INS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'IPD' FROM IPD;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'IPI' FROM IPI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'IPR' FROM IPR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ISI' FROM ISI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ISM' FROM ISM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ISR' FROM ISR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ISS' FROM ISS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'JBL' FROM JBL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'LAB' FROM LAB;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'LBL' FROM LBL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'LOC' FROM LOC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'LOT' FROM LOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'MAN' FROM MAN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'MCN' FROM MCN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'MED' FROM MED;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'MSG' FROM MSG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'MSG_ITM' FROM MSG_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'NAM' FROM NAM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'NDC' FROM NDC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'NFA' FROM NFA;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'NHI' FROM NHI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'ORD_NOT' FROM ORD_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'OVR' FROM OVR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAR' FROM PAR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT' FROM PAT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_ALC' FROM PAT_ALC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_BOK' FROM PAT_BOK;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_CRT' FROM PAT_CRT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_DIS' FROM PAT_DIS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_IMG' FROM PAT_IMG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_MED' FROM PAT_MED;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_NHI' FROM PAT_NHI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_NM9' FROM PAT_NM9;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_NMC' FROM PAT_NMC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_NOT' FROM PAT_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_PAR' FROM PAT_PAR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PAT_THP' FROM PAT_THP;
delete from idd where TABLENAME = 'PCT'
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PCT' FROM PCT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PFR' FROM PFR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PGR' FROM PGR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PHR' FROM PHR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PHR_PRF' FROM PHR_PRF;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PIN' FROM PIN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PLC' FROM PLC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PNT' FROM PNT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PPO' FROM PPO;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PPO_ITM' FROM PPO_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PRC' FROM PRC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PRC_ITM' FROM PRC_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PRI' FROM PRI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PRO' FROM PRO;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PRR' FROM PRR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'PRT' FROM PRT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'QUE' FROM QUE;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'REL' FROM REL;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'REQ' FROM REQ;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RGN' FROM RGN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RGN_FAC' FROM RGN_FAC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RPG' FROM RPG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RPG_ITM' FROM RPG_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RPT' FROM RPT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RPT_SCH' FROM RPT_SCH;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RQA' FROM RQA;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RRE' FROM RRE;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RSP' FROM RSP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RTN' FROM RTN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RTS' FROM RTS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXF' FROM RXF;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXF_CON' FROM RXF_CON;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXF_EXT' FROM RXF_EXT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXF_NOT' FROM RXF_NOT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXF_ORD' FROM RXF_ORD;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXS' FROM RXS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXS_DSP' FROM RXS_DSP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'RXS_ITM' FROM RXS_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'SCH' FROM SCH;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'SCH_ITM' FROM SCH_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'SEC' FROM SEC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'SEC_UGP' FROM SEC_UGP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'SEC_USR' FROM SEC_USR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'STD' FROM STD;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'STD_ITM' FROM STD_ITM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TBI' FROM TBI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TBX' FROM TBX;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TER' FROM TER;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'THC' FROM THC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'THP_FMT' FROM THP_FMT;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'THP_GPI' FROM THP_GPI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'THP_GRP' FROM THP_GRP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TRC' FROM TRC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TRF' FROM TRF;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TRM' FROM TRM;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TRX' FROM TRX;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TSK' FROM TSK;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TSK_DOC' FROM TSK_DOC;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'TSK_LOG' FROM TSK_LOG;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'UGP' FROM UGP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'USR' FROM USR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'USR_UGP' FROM USR_UGP;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'VEN' FROM VEN;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'VIS' FROM VIS;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'WAB' FROM WAB;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'WHI' FROM WHI;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'WHR' FROM WHR;
INSERT INTO IDD (NEXTID, FIELDNAME, TABLENAME) SELECT isnull(MAX(ID), 0) + 1, 'ID', 'WIC' FROM WIC;

delete fROM MSG

UPDATE REG SET DDATA = 'LIVE' WHERE ID = 'DB_ENVIRONMENT'
delete from reg where id = 'DB_VERSION_PLAY'

go

sp_updatestats