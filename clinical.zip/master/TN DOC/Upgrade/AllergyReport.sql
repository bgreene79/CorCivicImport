Use cips
select nhi.dtext, count(*) as patients from cips.dbo.pat_nhi join nhi on nhi.id = nhi_id where nhi_id in (select alc_trn.nhi_id from alc_trn where alc_trn.NHI_ID is not null) and pat_id in (Select pat.id from cips.dbo.pat where status = 'N') group by nhi.dtext order by patients desc
