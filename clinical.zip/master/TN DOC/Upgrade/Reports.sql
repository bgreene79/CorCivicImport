select 
[Rx Number]
from rx where DC_CODE is null and [HOA for Sig 2] is not null and rx.[Rx Stop Date] >= getdate()