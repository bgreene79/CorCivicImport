use cips_test
select * From pat where pat.id in (Select pat_thp.pat_id from pat_thp where thp_id = 'FED')

select * from rfd