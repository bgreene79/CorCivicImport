USE CIPS_SUP_PHILLY;

begin tran;

declare @NEXT_ID int;

set @NEXT_ID = ( select idd.nextid from idd where idd.TABLENAME = 'PAT_ALC' and idd.FIELDNAME = 'ID' );

INSERT INTO [dbo].[PAT_ALC]
           ([ID]
           ,[PAT_ID]
           ,[ALC_ID]
           ,[RASH_FLAG]
           ,[SHOCK_FLAG]
           ,[ASTHMA_FLAG]
           ,[NAUSEA_FLAG]
           ,[ANEMIA_FLAG]
           ,[OTHER_FLAG])
     SELECT
           @NEXT_ID + ROW_NUMBER() OVER (ORDER BY a.[patient id]),
           pat.id,													--<PAT_ID, int,>
           a.[Internal Id],											--<ALC_ID, int,>
           'F',														--<RASH_FLAG, char(1),>
           'F',														--<SHOCK_FLAG, char(1),>
           'F',														--<ASTHMA_FLAG, char(1),>
           'F',														--<NAUSEA_FLAG, char(1),>
           'F',														--<ANEMIA_FLAG, char(1),>
           'F'														--<OTHER_FLAG, char(1),>

	from cips_raw_philly.dbo.alc a
	left outer join pat on ( pat.acct_number = a.[pat account number] and pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) )

GO

update idd set nextid = ( select max(id) + 1 from pat_alc ) where idd.tablename = 'PAT_ALC' and idd.FIELDNAME = 'ID';

commit;












