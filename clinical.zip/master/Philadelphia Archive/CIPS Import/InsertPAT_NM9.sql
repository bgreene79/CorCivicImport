USE CIPS_SUP_PHILLY;

begin tran;

declare @NEXT_ID int;

set @NEXT_ID = ( select idd.nextid from idd where idd.TABLENAME = 'PAT_NM9' and idd.FIELDNAME = 'ID' );

INSERT INTO [dbo].[PAT_NM9]
           ([ID]
           ,[PAT_ID]
           ,[NM9_ID]
           ,[FLAGGED]
           ,[STARTON]
           ,[STOPON])
     SELECT
           @NEXT_ID + ROW_NUMBER() OVER (ORDER BY n.[patient id]),
           pat.id,													--<PAT_ID, int,>
           n.[ID],											        --<NM9_ID, int,>           
           'F',														--<FLAGGED, CHAR(1),>
           NULL,													--<STARTON, DATE,>
           NULL														--<STOPON, DATE,>

	from cips_raw_philly.dbo.nm9 n
	left outer join pat on ( pat.acct_number = n.[Account Number] and pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) )

GO

update idd set nextid = ( select max(id) + 1 from PAT_NM9 ) where idd.tablename = 'PAT_NM9' and idd.FIELDNAME = 'ID';

commit;