USE CIPS_SUP_PHILLY;

begin tran;

declare @NEXT_ID int;

set @NEXT_ID = ( select idd.nextid from idd where idd.TABLENAME = 'PAT_PAR' and idd.FIELDNAME = 'ID' );

INSERT INTO [dbo].[PAT_PAR]
           ([ID]
           ,[PAT_ID]
           ,[PAR_ID]
           ,[ONSET]
           ,[RASH_FLAG]
           ,[SHOCK_FLAG]
           ,[ASTHMA_FLAG]
           ,[NAUSEA_FLAG]
           ,[ANEMIA_FLAG]
           ,[OTHER_FLAG]
           ,[OTHER_TEXT])
     SELECT
           @NEXT_ID + ROW_NUMBER() OVER (ORDER BY p.[patient id]),
           pat.id,													--<PAT_ID, int,>
           p.[Internal ID],									        --<PAR_ID, int,>           
           NULL,													--<ONSET, DATE,>
           'F',														--<RASH_FLAG,   CHAR(1),>
           'F',														--<SHOCK_FLAG,  CHAR(1),>
           'F',														--<ASTHMA_FLAG, CHAR(1),>
           'F',														--<NAUSEA_FLAG, CHAR(1),>
           'F',														--<ANEMIA_FLAG, CHAR(1),>
           'F',													    --<OTHER_FLAG,  CHAR(1),>
           NULL														--<OTHER_TEXT,  varchar(25),>

	from cips_raw_philly.dbo.par p
	left outer join pat on ( pat.acct_number = p.[Account Number] and pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) )
	where len( p.[account number] ) > 0

GO

update idd set nextid = ( select max(id) + 1 from PAT_PAR ) where idd.tablename = 'PAT_PAR' and idd.FIELDNAME = 'ID';

commit;

--delete from pat_par where pat_id = 72272 and id = 130;

--select * from cips_raw_philly.dbo.par p

--select * from pat where id = 72923