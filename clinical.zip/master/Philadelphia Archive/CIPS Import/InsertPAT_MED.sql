USE CIPS_SUP_PHILLY;

begin tran;

declare @NEXT_ID int;

set @NEXT_ID = ( select idd.nextid from idd where idd.TABLENAME = 'PAT_MED' and idd.FIELDNAME = 'ID' );

INSERT INTO [dbo].[PAT_MED]
           ([ID]
           ,[PAT_ID]
           ,[MED_ID]
           ,[ONSET]
           ,[RASH_FLAG]
           ,[SHOCK_FLAG]
           ,[ASTHMA_FLAG]
           ,[NAUSEA_FLAG]
           ,[ANEMIA_FLAG]
           ,[OTHER_FLAG]
           ,[OTHER_TEXT])
     SELECT
           @NEXT_ID + ROW_NUMBER() OVER (ORDER BY m.[patient id]),
           pat.id,													--<PAT_ID, int,>
           m.[Internal Id],											--<MED_ID, int,>
           NULL,													--<ONSET, DATE>
           'F',														--<RASH_FLAG, char(1),>
           'F',														--<SHOCK_FLAG, char(1),>
           'F',														--<ASTHMA_FLAG, char(1),>
           'F',														--<NAUSEA_FLAG, char(1),>
           'F',														--<ANEMIA_FLAG, char(1),>
           'F',														--<OTHER_FLAG, char(1),>
           NULL														--<OTHER_TEXT, VARCHAR(25),>

	from cips_raw_philly.dbo.med m
	left outer join pat on ( pat.acct_number = m.[Account Number] and pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) )

GO

update idd set nextid = ( select max(id) + 1 from pat_med ) where idd.tablename = 'PAT_MED' and idd.FIELDNAME = 'ID';

commit;







