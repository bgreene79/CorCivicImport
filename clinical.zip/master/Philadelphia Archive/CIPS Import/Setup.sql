alter table doc add conversion varchar(10) null;
alter table drg add conversion varchar(10) null;
alter table rxf add conversion varchar(10) null;
alter table fil add conversion varchar(10) null;

-- This does not currently take into account stock rx # systems

--drop function dbo.GetRxNumberIDDKey;
--drop function dbo.GetRxNumber;

CREATE FUNCTION dbo.GetRxNumberIDDKey( @DEA char(1), @PHR_ID int )  
RETURNS varchar(30)  
WITH EXECUTE AS CALLER  
AS  
BEGIN 
	declare @System int;

	if @DEA <= '0' or @DEA > '6'
		set @System = ( select phr.rx_num_Dea0 from phr where phr.id = @PHR_ID );
	else if @DEA = '1' 
		set @System = ( select phr.rx_num_Dea1 from phr where phr.id = @PHR_ID );
	else if @DEA = '2'
		set @System = ( select phr.rx_num_Dea2 from phr where phr.id = @PHR_ID );
	else if @DEA = '3' 
		set @System = ( select phr.rx_num_Dea3 from phr where phr.id = @PHR_ID );
	else if @DEA = '4' 
		set @System = ( select phr.rx_num_Dea4 from phr where phr.id = @PHR_ID );
	else if @DEA = '5' 
		set @System = ( select phr.rx_num_Dea5 from phr where phr.id = @PHR_ID );
	else if @DEA = '6'
		set @System = ( select phr.rx_num_Dea6 from phr where phr.id = @PHR_ID );
	
	RETURN( convert( varchar(20), @PHR_ID ) + '-NUMBER-' + convert( char(1), @System ) );  
END;

CREATE FUNCTION dbo.GetRxNumber( @DEA char(1), @PHR_ID int )  
RETURNS int  
WITH EXECUTE AS CALLER  
AS  
BEGIN  
	declare @RxNumber int;
	
	set @RxNumber = ( select idd.NEXTID from idd where tablename = 'RXF' and fieldname = dbo.GetRxNumberIDDKey( @DEA, @PHR_ID ) );
     
	RETURN(@RxNumber);  
END;  