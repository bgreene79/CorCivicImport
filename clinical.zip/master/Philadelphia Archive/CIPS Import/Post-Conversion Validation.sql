
select
( select count(*) from cips_raw_philly.dbo.pat ) 'Exported Patients',
( select count(*) from pat where pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) ) 'Imported Patients'

select
( select count(distinct rx.[Doc ID]) from cips_raw_philly.dbo.rx ) 'Exported Doctors',
( select count(*) from doc where conversion = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'conversion' ) ) 'Imported Doctors'

-- Keep in mind that we only add drugs where the formatted ndc doesn't already exist in the CIPS drug table
select
( select count(distinct rx.[drug id]) from cips_raw_philly.dbo.rx ) 'Exported Drugs',
( select count(*) from drg where conversion = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'conversion' ) ) 'Imported Drugs'




