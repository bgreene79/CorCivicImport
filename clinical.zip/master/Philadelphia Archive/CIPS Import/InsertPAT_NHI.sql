USE CIPS_SUP_PHILLY;

begin tran;

declare @NEXT_ID int;

set @NEXT_ID = ( select idd.nextid from idd where idd.TABLENAME = 'PAT_NHI' and idd.FIELDNAME = 'ID' );

INSERT INTO [dbo].[PAT_NHI]
           ([ID]
           ,[PAT_ID]
           ,[NHI_ID]
           ,[DCODE]
           ,[DTEXT])
     SELECT
           @NEXT_ID + ROW_NUMBER() OVER (ORDER BY n.[patient id]),
           pat.id,													--<PAT_ID, int,>
           n.[Internal Id],											--<NHI_ID, int,>           
           NULL,													--<DCODE, VARCHAR(25),>
           NULL														--<DTEXT, VARCHAR(25),>

	from cips_raw_philly.dbo.nhi n
	left outer join pat on ( pat.acct_number = n.[Pat Account Number] and pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) )

GO

update idd set nextid = ( select max(id) + 1 from pat_nhi ) where idd.tablename = 'PAT_NHI' and idd.FIELDNAME = 'ID';

commit;