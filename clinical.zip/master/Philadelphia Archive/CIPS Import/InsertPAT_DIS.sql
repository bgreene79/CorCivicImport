USE CIPS_SUP_PHILLY;

begin tran;

declare @NEXT_ID int;

set @NEXT_ID = ( select idd.nextid from idd where idd.TABLENAME = 'PAT_DIS' and idd.FIELDNAME = 'ID' );

INSERT INTO [dbo].[PAT_Dis]
           ([ID]
           ,[PAT_ID]
           ,[DIS_ID]
           ,[FLAGGED]
           ,[STARTON]
           ,[STOPON])
     SELECT
           @NEXT_ID + ROW_NUMBER() OVER (ORDER BY d.[patient id]),
           pat.id,													--<PAT_ID, int,>
           d.[Internal Id],											--<DIS_ID, int,>
           'F',														--<FLAGGED, char(1),>
           NULL,													--<STARTON, DATE,>
           NULL														--<STOPON, DATE,>

	from cips_raw_philly.dbo.dis d
	left outer join pat on ( pat.acct_number = d.[account number] and pat.fac_id in ( select fac_id from rgn_fac where rgn_id = ( select data from cips_raw_philly.dbo.tmp_reg where id = 'RGN_ID' ) ) )

GO

update idd set nextid = ( select max(id) + 1 from pat_dis ) where idd.tablename = 'PAT_DIS' and idd.FIELDNAME = 'ID';

commit;