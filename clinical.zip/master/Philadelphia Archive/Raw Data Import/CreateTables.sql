Create Table FacilityTranslation ( OldFacCode varchar(10) NOT NULL, NewFacCode varchar(10) NOT NULL, Defaults char(1) NOT NULL );

GO

CREATE UNIQUE CLUSTERED INDEX [ClusteredIndex] ON [dbo].[FacilityTranslation]
(
	[OldFacCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

GO


insert into facilitytranslation values ( 'KAL', 'FAC223424', 'F' );

GO

create table tmp_reg ( id varchar(20) NOT NULL, data varchar(255) );

GO

insert into tmp_reg values ( 'PHR_ID', 1 );
insert into tmp_reg values ( 'NEW_PHR_ID', 1 );
insert into tmp_reg values ( 'RGN_ID', 1 );
insert into tmp_reg values ( 'CONVERSION', 'PHILLY' );
insert into tmp_reg values ( 'DC_REA_ID', 'DISC' );
insert into tmp_reg values ( 'SYS_USR_ID', 56 );
insert into tmp_reg values ( 'RPH_USR_ID', 56 );

GO

