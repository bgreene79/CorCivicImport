-- Clear out data from temp tables

drop table CIPS_RAW_PHILLY.dbo.rx;
drop table CIPS_RAW_PHILLY.dbo.alc;
drop table CIPS_RAW_PHILLY.dbo.par;
drop table CIPS_RAW_PHILLY.dbo.med;
drop table CIPS_RAW_PHILLY.dbo.nhi;
drop table CIPS_RAW_PHILLY.dbo.dis;
drop table CIPS_RAW_PHILLY.dbo.nm9;
drop table CIPS_RAW_PHILLY.dbo.pat;
